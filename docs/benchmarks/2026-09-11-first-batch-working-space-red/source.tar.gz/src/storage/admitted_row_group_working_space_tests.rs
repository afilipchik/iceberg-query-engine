//! Same-budget reader progress: distinguish output ordering from page floors.
use super::*;
use arrow::{
    array::{Array, Int64Array},
    datatypes::{DataType, Field, Schema},
    record_batch::RecordBatch,
};
use parquet::{arrow::ArrowWriter, basic::Compression, file::properties::WriterProperties};
use std::sync::Arc;

fn fixture(
    path: &std::path::Path,
    count: usize,
    columns: usize,
) -> (File, ArrowReaderMetadata, SchemaRef) {
    let schema = Arc::new(Schema::new(
        (0..columns)
            .map(|c| Field::new(format!("c{c}"), DataType::Int64, true))
            .collect::<Vec<_>>(),
    ));
    let arrays = (0..columns)
        .map(|c| {
            Arc::new(Int64Array::from(
                (0..count)
                    .map(|i| (i % 17 != 0).then_some((i % 101) as i64 + c as i64 * 1000))
                    .collect::<Vec<_>>(),
            )) as arrow::array::ArrayRef
        })
        .collect();
    let batch = RecordBatch::try_new(schema.clone(), arrays).unwrap();
    let props = WriterProperties::builder()
        .set_dictionary_enabled(false)
        .set_compression(Compression::UNCOMPRESSED)
        .set_write_batch_size(count)
        .set_data_page_row_count_limit(count)
        .set_max_row_group_row_count(Some(count))
        .build();
    let mut writer =
        ArrowWriter::try_new(File::create(path).unwrap(), schema.clone(), Some(props)).unwrap();
    writer.write(&batch).unwrap();
    writer.close().unwrap();
    let file = File::open(path).unwrap();
    let metadata = ArrowReaderMetadata::load(&file, Default::default()).unwrap();
    (file, metadata, schema)
}

fn check(batch: &RecordBatch, start: usize) {
    for (c, a) in batch.columns().iter().enumerate() {
        let a = a.as_any().downcast_ref::<Int64Array>().unwrap();
        for i in 0..a.len() {
            let row = start + i;
            assert_eq!(a.is_valid(i), row % 17 != 0);
            if a.is_valid(i) {
                assert_eq!(a.value(i), (row % 101) as i64 + c as i64 * 1000);
            }
        }
    }
}

#[test]
fn fresh_small_target_progresses_at_same_budget_as_large_target() {
    let dir = tempfile::tempdir().unwrap();
    let (file, metadata, schema) = fixture(&dir.path().join("working-space.parquet"), 4096, 3);
    let budget = 160 << 10;
    let small_pool = MemoryPool::new(budget);
    let mut small = open(&file, &metadata, 0, &[0, 1, 2], schema.clone(), &small_pool).unwrap();
    let mut count = 0;
    while let Some(batch) = small.next(1, 65536, &small_pool).unwrap() {
        assert_eq!(batch.num_rows(), 1);
        check(&batch, count);
        count += batch.num_rows();
    }
    assert_eq!(count, 4096);
    drop(small);
    assert_eq!(small_pool.used(), 0);
    let large_pool = MemoryPool::new(budget);
    let mut large = open(&file, &metadata, 0, &[0, 1, 2], schema, &large_pool).unwrap();
    let first = large.next(4096, 65536, &large_pool);
    if let Err(error) = &first {
        assert!(error.is_memory_limit(), "{error}");
        eprintln!(
            "large first output refused: used={} limit={} error={error}",
            large_pool.used(),
            large_pool.max()
        );
        let retry = large.next(1, 65536, &large_pool);
        eprintln!(
            "retained reader one-row retry: {:?}; used={}",
            retry
                .as_ref()
                .map(|v| v.as_ref().map(RecordBatch::num_rows)),
            large_pool.used()
        );
        drop(retry);
    }
    let failed = first.is_err();
    if let Ok(Some(batch)) = first {
        check(&batch, 0);
    }
    drop(large);
    assert_eq!(large_pool.used(), 0);
    assert!(
        !failed,
        "same budget completes a fresh one-row reader but refuses a large-target first output"
    );
}

#[test]
fn genuinely_oversized_page_refuses_even_with_one_row_target() {
    let dir = tempfile::tempdir().unwrap();
    let (file, metadata, schema) = fixture(&dir.path().join("page-floor.parquet"), 8192, 1);
    let pool = MemoryPool::new(32 << 10);
    let mut reader = open(&file, &metadata, 0, &[0], schema, &pool).unwrap();
    let error = reader.next(1, 65536, &pool).unwrap_err();
    assert!(error.is_memory_limit(), "{error}");
    eprintln!("one-row page-floor refusal: {error}; used={}", pool.used());
    drop(reader);
    assert_eq!(pool.used(), 0);
}
