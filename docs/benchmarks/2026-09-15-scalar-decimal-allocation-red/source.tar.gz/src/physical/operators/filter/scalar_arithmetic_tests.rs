use super::*;
use crate::execution::{expression_memory::with_expression_pool, MemoryPool};
use arrow::array::Decimal128Array;

fn decimal_batch(values: Vec<Option<i128>>, precision: u8, scale: i8) -> RecordBatch {
    let values: ArrayRef = Arc::new(
        Decimal128Array::from(values)
            .with_precision_and_scale(precision, scale)
            .unwrap(),
    );
    RecordBatch::try_from_iter(vec![("v", values)]).unwrap()
}

fn expression(op: BinaryOp, scalar_left: bool, literal: i64) -> Expr {
    let scalar = Expr::literal(ScalarValue::Int64(literal));
    let column = Expr::column("v");
    let (left, right) = if scalar_left {
        (scalar, column)
    } else {
        (column, scalar)
    };
    Expr::BinaryExpr {
        left: Box::new(left),
        op,
        right: Box::new(right),
    }
}

#[test]
fn decimal_literal_arithmetic_fits_output_sized_workspace() {
    let len = 4096;
    let batch = decimal_batch(
        (0..len + 3)
            .map(|i| {
                if i % 7 == 0 {
                    None
                } else {
                    Some((i % 11) as i128 - 5)
                }
            })
            .collect(),
        10,
        2,
    )
    .slice(3, len);
    for aggregate_root in [false, true] {
        for scalar_left in [false, true] {
            for op in [BinaryOp::Subtract, BinaryOp::Multiply] {
                // Input ownership is external to this expression scope. Allow
                // output values/validity and metadata, not full literal/coercion
                // arrays. This applies to any batch, not a named SQL query.
                let pool = Arc::new(MemoryPool::new(len * 16 + len.div_ceil(8) + 8192));
                let expr = expression(op, scalar_left, 2);
                let result = with_expression_pool(&pool, || {
                    if aggregate_root {
                        evaluate_aggregate_inputs(&batch, 1, |_| &expr, Ok)
                            .map(|mut arrays| arrays.remove(0))
                    } else {
                        evaluate_expr(&batch, &expr)
                    }
                })
                .expect("scalar arithmetic must not expand and coerce a full literal array");
                let output = result.as_any().downcast_ref::<Decimal128Array>().unwrap();
                let precision = if op == BinaryOp::Multiply { 30 } else { 22 };
                assert_eq!(output.data_type(), &DataType::Decimal128(precision, 2));
                let input = batch
                    .column(0)
                    .as_any()
                    .downcast_ref::<Decimal128Array>()
                    .unwrap();
                let expected: Vec<_> = input
                    .iter()
                    .map(|value| {
                        value.map(|v| match op {
                            BinaryOp::Multiply => v * 2,
                            BinaryOp::Subtract if scalar_left => 200 - v,
                            BinaryOp::Subtract => v - 200,
                            _ => unreachable!(),
                        })
                    })
                    .collect();
                assert_eq!(output.iter().collect::<Vec<_>>(), expected);
                let escaped = result.slice(1, 3).to_data().buffers()[0].clone();
                drop(result);
                assert!(pool.used() > 0, "escaped output lost its admission owner");
                drop(escaped);
                assert_eq!(pool.used(), 0);
            }
        }
    }
}

#[test]
fn decimal_literal_scaling_does_no_value_work_for_empty_or_null_rows() {
    for len in [0, 17] {
        let batch = decimal_batch(vec![None; len], 38, 38);
        let pool = Arc::new(MemoryPool::new(1024 * 1024));
        for scalar_left in [false, true] {
            let expr = expression(BinaryOp::Add, scalar_left, i64::MAX);
            let result = with_expression_pool(&pool, || evaluate_expr(&batch, &expr)).unwrap();
            assert_eq!(result.data_type(), &DataType::Decimal128(38, 38));
            assert_eq!(result.len(), len);
            assert_eq!(result.null_count(), len);
            drop(result);
            assert_eq!(pool.used(), 0);
        }
    }
}

#[test]
fn decimal_literal_scaling_preserves_late_overflow_and_releases_allocations() {
    let batch = decimal_batch(vec![None, Some(0)], 38, 38);
    let pool = Arc::new(MemoryPool::new(1024 * 1024));
    for scalar_left in [false, true] {
        let expr = expression(BinaryOp::Add, scalar_left, i64::MAX);
        let error = with_expression_pool(&pool, || evaluate_expr(&batch, &expr)).unwrap_err();
        assert!(!error.is_memory_limit(), "{error}");
        assert!(
            error.to_string().to_lowercase().contains("overflow"),
            "{error}"
        );
        assert_eq!(pool.used(), 0);
    }
}
