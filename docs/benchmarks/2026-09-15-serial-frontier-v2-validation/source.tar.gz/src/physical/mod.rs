//! Physical execution module
//!
//! Converts logical plans to physical plans and executes them

pub mod compiled_expr;
pub(crate) mod dense_domain;
pub(crate) mod fixed_width_output;
#[cfg(feature = "gpu")]
pub mod gpu;
pub mod morsel;
pub mod morsel_agg;
pub mod operators;
mod plan;
mod planner;
pub mod queue_layout;
pub mod vector;
pub mod vectorized_agg;

pub use morsel::*;
pub use morsel_agg::*;
pub use operators::*;
pub use plan::*;
pub use planner::*;
pub use vector::*;
pub use vectorized_agg::*;
