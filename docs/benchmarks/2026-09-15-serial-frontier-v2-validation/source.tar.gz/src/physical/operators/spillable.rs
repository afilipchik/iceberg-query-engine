//! Spillable operators for larger-than-memory execution
//!
//! This module provides versions of hash join, hash aggregate, and sort
//! operators that can spill intermediate data to disk when memory limits
//! are exceeded.

use crate::error::{QueryError, Result};
use crate::execution::{ExecutionConfig, SharedMemoryPool};
use crate::physical::operators::filter::evaluate_expr;
use crate::physical::{PhysicalOperator, RecordBatchStream};
use crate::planner::{Expr, JoinType};
use arrow::array::{
    ArrayRef, Date32Array, Float64Array, Int64Array, StringArray, UInt32Array, UInt64Array,
};
use arrow::compute;
use arrow::datatypes::{Schema, SchemaRef};
use arrow::record_batch::RecordBatch;
use async_trait::async_trait;
use futures::stream::{self, StreamExt, TryStreamExt};
use hashbrown::HashMap;
use parquet::arrow::arrow_reader::ParquetRecordBatchReaderBuilder;
use parquet::arrow::ArrowWriter;
use parquet::basic::Compression;
use parquet::file::properties::WriterProperties;
use std::fmt;
use std::fs::File;
use std::hash::{Hash, Hasher};
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Arc;
use tokio::sync::OnceCell;

/// Unique counter for spill directory names to avoid conflicts between concurrent operators
static SPILL_COUNTER: AtomicU64 = AtomicU64::new(0);

/// Number of hash partitions for spilling
const NUM_PARTITIONS: usize = 64;

/// Row granularity for re-chunking oversized batches during spill ingestion
/// AND for streaming a spilled aggregate partition back off disk
/// (`aggregate_partition_chunked`). Matches `append_batch_streaming`'s
/// `SPILL_WRITER_ROW_GROUP_ROWS` — one shared magic number, not three.
const AGG_CHUNK_ROWS: usize = 8_192;

/// Monotonic call-sequence id for `QE_SPILL_DEBUG` join/aggregate spill-path
/// tracing (task 001, spill-join-correctness epic). Diagnostic only — lets
/// log lines from repeated or overlapping invocations of
/// `execute_spill_path` / `execute_fused_streaming` (e.g. a fused-streaming
/// aggregate that aborts and falls back, re-executing its input) be told
/// apart in the log. Never read by any non-diagnostic code path.
static SJ_TRACE_SEQ: AtomicU64 = AtomicU64::new(0);

/// Next id for `QE_SPILL_DEBUG` tracing. `Ordering::Relaxed` is enough: this
/// only needs distinct values for correlating log lines, never ordering
/// guarantees against other memory operations.
fn next_sj_trace_id() -> u64 {
    SJ_TRACE_SEQ.fetch_add(1, Ordering::Relaxed)
}

// ============================================================================
// Fault injection: forced spill (spill-join-correctness-2 epic, task 003)
// ============================================================================
//
// A reusable, permanent mechanism to force `SpillableHashJoinExec`'s
// spill/unspill machinery to engage at a CHOSEN, controllable point in
// build/probe, decoupled from whether the data is actually oversized — the
// harness this enables (`examples/spill_chaos_harness.rs`) runs a query once
// with this forced and once without, and differentially compares the two
// results. Same style as this file's own `QE_SPILL_DEBUG` and the archived
// `spill-join-correctness` epic's own `QE_SPILL_CHAOS_FORCE_ABORT`: plain,
// explicitly-opt-in env vars, checked fresh (never cached) at each call site,
// zero cost and zero behavior change unless a caller sets them.
//
// Two independent, orthogonal levers:
//
// 1. `QE_SPILL_CHAOS_FORCE_SPILL` (`compute_build_decision`, WHEN): forces
//    the top-level build/no-build decision to take the disk-spill branch
//    (`BuildDecision::Spill`) after a CHOSEN number of build batches have
//    already been collected flat (0 = force on the very first batch),
//    regardless of the configured `memory_limit`/`spill_threshold` or how
//    much data is actually present. On its own this only guarantees the
//    `BuildDecision::Spill` CODE PATH is taken — whether any individual
//    partition's rows actually touch disk still depends on memory pressure
//    inside `build_with_partitioning`, since a small build side may still
//    fit every partition in memory once inside it.
// 2. `QE_SPILL_CHAOS_FORCE_SPILL_PARTITIONS` (`build_with_partitioning`,
//    WHICH): forces specific hash partitions — "all", or a comma-separated
//    list of indices in `0..NUM_PARTITIONS` — to write their resident
//    batches to disk the moment they receive their first one, regardless of
//    memory pressure. This is the lever that guarantees a REAL write +
//    read-back round trip happens for chosen rows, even when the whole
//    build side is a handful of rows that would otherwise trivially fit in
//    memory end to end. Because probe-side routing (`probe_with_spilling`)
//    decides whether to spill a probe batch purely from whether its build
//    partition already spilled, forcing build-side partitions here also
//    forces the PROBE-side disk round trip (through
//    `process_spilled_partition`) for those same partitions — one lever
//    covers both build and probe.
//
// Pure parsing logic is factored out (`parse_chaos_force_spill_after_batches`
// / `ChaosPartitionSpec::parse`) so it is unit-testable without mutating the
// real process environment — `cargo test` runs many tests from one binary
// concurrently, and a test calling `std::env::set_var` here would race every
// other test reading the same key (see `gpu.rs`'s `parse_cache_budget_mb` and
// `execution::context::parse_merge_concurrency` for this exact, established
// precedent in this codebase).

/// Pure parsing logic for `QE_SPILL_CHAOS_FORCE_SPILL` — see the module-level
/// "Fault injection" doc comment above. `None` (env var unset) means no
/// forcing at all; `Some(raw)` (env var set, to any string, including empty
/// or unparseable) means "force spill," at the batch count `raw` parses to,
/// defaulting to 0 (force on the very first batch) if `raw` doesn't parse.
fn parse_chaos_force_spill_after_batches(raw: Option<&str>) -> Option<usize> {
    raw.map(|v| v.trim().parse::<usize>().unwrap_or(0))
}

fn chaos_force_spill_after_batches() -> Option<usize> {
    parse_chaos_force_spill_after_batches(
        std::env::var("QE_SPILL_CHAOS_FORCE_SPILL").ok().as_deref(),
    )
}

/// Which hash partitions `build_with_partitioning` should force to disk,
/// independent of memory pressure — see the module-level "Fault injection"
/// doc comment above for why this is needed alongside
/// `chaos_force_spill_after_batches`.
#[derive(Debug, Clone, PartialEq, Eq)]
enum ChaosPartitionSpec {
    /// Force every one of the `NUM_PARTITIONS` hash partitions to disk —
    /// maximum coverage in a single trial.
    All,
    /// Force exactly these partition indices to disk; every other
    /// partition still spills only if memory pressure demands it.
    Indices(std::collections::HashSet<usize>),
}

impl ChaosPartitionSpec {
    fn contains(&self, idx: usize) -> bool {
        match self {
            ChaosPartitionSpec::All => true,
            ChaosPartitionSpec::Indices(set) => set.contains(&idx),
        }
    }

    /// "all" (case-insensitive) forces every partition. Otherwise, a
    /// comma-separated list of partition indices; any comma-separated
    /// token that fails to parse as a `usize` is silently skipped (an
    /// empty or fully-unparseable spec is `Indices(<empty set>)`, i.e. "no
    /// partitions forced" — never a panic).
    fn parse(spec: &str) -> Self {
        let spec = spec.trim();
        if spec.eq_ignore_ascii_case("all") {
            return ChaosPartitionSpec::All;
        }
        let indices = spec
            .split(',')
            .filter_map(|s| s.trim().parse::<usize>().ok())
            .collect();
        ChaosPartitionSpec::Indices(indices)
    }
}

fn parse_chaos_force_spill_partitions(raw: Option<&str>) -> Option<ChaosPartitionSpec> {
    raw.map(ChaosPartitionSpec::parse)
}

fn chaos_force_spill_partitions() -> Option<ChaosPartitionSpec> {
    parse_chaos_force_spill_partitions(
        std::env::var("QE_SPILL_CHAOS_FORCE_SPILL_PARTITIONS")
            .ok()
            .as_deref(),
    )
}

/// Drain every input partition concurrently and return the collected batches
/// together with their estimated in-memory size.
///
/// Pipeline-breaking operators (aggregate, sort) must consume all input partitions
/// before they can produce output. Draining them one-at-a-time in an `await` loop
/// serializes the whole subtree beneath the operator — a parallel scan/join feeding
/// an aggregate would execute on a single core. Spawning one task per partition lets
/// the producers run concurrently across the tokio worker pool.
///
/// The total size is returned so the caller can decide whether the data fits within
/// its memory budget or the spill path is required.
pub(crate) async fn collect_input_partitions_concurrently(
    input: &Arc<dyn PhysicalOperator>,
) -> Result<(Vec<RecordBatch>, usize)> {
    let input_partitions = input.output_partitions().max(1);

    if input_partitions == 1 {
        // Nothing to overlap — avoid the task-spawn round trip.
        let stream = input.execute(0).await?;
        let batches: Vec<RecordBatch> = stream.try_collect().await?;
        let size = batches.iter().map(estimate_batch_size).sum();
        return Ok((batches, size));
    }

    let mut handles = Vec::with_capacity(input_partitions);
    for part in 0..input_partitions {
        let input = input.clone();
        handles.push(tokio::spawn(async move {
            let stream = input.execute(part).await?;
            let batches: Vec<RecordBatch> = stream.try_collect().await?;
            let size: usize = batches.iter().map(estimate_batch_size).sum();
            Ok::<_, QueryError>((batches, size))
        }));
    }

    let mut all_batches = Vec::new();
    let mut total_size = 0usize;
    for handle in handles {
        let (batches, size) = handle
            .await
            .map_err(|e| QueryError::Execution(format!("Partition task join error: {}", e)))??;
        total_size += size;
        all_batches.extend(batches);
    }

    Ok((all_batches, total_size))
}

/// Stream every output partition of `input` concurrently into ONE merged
/// stream, without collecting anything into a `Vec` first.
///
/// `collect_input_partitions_concurrently` (above) gives a pipeline-breaking
/// operator's collect side the same cross-core parallelism benefit, but by
/// fully draining every partition into memory before returning — exactly
/// what let `SpillableHashJoinExec`'s build side OOM before its own spill
/// decision could ever run (spill-join-correctness-2 epic, task 002: the
/// build side was compared against `memory_limit * spill_threshold` only
/// AFTER `collect_input_partitions_concurrently` had already fully
/// materialized it).
///
/// Queue occupancy accounting, including batches waiting to send. This is not
/// admission before upstream allocation or ownership after consumer handoff.
struct QueuedInputBatch {
    batch: RecordBatch,
    // Drop buffers before releasing their queue accounting guard.
    _reservation: Option<crate::execution::MemoryReservation>,
    // Demand becomes available only after the queue charge is released.
    _demand: tokio::sync::OwnedSemaphorePermit,
}

// Round exposed buffer bytes to safe u128 storage. ArrayData::build
// validates the resulting type/alignment; no unchecked array construction.
fn copied_input_buffer_bytes(len: usize) -> Result<usize> {
    len.checked_add(15)
        .map(|n| n / 16)
        .and_then(|words| words.checked_mul(16))
        .ok_or_else(|| QueryError::Execution("input queue copy size overflow".into()))
}

#[cfg(test)]
thread_local! { static INPUT_QUEUE_COPY_ATTEMPTS: std::cell::Cell<usize> = const { std::cell::Cell::new(0) }; }

fn own_input_buffer(buffer: &arrow::buffer::Buffer) -> Result<arrow::buffer::Buffer> {
    let bytes = copied_input_buffer_bytes(buffer.len())?;
    let words = bytes / 16;
    #[cfg(test)]
    INPUT_QUEUE_COPY_ATTEMPTS.with(|count| count.set(count.get() + 1));
    let mut owned = Vec::<u128>::new();
    owned.try_reserve_exact(words).map_err(|error| {
        QueryError::Execution(format!(
            "input queue owned buffer allocation refused: {error}"
        ))
    })?;
    // Do not retain an allocation larger than the pre-admitted exact layout.
    // Global Vec normally reports precisely the requested capacity; this check
    // makes a different allocator's excess capacity an explicit refusal.
    if owned.capacity() != words {
        return Err(QueryError::Execution(
            "input queue copy allocator capacity differs from admitted layout".into(),
        ));
    }
    for chunk in buffer.as_slice().chunks(16) {
        let mut bytes = [0u8; 16];
        bytes[..chunk.len()].copy_from_slice(chunk);
        owned.push(u128::from_ne_bytes(bytes));
    }
    Ok(arrow::buffer::Buffer::from_vec(owned).slice_with_length(0, buffer.len()))
}

fn own_input_data(data: arrow::array::ArrayData) -> Result<arrow::array::ArrayData> {
    let mut buffers = Vec::new();
    buffers
        .try_reserve_exact(data.buffers().len())
        .map_err(|error| {
            QueryError::Execution(format!(
                "input queue buffer metadata allocation refused: {error}"
            ))
        })?;
    for buffer in data.buffers() {
        buffers.push(own_input_buffer(buffer)?);
    }
    let mut children = Vec::new();
    children
        .try_reserve_exact(data.child_data().len())
        .map_err(|error| {
            QueryError::Execution(format!(
                "input queue child metadata allocation refused: {error}"
            ))
        })?;
    for child in data.child_data() {
        children.push(own_input_data(child.clone())?);
    }
    let nulls = data
        .nulls()
        .map(|nulls| {
            let bits = nulls.inner();
            Ok::<_, QueryError>(arrow::buffer::NullBuffer::new(
                arrow::buffer::BooleanBuffer::new(
                    own_input_buffer(nulls.buffer())?,
                    bits.offset(),
                    bits.len(),
                ),
            ))
        })
        .transpose()?;
    Ok(data
        .into_builder()
        .buffers(buffers)
        .child_data(children)
        .nulls(nulls)
        .build()?)
}

pub(crate) fn own_input_batch(batch: RecordBatch) -> Result<RecordBatch> {
    let mut columns = Vec::new();
    columns
        .try_reserve_exact(batch.num_columns())
        .map_err(|error| {
            QueryError::Execution(format!(
                "input queue column metadata allocation refused: {error}"
            ))
        })?;
    for array in batch.columns() {
        let data = array.to_data();
        columns.push(arrow::array::make_array(own_input_data(data)?));
    }
    Ok(RecordBatch::try_new_with_options(
        batch.schema(),
        columns,
        &arrow::record_batch::RecordBatchOptions::new().with_row_count(Some(batch.num_rows())),
    )?)
}

fn add_input_charge(total: &mut usize, bytes: usize) -> Result<()> {
    *total = total
        .checked_add(bytes)
        .ok_or_else(|| QueryError::Execution("input queue memory accounting overflow".into()))?;
    Ok(())
}

pub(crate) fn owned_input_column_charge(array: &ArrayRef) -> Result<usize> {
    fn data_bytes(data: &arrow::array::ArrayData, total: &mut usize) -> Result<()> {
        add_input_charge(total, std::mem::size_of_val(data))?;
        for buffer in data.buffers() {
            add_input_charge(total, std::mem::size_of_val(buffer))?;
            // Public Buffer APIs cannot identify custom owners. Charge copies.
            add_input_charge(total, copied_input_buffer_bytes(buffer.len())?)?;
        }
        if let Some(nulls) = data.nulls() {
            add_input_charge(total, copied_input_buffer_bytes(nulls.buffer().len())?)?;
        }
        for child in data.child_data() {
            data_bytes(child, total)?;
        }
        Ok(())
    }
    let mut total = std::mem::size_of::<ArrayRef>();
    add_input_charge(&mut total, std::mem::size_of_val(array.as_ref()))?;
    data_bytes(&array.to_data(), &mut total)?;
    Ok(total)
}

pub(crate) fn owned_input_schema_charge(schema: &SchemaRef) -> Result<usize> {
    let mut total = std::mem::size_of_val(schema.as_ref());
    for field in schema.fields() {
        add_input_charge(&mut total, field.size())?;
    }
    for (key, value) in schema.metadata() {
        add_input_charge(&mut total, std::mem::size_of::<(String, String)>())?;
        add_input_charge(&mut total, key.capacity())?;
        add_input_charge(&mut total, value.capacity())?;
    }
    Ok(total)
}

pub(crate) fn owned_input_batch_base_charge() -> usize {
    std::mem::size_of::<QueuedInputBatch>()
}

pub(crate) fn owned_input_batch_charge(batch: &RecordBatch) -> Result<usize> {
    let mut total = owned_input_batch_base_charge();
    for array in batch.columns() {
        add_input_charge(&mut total, owned_input_column_charge(array)?)?;
    }
    // Shared schema metadata is deliberately charged per queued batch. These
    // are accounted copied-layout bytes, not unique physical bytes or RSS.
    add_input_charge(&mut total, owned_input_schema_charge(&batch.schema())?)?;
    Ok(total)
}

/// Choose a scan row target from the compact fixed-width copy layout. This is
/// scheduling, not a memory reservation: actual queue admission still checks
/// the emitted buffers. Variable-width/encoded layouts have no schema-only bound.
pub(crate) fn input_queue_fixed_width_row_limit(
    schema: &SchemaRef,
    requested: usize,
    budget: usize,
) -> Option<usize> {
    use arrow::datatypes::DataType;
    let widths: Vec<Option<usize>> = schema
        .fields()
        .iter()
        .map(|field| match field.data_type() {
            DataType::Boolean => Some(None),
            DataType::Null => Some(Some(0)),
            DataType::FixedSizeBinary(width) if *width >= 0 => Some(Some(*width as usize)),
            other => other.primitive_width().map(Some),
        })
        .collect::<Option<Vec<_>>>()?;
    let base = owned_input_batch_charge(&RecordBatch::new_empty(schema.clone())).ok()?;
    let fits = |rows: usize| -> Option<bool> {
        let mut bytes = base;
        for width in &widths {
            let payload = match width {
                Some(width) => rows.checked_mul(*width)?,
                None => rows.checked_add(7)? / 8,
            };
            bytes = bytes.checked_add(copied_input_buffer_bytes(payload).ok()?)?;
            // Allow validity even for a non-nullable declared field. Include
            // up to seven leading bitmap bits, then the owned-copy alignment.
            let validity = rows.checked_add(14)? / 8;
            bytes = bytes.checked_add(copied_input_buffer_bytes(validity).ok()?)?;
        }
        Some(bytes <= budget)
    };
    if fits(1) != Some(true) {
        return None;
    }
    let mut low = 1;
    let mut high = requested.max(1);
    while low < high {
        let distance = high - low;
        let middle = low + distance / 2 + distance % 2;
        if fits(middle) == Some(true) {
            low = middle;
        } else {
            high = middle - 1;
        }
    }
    Some(low)
}

// Opt-in attribution only. Durations from concurrent producers overlap and
// must not be summed as wall time. Drop emits partial/error/cancellation work.
struct InputTrace {
    id: u64,
    phase: &'static str,
    started: std::time::Instant,
    detail: serde_json::Value,
    completed: bool,
}

impl InputTrace {
    fn new(phase: &'static str, detail: impl FnOnce() -> serde_json::Value) -> Option<Self> {
        if std::env::var("QE_INPUT_QUEUE_TRACE").as_deref() != Ok("1") {
            return None;
        }
        static NEXT: AtomicU64 = AtomicU64::new(1);
        Some(Self {
            id: NEXT.fetch_add(1, Ordering::Relaxed),
            phase,
            started: std::time::Instant::now(),
            detail: detail(),
            completed: false,
        })
    }

    fn finish(trace: &mut Option<Self>) {
        if let Some(t) = trace.as_mut() {
            t.completed = true;
        }
        drop(trace.take());
    }
}

impl Drop for InputTrace {
    fn drop(&mut self) {
        use std::io::Write;
        let _ = writeln!(
            std::io::stderr().lock(),
            "[input-queue] {}",
            serde_json::json!({
                "id":self.id,"phase":self.phase,"ms":self.started.elapsed().as_secs_f64()*1000.0,
                "completed":self.completed,"unwinding":std::thread::panicking(),"detail":self.detail
            })
        );
    }
}

struct InputQueueStream {
    receiver: tokio::sync::mpsc::Receiver<QueuedInputBatch>,
    producers: tokio::task::JoinSet<Result<()>>,
    label: &'static str,
    finished: bool,
    pending_error: Option<QueryError>,
    // Fixed parallel slots remain admitted until queue AND producers release
    // them, including asynchronous cancellation cleanup.
    envelope: Option<Arc<crate::execution::MemoryReservation>>,
    _queue_metadata: Option<Arc<crate::execution::MemoryReservation>>,
}

enum QueueStreams {
    Legacy(std::vec::IntoIter<RecordBatchStream>),
    Admitted(crate::execution::reserved_vec::ReservedIntoIter<RecordBatchStream>),
}
impl Iterator for QueueStreams {
    type Item = RecordBatchStream;
    fn next(&mut self) -> Option<Self::Item> {
        match self {
            Self::Legacy(iter) => iter.next(),
            Self::Admitted(iter) => iter.next(),
        }
    }
}

impl InputQueueStream {
    fn stop(&mut self) {
        self.finished = true;
        self.receiver.close();
        self.producers.abort_all();
        while self.receiver.try_recv().is_ok() {}
        self.envelope.take();
    }
}

impl Drop for InputQueueStream {
    fn drop(&mut self) {
        self.stop();
        // JoinSet also aborts on drop. Already-running spawn_blocking work in
        // an upstream operator is not preempted by async task cancellation.
    }
}

impl futures::Stream for InputQueueStream {
    type Item = Result<RecordBatch>;

    fn poll_next(
        self: std::pin::Pin<&mut Self>,
        cx: &mut std::task::Context<'_>,
    ) -> std::task::Poll<Option<Self::Item>> {
        use std::task::Poll;
        let this = self.get_mut();
        if this.finished {
            return Poll::Ready(None);
        }
        if this.pending_error.is_some() {
            // Cancellation cannot preempt a synchronous decoder poll. Reap all
            // owned tasks before exposing failure so query teardown/retry cannot
            // overlap their remaining allocations or side effects.
            for _ in 0..64 {
                match this.producers.poll_join_next(cx) {
                    Poll::Ready(Some(_)) => continue,
                    Poll::Ready(None) => {
                        this.finished = true;
                        return Poll::Ready(Some(Err(this.pending_error.take().unwrap())));
                    }
                    Poll::Pending => return Poll::Pending,
                }
            }
            cx.waker().wake_by_ref();
            return Poll::Pending;
        }
        // Observe task failures before yielding more batches. Bound completed
        // task work per poll so a large partition count cannot monopolize it.
        let mut completions = 0;
        for _ in 0..64 {
            completions += 1;
            match this.producers.poll_join_next(cx) {
                Poll::Ready(Some(Ok(Ok(())))) => continue,
                Poll::Ready(Some(result)) => {
                    let error = match result {
                        Ok(Err(error)) => error,
                        Err(error) => QueryError::Execution(format!(
                            "{} producer task failed: {error}",
                            this.label
                        )),
                        Ok(Ok(())) => unreachable!(),
                    };
                    this.stop();
                    this.finished = false;
                    this.pending_error = Some(error);
                    cx.waker().wake_by_ref();
                    return Poll::Pending;
                }
                Poll::Ready(None) | Poll::Pending => break,
            }
        }
        if completions == 64 {
            cx.waker().wake_by_ref();
        }
        match this.receiver.poll_recv(cx) {
            Poll::Ready(Some(queued)) => {
                let QueuedInputBatch {
                    batch,
                    _reservation,
                    _demand,
                } = queued;
                // Consumer ownership begins here; the queue no longer retains
                // this batch. Downstream retained state needs its own admission.
                drop(_reservation);
                drop(_demand);
                Poll::Ready(Some(Ok(batch)))
            }
            Poll::Ready(None) if this.producers.is_empty() => {
                this.finished = true;
                this.envelope.take();
                Poll::Ready(None)
            }
            Poll::Ready(None) => {
                // A closed channel alone is not successful completion: a
                // producer panic may have dropped its last sender. JoinSet
                // registered our waker above; wait for completion instead of
                // self-waking in a loop while the final task is still pending.
                // The completion-budget branch already wakes when needed.
                Poll::Pending
            }
            Poll::Pending => Poll::Pending,
        }
    }
}

#[cfg(test)]
mod admitted_queue_tests;

async fn stream_merge_input_partitions(
    input: &Arc<dyn PhysicalOperator>,
    pool: &SharedMemoryPool,
    label: &'static str,
) -> Result<RecordBatchStream> {
    let partitions = input.output_partitions();
    let mut preparation_trace = InputTrace::new("queue_prepare", || {
        serde_json::json!({
            "label":label,"operator":input.name(),"partitions":partitions
        })
    });
    if partitions == 0 {
        InputTrace::finish(&mut preparation_trace);
        return Ok(Box::pin(stream::empty()));
    }
    if partitions == 1 {
        let result = input.execute(0).await;
        if result.is_ok() {
            InputTrace::finish(&mut preparation_trace);
        }
        return result;
    }
    const PER_PARTITION_CAPACITY: usize = 4;
    let capacity = partitions
        .checked_mul(PER_PARTITION_CAPACITY)
        .ok_or_else(|| QueryError::Execution(format!("{label} input queue capacity overflow")))?;
    if capacity > tokio::sync::Semaphore::MAX_PERMITS {
        return Err(QueryError::Execution(format!(
            "{label} input queue capacity exceeds runtime limit"
        )));
    }
    // Explicit preparation may need this pool for a nested build. Complete it
    // before admitting any outer output slots; ordinary execute is not a proof
    // that an unknown operator has finished initializing or stayed pull-driven.
    let admitted = input.prepare_admitted_queue_input(pool.clone()).await?;
    let admitted_mode = admitted.is_some();
    if let Some(prepared) = &admitted {
        if !prepared.pool.is_within(pool) || prepared.streams.as_slice().len() != partitions {
            return Err(QueryError::Execution(format!(
                "{label} admitted input pool/partition contract violated"
            )));
        }
    }
    let prepared = if admitted_mode {
        None
    } else {
        input.prepare_queue_input().await?
    };
    let prepared_mode = admitted_mode || prepared.is_some();
    let (bound, mut prepared_streams) = if let Some(prepared) = admitted {
        (
            None,
            Some(QueueStreams::Admitted(prepared.streams.into_owned_iter())),
        )
    } else if let Some(prepared) = prepared {
        if prepared.streams.len() != partitions {
            return Err(QueryError::Execution(format!(
                "{label} prepared partition contract violated: expected {partitions}, got {}",
                prepared.streams.len()
            )));
        }
        let bytes = prepared.output.max_bytes();
        (
            bytes,
            Some(QueueStreams::Legacy(prepared.streams.into_iter())),
        )
    } else {
        (
            input
                .pool_independent_queue_copy_bound()
                .and_then(|b| b.max_bytes()),
            None,
        )
    };
    let pool = Arc::new(crate::execution::MemoryPool::new_child(
        pool,
        label,
        pool.max(),
    ));
    // Conservative task/channel/handle allowance, retained through cancellation
    // by both the queue and producers. Decoder and output leases are separate.
    let queue_metadata = if admitted_mode {
        let bytes = partitions
            .checked_mul(16384)
            .and_then(|n| {
                capacity
                    .checked_mul(std::mem::size_of::<QueuedInputBatch>() * 4)
                    .and_then(|c| n.checked_add(c))
            })
            .and_then(|n| n.checked_add(4096))
            .ok_or_else(|| QueryError::Execution(format!("{label} queue metadata overflow")))?;
        Some(Arc::new(pool.allocate(bytes)?))
    } else {
        None
    };
    let (tx, receiver) = tokio::sync::mpsc::channel(capacity);
    let mut producers = tokio::task::JoinSet::new();
    // Audited resident pipelines and explicit prepared descriptors promise a
    // copied-output bound AND pool-independent future pulls.
    // A fixed envelope avoids per-batch contention among our own queued slots.
    // It does not admit upstream expression scratch or retained source storage.
    let max_slots = partitions.min(rayon::current_num_threads().max(1));
    let declared_bound = bound;
    let parallel = bound.and_then(|bytes| {
        (2..=max_slots).rev().find_map(|slots| {
            let total = bytes.checked_mul(slots)?;
            pool.try_allocate(total)
                .map(|guard| (slots, bytes, Arc::new(guard)))
        })
    });
    let (slots, bound, envelope) = if admitted_mode {
        (max_slots, None, None)
    } else {
        match parallel {
            Some((slots, bytes, guard)) => (slots, Some(bytes), Some(guard)),
            None => (1, None, None),
        }
    };
    let queue_id = preparation_trace.as_ref().map(|t| t.id);
    if let Some(t) = preparation_trace.as_mut() {
        t.detail = serde_json::json!({"label":label,"operator":input.name(),"partitions":partitions,
            "prepared":prepared_mode,"admitted_buffers":admitted_mode,"declared_bound":declared_bound,"slots":slots,
            "max_slots":max_slots,"envelope_bytes":bound.and_then(|b| b.checked_mul(slots))});
    }
    InputTrace::finish(&mut preparation_trace);
    let demand = Arc::new(tokio::sync::Semaphore::new(slots));
    for part in 0..partitions {
        let input = input.clone();
        let tx = tx.clone();
        let pool = pool.clone();
        let demand = demand.clone();
        let envelope = envelope.clone();
        let queue_metadata = queue_metadata.clone();
        let prepared_stream = prepared_streams.as_mut().and_then(Iterator::next);
        producers.spawn(async move {
            let mut trace = queue_id.and_then(|id| {
                InputTrace::new("queue_producer", || {
                    serde_json::json!({
                        "queue":id,"partition":part,"rows":0,"batches":0,"charged_copy_bytes":0,
                        "permit_ms":0.0,"poll_ms":0.0,"charge_ms":0.0,"copy_ms":0.0,"send_ms":0.0
                    })
                })
            });
            // Retain even when parked before a pull; Drop cancels asynchronously.
            let _envelope = envelope;
            let _queue_metadata = queue_metadata;
            let tick = trace.as_ref().map(|_| std::time::Instant::now());
            let mut stream = match prepared_stream {
                Some(stream) => stream,
                None => input.execute(part).await?,
            };
            input_trace_add_ms(&mut trace, "execute_ms", tick);
            drop(input);
            loop {
                // Backpressure precedes upstream polling: no newly pulled
                // batch waits unreserved for another queued batch to drain.
                // Unknown layouts retain one demand; proven layouts use the
                // fixed pre-admitted parallel slots.
                let tick = trace.as_ref().map(|_| std::time::Instant::now());
                let permit =
                    demand.clone().acquire_owned().await.map_err(|_| {
                        QueryError::Execution(format!("{label} demand gate closed"))
                    })?;
                input_trace_add_ms(&mut trace, "permit_ms", tick);
                let tick = trace.as_ref().map(|_| std::time::Instant::now());
                let Some(batch) = stream.try_next().await? else {
                    input_trace_add_ms(&mut trace, "poll_ms", tick);
                    InputTrace::finish(&mut trace);
                    return Ok(());
                };
                input_trace_add_ms(&mut trace, "poll_ms", tick);
                let tick = trace.as_ref().map(|_| std::time::Instant::now());
                let bytes = if admitted_mode {
                    0
                } else {
                    owned_input_batch_charge(&batch)
                        .map_err(|error| QueryError::Execution(format!("{label}: {error}")))?
                };
                // Preserve the owned-pool refusal grammar used by the cap
                // harness; the denying child or ancestor is already named.
                let reservation = if admitted_mode {
                    None
                } else if let Some(limit) = bound {
                    if bytes > limit {
                        return Err(QueryError::Execution(format!(
                            "{label} copy-bound contract violated: actual {bytes}, bound {limit}"
                        )));
                    }
                    None
                } else {
                    Some(pool.allocate(bytes)?)
                };
                input_trace_add_ms(&mut trace, "charge_ms", tick);
                if let Some(t) = trace.as_mut() {
                    for (key, n) in [
                        ("rows", batch.num_rows()),
                        ("batches", 1),
                        ("charged_copy_bytes", bytes),
                    ] {
                        t.detail[key] = serde_json::json!(t.detail[key]
                            .as_u64()
                            .unwrap_or(0)
                            .saturating_add(n as u64));
                    }
                }
                let tick = trace.as_ref().map(|_| std::time::Instant::now());
                let batch = if admitted_mode {
                    batch
                } else {
                    own_input_batch(batch)?
                };
                input_trace_add_ms(&mut trace, "copy_ms", tick);
                let queued = QueuedInputBatch {
                    batch,
                    _reservation: reservation,
                    _demand: permit,
                };
                // Admission includes the pending-send value; never await budget
                // availability, which could deadlock against downstream state.
                let tick = trace.as_ref().map(|_| std::time::Instant::now());
                let sent = tx.send(queued).await;
                input_trace_add_ms(&mut trace, "send_ms", tick);
                if sent.is_err() {
                    return Ok(());
                }
            }
        });
    }
    drop(tx);
    Ok(Box::pin(InputQueueStream {
        receiver,
        producers,
        label,
        finished: false,
        pending_error: None,
        envelope,
        _queue_metadata: queue_metadata,
    }))
}

fn input_trace_add_ms(trace: &mut Option<InputTrace>, key: &str, tick: Option<std::time::Instant>) {
    if let (Some(t), Some(tick)) = (trace.as_mut(), tick) {
        t.detail[key] = serde_json::json!(
            t.detail[key].as_f64().unwrap_or(0.0) + tick.elapsed().as_secs_f64() * 1000.0
        );
    }
}

/// A closed merge channel is not proof of successful blocking-task completion.
/// Retain/poll its handle so a panic cannot turn a valid prefix into clean EOF.
struct OwnedTaskOutputStream {
    label: &'static str,
    receiver: tokio::sync::mpsc::Receiver<Result<RecordBatch>>,
    worker: Option<tokio::task::JoinHandle<()>>,
    finished: bool,
}
impl OwnedTaskOutputStream {
    fn stop(&mut self) {
        self.finished = true;
        self.receiver.close();
        while self.receiver.try_recv().is_ok() {}
        if let Some(worker) = self.worker.take() {
            worker.abort();
        }
        // Async producers stop cooperatively on Tokio cancellation. Started
        // blocking tasks cannot be aborted: their captured file owners survive
        // until their closed-receiver sink stops and their closure exits.
    }
}
impl Drop for OwnedTaskOutputStream {
    fn drop(&mut self) {
        self.stop();
    }
}
impl futures::Stream for OwnedTaskOutputStream {
    type Item = Result<RecordBatch>;
    fn poll_next(
        self: std::pin::Pin<&mut Self>,
        cx: &mut std::task::Context<'_>,
    ) -> std::task::Poll<Option<Self::Item>> {
        use std::task::Poll;
        let this = self.get_mut();
        if this.finished {
            return Poll::Ready(None);
        }
        if let Some(worker) = &mut this.worker {
            match std::future::Future::poll(std::pin::Pin::new(worker), cx) {
                Poll::Ready(Ok(())) => this.worker = None,
                Poll::Ready(Err(error)) => {
                    let error =
                        QueryError::Execution(format!("{} task failed: {error}", this.label));
                    this.stop();
                    return Poll::Ready(Some(Err(error)));
                }
                Poll::Pending => (),
            }
        }
        match this.receiver.poll_recv(cx) {
            Poll::Ready(Some(Ok(batch))) => Poll::Ready(Some(Ok(batch))),
            Poll::Ready(Some(Err(error))) => {
                this.stop();
                Poll::Ready(Some(Err(error)))
            }
            Poll::Ready(None) if this.worker.is_none() => {
                this.finished = true;
                Poll::Ready(None)
            }
            // Worker poll registered a waker. Sender drop can precede panic or
            // normal return; wait without self-waking or reporting early EOF.
            Poll::Ready(None) | Poll::Pending => Poll::Pending,
        }
    }
}

/// Stop at the exact fetch boundary without another upstream poll. Dropping
/// the task stream here closes its receiver while the worker keeps file ownership.
struct SortFetchStream {
    input: Option<OwnedTaskOutputStream>,
    remaining: usize,
}
impl futures::Stream for SortFetchStream {
    type Item = Result<RecordBatch>;
    fn poll_next(
        self: std::pin::Pin<&mut Self>,
        cx: &mut std::task::Context<'_>,
    ) -> std::task::Poll<Option<Self::Item>> {
        use std::task::Poll;
        let this = self.get_mut();
        if this.remaining == 0 {
            this.input.take();
            return Poll::Ready(None);
        }
        let Some(input) = this.input.as_mut() else {
            return Poll::Ready(None);
        };
        match futures::Stream::poll_next(std::pin::Pin::new(input), cx) {
            Poll::Ready(Some(Ok(batch))) => {
                let batch = truncate_batches_to_limit(vec![batch], this.remaining)
                    .pop()
                    .expect("positive fetch retains its batch");
                this.remaining -= batch.num_rows();
                if this.remaining == 0 {
                    this.input.take();
                }
                Poll::Ready(Some(Ok(batch)))
            }
            Poll::Ready(Some(Err(error))) => {
                this.input.take();
                Poll::Ready(Some(Err(error)))
            }
            Poll::Ready(None) => {
                this.input.take();
                Poll::Ready(None)
            }
            Poll::Pending => Poll::Pending,
        }
    }
}

// ============================================================================
// Spillable Hash Join
// ============================================================================

/// Hash join execution operator with spilling support
///
/// When memory limits are exceeded, this operator partitions data by hash
/// and spills partitions to disk. During the probe phase, spilled partitions
/// are processed one at a time.
pub struct SpillableHashJoinExec {
    /// Runtime probe-scan key filter (Inner joins), passed to the delegate.
    pub probe_runtime_filter: Option<crate::physical::operators::SharedRuntimeFilter>,
    /// Which equi pair the runtime filter applies to.
    pub probe_runtime_filter_pair: usize,
    /// Join-output retention mask (see HashJoinExec::retained).
    pub retained: Option<Vec<bool>>,
    left: Arc<dyn PhysicalOperator>,
    right: Arc<dyn PhysicalOperator>,
    on: Vec<(Expr, Expr)>,
    join_type: JoinType,
    schema: SchemaRef,
    /// The FULL (left ++ right, nullability-adjusted) output schema, kept
    /// unpruned even after `set_retained` narrows `schema` — the spill
    /// path's outer-join emission (spill-boundaries task 003) needs the
    /// declared type of every column, including the pruned ones, to
    /// NULL-extend the non-preserved side before applying the mask.
    full_schema: SchemaRef,
    memory_pool: SharedMemoryPool,
    config: ExecutionConfig,
    /// When true, build hash table from right side (smaller) for Left joins.
    build_right: bool,
    /// Optional join filter (e.g., for Semi/Anti with additional predicates)
    filter: Option<Expr>,
    /// Cached build decision — computed once, shared across all partition executions
    build_decision: OnceCell<BuildDecision>,
    /// join-spill-streaming task 003: explicit spilled-partition read-back
    /// parallelism (K), overriding both the machine-derived default and
    /// `QE_SPILL_JOIN_PARALLELISM`. `None` = derive (see `plan_phase_b`).
    /// Set by tests/harnesses that need a deterministic K.
    spill_join_parallelism: Option<usize>,
}

impl fmt::Debug for SpillableHashJoinExec {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SpillableHashJoinExec")
            .field("join_type", &self.join_type)
            .field("on", &self.on)
            .field("build_right", &self.build_right)
            .finish()
    }
}

/// Cached decision about whether the build side fits in memory
enum BuildDecision {
    /// Build fits in memory — use cached HashJoinExec for parallel probe
    InMemory(Arc<crate::physical::operators::HashJoinExec>),
    /// Build exceeds memory — spill path (only partition 0 processes).
    ///
    /// spill-join-correctness-2 epic, task 002: `partitions`/`spilled` are
    /// the ALREADY hash-partitioned, already-spilled-where-needed build
    /// side, computed ONCE by `compute_build_decision`'s bounded,
    /// incremental collection — never a full, unbounded, unpartitioned
    /// copy of the build side (that was the collect-fully-then-decide OOM
    /// hole this task fixes). Kept for EVERY execution of partition 0 — an
    /// operator above may legitimately execute its child more than once
    /// (the fused streaming aggregate drains, aborts, and re-executes).
    /// The old `Mutex<Option<..>>::take()` shape handed the second
    /// execution an EMPTY build side, which joined to zero rows and
    /// returned them as the answer; this shape avoids that the same way
    /// the old flat-`Vec` one did, just without the flat Vec. `spill_dir`
    /// is REUSED, not recreated, across repeat calls, so
    /// `spilled[..].build_file` stays valid — it is removed exactly once,
    /// when the LAST holder of the `Arc<SpillState>` goes away (see
    /// `SpillState`'s own `Drop`).
    ///
    /// oom-safety-hardening task 007: `tables` are the in-memory
    /// partitions' join hash tables, built ONCE by
    /// `build_with_partitioning`'s hash-table budgeting pass under DIRECT
    /// memory accounting (`hash_table_memory_bytes`) — the resident set's
    /// batches PLUS tables together fit under `memory_limit *
    /// spill_threshold` by construction, with partitions evicted to disk
    /// when the running total would cross it. Memoizing them here (rather
    /// than rebuilding per `execute_spill_path` call, as before) means the
    /// bound holds for the operator's whole lifetime and a repeat
    /// execution never re-pays the build. Before this task these tables
    /// were rebuilt per call with ZERO accounting at ~10-20x the batch
    /// bytes the spill decision budgeted (task 001's root-caused hole:
    /// measured 15-24x budget overshoot, ≥7.3GB at a 500MB budget).
    ///
    /// join-spill-streaming task 002: the state sits behind an `Arc` so
    /// that each execution's OUTPUT STREAM — a `'static` producer task
    /// that yields batches as they are produced instead of a
    /// materialized `Vec` — can own a handle to it without borrowing
    /// `&self` (a `RecordBatchStream` cannot).
    Spill(Arc<SpillState>),
}

/// Own a newly-created operator spill directory across initialization and work.
/// Move this guard with background work; never delete files before its last use.
struct SpillDirectoryOwner(Option<PathBuf>);

impl SpillDirectoryOwner {
    fn create(path: PathBuf) -> Result<Self> {
        // The configured parent already exists. Never adopt/delete a stale or
        // foreign existing directory merely because its counter-based name fits.
        std::fs::create_dir(&path).map_err(|error| {
            QueryError::Execution(format!("Failed to create spill directory: {error}"))
        })?;
        Ok(Self(Some(path)))
    }
    fn into_path(mut self) -> PathBuf {
        self.0.take().expect("initialization directory owned")
    }
}
impl Drop for SpillDirectoryOwner {
    fn drop(&mut self) {
        if let Some(path) = &self.0 {
            let _ = std::fs::remove_dir_all(path);
        }
    }
}

/// The memoized, already-partitioned build side of a spilling join (see
/// `BuildDecision::Spill`): the resident partitions and their hash tables,
/// the spilled partitions' build files, and the directory holding them.
///
/// join-spill-streaming task 002: shared (`Arc`) between the operator's
/// memoized decision and every in-flight output stream's producer task.
/// The spill directory is removed in THIS type's `Drop` — i.e. by whichever
/// holder is dropped LAST — so a producer that is still reading build files
/// (or writing its per-call probe files) can never have the directory
/// pulled out from under it by the operator being dropped first, and an
/// operator that outlives an abandoned stream still cleans up exactly
/// once. Per-call probe files (`probe_<call>_<idx>.parquet`) are removed
/// by their own producer at the end of the call; anything left over (a
/// producer killed mid-flight) goes with the directory here.
struct SpillState {
    partitions: Vec<Option<BuildPartition>>,
    tables: Vec<Option<HashMap<JoinKey, Vec<HashEntry>>>>,
    spilled: Vec<Option<SpilledPartition>>,
    spill_dir: PathBuf,
}

impl Drop for SpillState {
    fn drop(&mut self) {
        let _ = std::fs::remove_dir_all(&self.spill_dir);
    }
}

impl SpillableHashJoinExec {
    pub fn new(
        left: Arc<dyn PhysicalOperator>,
        right: Arc<dyn PhysicalOperator>,
        on: Vec<(Expr, Expr)>,
        join_type: JoinType,
        memory_pool: SharedMemoryPool,
        config: ExecutionConfig,
    ) -> Self {
        let left_schema = left.schema();
        let right_schema = right.schema();

        let schema = match join_type {
            JoinType::Semi | JoinType::Anti => left_schema,
            _ => {
                let left_nullable = matches!(join_type, JoinType::Right | JoinType::Full);
                let right_nullable = matches!(join_type, JoinType::Left | JoinType::Full);

                let left_fields = left_schema.fields().iter().map(|f| {
                    if left_nullable && !f.is_nullable() {
                        Arc::new(f.as_ref().clone().with_nullable(true))
                    } else {
                        f.clone()
                    }
                });

                let right_fields = right_schema.fields().iter().map(|f| {
                    if right_nullable && !f.is_nullable() {
                        Arc::new(f.as_ref().clone().with_nullable(true))
                    } else {
                        f.clone()
                    }
                });

                let fields: Vec<_> = left_fields.chain(right_fields).collect();
                Arc::new(Schema::new(fields))
            }
        };

        Self {
            left,
            right,
            on,
            join_type,
            full_schema: schema.clone(),
            schema,
            memory_pool,
            config,
            build_right: false,
            filter: None,
            build_decision: OnceCell::new(),
            spill_join_parallelism: None,
            probe_runtime_filter: None,
            probe_runtime_filter_pair: 0,
            retained: None,
        }
    }

    /// join-spill-streaming task 003: force the spilled-partition read-back
    /// parallelism K (`Some(n)`, clamped to the number of spilled
    /// partitions) instead of deriving it from the machine and the budget.
    /// The chunk table budget is `threshold / K` either way, so a larger K
    /// never raises the operator's transient memory — it only splits it.
    pub fn with_spill_join_parallelism(mut self, k: Option<usize>) -> Self {
        self.spill_join_parallelism = k.filter(|&k| k >= 1);
        self
    }

    /// Set build_right flag: when true, build hash table from right side.
    pub fn with_build_right(mut self, build_right: bool) -> Self {
        self.build_right = build_right;
        self
    }

    /// Set join filter (for Semi/Anti joins with additional predicates).
    pub fn with_filter(mut self, filter: Option<Expr>) -> Self {
        self.filter = filter;
        self
    }

    /// Join-output retention mask over the FULL (left ++ right) column
    /// order: false = no ancestor references the column (ON-only keys, or a
    /// filter-only column nothing downstream selects), so it is dropped
    /// from the output schema and never gathered. Set by the planner's
    /// usage analysis for Inner/Left/Right/Full joins whose filter (if any)
    /// contains no subquery.
    ///
    /// Gate condition — MUST stay identical to `HashJoinExec::set_retained`
    /// and the planner's `analyze_join_output_usage` (three gates that must
    /// move in lockstep). This wrapper delegates to an inner `HashJoinExec`
    /// for the in-memory build path and forwards this exact mask to it
    /// (`hj.set_retained(self.retained.clone())`); if that gate ever
    /// disagreed with this one, `self.schema()` would report a narrower
    /// width than the delegate's stream actually produces — a silent
    /// schema/column-count mismatch a unit test on `HashJoinExec` alone
    /// cannot catch (see the dedicated Spillable-level regression test).
    pub fn set_retained(&mut self, mask: Option<Vec<bool>>) {
        if let Some(m) = &mask {
            let type_ok = matches!(
                self.join_type,
                JoinType::Inner | JoinType::Left | JoinType::Right | JoinType::Full
            );
            let filter_ok = self
                .filter
                .as_ref()
                .map(|f| !f.contains_subquery())
                .unwrap_or(true);
            if !type_ok || !filter_ok || m.len() != self.schema.fields().len() {
                return;
            }
            let fields: Vec<_> = self
                .schema
                .fields()
                .iter()
                .zip(m)
                .filter(|(_, keep)| **keep)
                .map(|(f, _)| f.clone())
                .collect();
            self.schema = Arc::new(Schema::new(fields));
        }
        self.retained = mask;
    }
}

/// State for a hash partition during the build phase
struct BuildPartition {
    batches: Vec<RecordBatch>,
    memory_bytes: usize,
    /// Total rows across `batches` — kept incrementally so the spill
    /// path's hash-table accounting (`predicted_hash_table_bytes`,
    /// oom-safety-hardening task 007) never rescans batches to price the
    /// table this partition's rows imply.
    rows: usize,
}

impl BuildPartition {
    fn new() -> Self {
        Self {
            batches: Vec::new(),
            memory_bytes: 0,
            rows: 0,
        }
    }

    fn add_batch(&mut self, batch: RecordBatch) {
        self.memory_bytes += estimate_batch_size(&batch);
        self.rows += batch.num_rows();
        self.batches.push(batch);
    }

    /// What keeping this partition resident REALLY costs once its join
    /// hash table exists: batch bytes plus the (conservative, worst-case
    /// all-unique-keys) predicted table bytes. oom-safety-hardening task
    /// 007: this is the charge the streaming build loop accounts against
    /// the memory threshold — before it, only `memory_bytes` was charged,
    /// so resident partitions were kept AT the threshold in batch bytes
    /// and the 10-20x table amplification landed entirely on top,
    /// unbudgeted (the measured 15-24x overshoot of task 001's repros).
    fn charged_bytes(&self, key_cols: usize) -> usize {
        self.memory_bytes + predicted_hash_table_bytes(self.rows, key_cols)
    }
}

/// State for a spilled partition — build-side info only.
///
/// spill-join-correctness-2 epic, task 002: this struct is now memoized
/// ONCE (inside `BuildDecision::Spill`, computed by
/// `SpillableHashJoinExec::compute_build_decision`) and reused across
/// every call to `execute_spill_path` (an operator above may legitimately
/// execute its child more than once — see `BuildDecision::Spill`'s own
/// doc comment). Probe-side spill info is call-specific (each call
/// re-probes and writes fresh probe spill files, since the probe side is
/// re-executed every call), so it is threaded through
/// `execute_spill_path`/`process_spilled_partition` as separate, per-call
/// parameters instead of being stored here — storing it here would have
/// meant either clobbering it on a second call before the first call's
/// results were done using it, or leaking a `Mutex`/interior-mutability
/// dance this file doesn't otherwise need.
struct SpilledPartition {
    build_file: PathBuf,
    build_rows: usize,
    /// Diagnostic only (`QE_SPILL_DEBUG`), spill-join-correctness-2 epic
    /// task 001: a checksum of the join-key values as WRITTEN to
    /// `build_file`, computed from the ORIGINAL in-memory batch(es) at
    /// spill time via the exact same `extract_join_key` code path
    /// `build_hash_table`/`partition_batch_by_hash` use. Compared in
    /// `process_spilled_partition` against the checksum RECOMPUTED from
    /// the data read back off `build_file` -- directly testing whether the
    /// spill/unspill round trip preserves join-key data, the same shape of
    /// bug as Trino's PR #25892 (spill wrote with one hash generator,
    /// unspill read with a different one). `None` when `QE_SPILL_DEBUG` is
    /// unset (never computed, zero cost).
    build_key_checksum: Option<KeyChecksum>,
}

#[async_trait]
impl PhysicalOperator for SpillableHashJoinExec {
    fn runtime_filter_target(
        &self,
        output: usize,
    ) -> Option<crate::physical::plan::RuntimeFilterTarget> {
        let index = super::hash_join::runtime_filter_probe_ordinal(
            self.join_type,
            self.build_right,
            self.retained.as_deref(),
            self.left.schema().fields().len(),
            self.right.schema().fields().len(),
            output,
        )?;
        let probe = if self.build_right {
            &self.left
        } else {
            &self.right
        };
        probe.runtime_filter_target(index)
    }
    fn schema(&self) -> SchemaRef {
        self.schema.clone()
    }

    fn children(&self) -> Vec<Arc<dyn PhysicalOperator>> {
        vec![self.left.clone(), self.right.clone()]
    }

    fn output_partitions(&self) -> usize {
        match self.join_type {
            JoinType::Semi | JoinType::Anti => 1,
            _ => {
                let probe_side = if self.build_right || matches!(self.join_type, JoinType::Right) {
                    &self.left
                } else {
                    &self.right
                };
                probe_side.output_partitions().max(1)
            }
        }
    }

    async fn prepare_admitted_queue_input(
        &self,
        pool: crate::execution::SharedMemoryPool,
    ) -> Result<Option<crate::physical::PreparedAdmittedInput>> {
        if !matches!(
            self.join_type,
            JoinType::Inner | JoinType::Left | JoinType::Right | JoinType::Full
        ) {
            return Ok(None);
        }
        let swapped = self.build_right || self.join_type == JoinType::Right;
        let build = if swapped { &self.right } else { &self.left };
        let decision = self
            .build_decision
            .get_or_try_init(|| self.compute_build_decision(build, swapped))
            .await?;
        match decision {
            BuildDecision::InMemory(join) => join.prepare_admitted_queue_input(pool).await,
            BuildDecision::Spill(_) => Ok(None),
        }
    }

    async fn prepare_queue_input(&self) -> Result<Option<crate::physical::PreparedQueueInput>> {
        if self.join_type != JoinType::Inner {
            return Ok(None);
        }
        let (build, _probe, swapped) = if self.build_right {
            (&self.right, &self.left, true)
        } else {
            (&self.left, &self.right, false)
        };
        // Decide the outer build before asking the in-memory delegate to
        // recursively prepare its probe. Spilled output remains unsupported.
        let decision = self
            .build_decision
            .get_or_try_init(|| self.compute_build_decision(build, swapped))
            .await?;
        match decision {
            BuildDecision::InMemory(join) => join.prepare_queue_input().await,
            // Computing the decision owns initialization files; never start
            // the spill output producer merely to decline this capability.
            BuildDecision::Spill(_) => Ok(None),
        }
    }

    async fn execute(&self, partition: usize) -> Result<RecordBatchStream> {
        crate::physical::check_partition(self, partition)?;

        // Determine build and probe sides
        let (build_side, probe_side, swapped) =
            if self.build_right || matches!(self.join_type, JoinType::Right) {
                (&self.right, &self.left, true)
            } else {
                (&self.left, &self.right, false)
            };

        // Get or compute the build decision (computed ONCE, shared across all
        // partitions). spill-join-correctness-2 epic, task 002:
        // `compute_build_decision` collects the build side INCREMENTALLY,
        // checking the running size against the spill threshold as batches
        // arrive, instead of the old `collect_input_partitions_concurrently`
        // -then-check order that could OOM on an oversized build side before
        // the spill decision ever ran. See that method's own doc comment.
        let decision = self
            .build_decision
            .get_or_try_init(|| self.compute_build_decision(build_side, swapped))
            .await?;

        match decision {
            BuildDecision::InMemory(hash_join) => {
                // Delegate directly — HashJoinExec has its own OnceCell for the hash table
                hash_join.execute(partition).await
            }
            BuildDecision::Spill(state) => {
                // Spill path runs everything through partition 0
                if partition > 0 {
                    return Ok(Box::pin(stream::empty()));
                }
                self.execute_spill_path(state, probe_side, swapped).await
            }
        }
    }

    fn name(&self) -> &str {
        "SpillableHashJoin"
    }
}

impl SpillableHashJoinExec {
    /// Compute the (memoized-once) build decision: does the build side fit
    /// in memory, or must it spill?
    ///
    /// spill-join-correctness-2 epic, task 002: this is the actual fix for
    /// the collect-fully-then-decide OOM hole. The OLD code called
    /// `collect_input_partitions_concurrently`, which fully drains the
    /// ENTIRE build side into one flat `Vec<RecordBatch>`, and only THEN
    /// compared its total size against `memory_limit * spill_threshold` —
    /// so an oversized build side could exhaust real memory during that
    /// initial collection, before the spill decision (or anything it would
    /// have triggered) ever ran.
    ///
    /// This is Photon's (Databricks, SIGMOD'22) two-phase reservation
    /// pattern, adapted rather than ported literally: phase 1 below
    /// ("reserve, possibly spill") streams the build side in via
    /// `stream_merge_input_partitions` and tracks a running size total,
    /// batch by batch, checking it against `memory_threshold` as each batch
    /// arrives — never buffering more than ~`memory_threshold` bytes of
    /// flat, unpartitioned build-side data. The MOMENT the running total
    /// would cross the threshold, phase 2 ("guaranteed spill-free
    /// allocation" becomes "hand off to the bounded, spill-capable
    /// structure") takes over: everything collected so far, plus the
    /// crossing batch, plus the rest of the stream, feeds into
    /// `build_with_partitioning`'s existing hash-partition-and-spill-
    /// as-needed bookkeeping — the exact same mechanism the rest of the
    /// spill path already used, just entered mid-stream instead of only
    /// after a full prior collection. If the whole build side is consumed
    /// without ever crossing the threshold, this is the ordinary "fits in
    /// memory" case — nothing about that path's cost or shape changes
    /// versus before.
    /// Enter the disk-spill branch: validate join shape (INNER/SEMI/ANTI),
    /// create the spill directory, and hand `prefix` (already
    /// flat-collected batches) chained with `rest` (whatever remains of the
    /// build stream — empty if the stream was already exhausted) to
    /// `build_with_partitioning`. Factored out of `compute_build_decision`
    /// (spill-join-correctness-2 epic, task 003) so its two crossing sites
    /// — the ordinary mid-stream crossing (organic memory pressure or
    /// `QE_SPILL_CHAOS_FORCE_SPILL`, `rest` non-empty) and the
    /// end-of-stream chaos fallback (`rest` always empty, see that
    /// fallback's own comment) — share one copy of the INNER/filter guard
    /// and spill-directory setup rather than risking drift between two
    /// copies.
    async fn finish_via_spill(
        &self,
        prefix: Vec<RecordBatch>,
        rest: RecordBatchStream,
        build_keys: &[Expr],
        sj_trace: bool,
    ) -> Result<BuildDecision> {
        // spill-join-correctness-3 task 004: SEMI and ANTI take the spill
        // path (existence semantics survive hash partitioning — see
        // `probe_with_spilling` / `process_spilled_partition`).
        // spill-boundaries task 002: an ON-clause filter no longer refuses
        // — it is applied to every candidate pair where the pair is formed
        // (`visit_candidate_pairs`). Task 003: LEFT/RIGHT/FULL spill too —
        // the SEMI/ANTI match bitmaps, per preserved side, plus
        // NULL-extended emission of the unmatched rows (see
        // `SpillJoinCtx::probe_emit` / `build_emit`). What remains refused,
        // by name: CROSS (no key to partition on), SINGLE and MARK (the
        // DelimJoin-only types).
        if !matches!(
            self.join_type,
            JoinType::Inner
                | JoinType::Left
                | JoinType::Right
                | JoinType::Full
                | JoinType::Semi
                | JoinType::Anti
        ) {
            return Err(QueryError::Execution(format!(
                "{} join build side exceeds the memory budget, but the join spill \
                 path supports INNER, LEFT, RIGHT, FULL, SEMI and ANTI joins only \
                 (CROSS/SINGLE/MARK are not spillable). Raise the memory limit for \
                 this query.",
                self.join_type
            )));
        }

        self.config.ensure_spill_dir()?;
        let spill_id = SPILL_COUNTER.fetch_add(1, Ordering::Relaxed);
        let spill_dir = self.config.spill_path.join(format!("join_0_{}", spill_id));
        // Declared before the nested build future: its local writers/stream
        // drop before this guard cleans the initialization directory.
        let init_directory = SpillDirectoryOwner::create(spill_dir.clone())?;

        if sj_trace {
            let prefix_rows: usize = prefix.iter().map(|b| b.num_rows()).sum();
            eprintln!(
                "[sj-trace] compute_build_decision spill_dir={:?} entering build_with_partitioning prefix_rows={}",
                spill_dir, prefix_rows
            );
        }

        // Phase 2: guaranteed-spill-free (for what's ALREADY collected)
        // allocation becomes "hand off to the bounded, spill-capable
        // structure" — everything gathered so far (`prefix`) plus whatever
        // remains of the stream (`rest`), through the SAME
        // hash-partition-and-spill-as-needed bookkeeping the rest of the
        // spill path already used. Nothing collected in phase 1 is thrown
        // away or re-pulled from the source.
        let combined: RecordBatchStream =
            Box::pin(stream::iter(prefix.into_iter().map(Ok)).chain(rest));

        let (partitions, tables, spilled) = self
            .build_with_partitioning(combined, build_keys, &spill_dir)
            .await?;

        Ok(BuildDecision::Spill(Arc::new(SpillState {
            partitions,
            tables,
            spilled,
            spill_dir: init_directory.into_path(),
        })))
    }

    async fn compute_build_decision(
        &self,
        build_side: &Arc<dyn PhysicalOperator>,
        swapped: bool,
    ) -> Result<BuildDecision> {
        let memory_threshold =
            (self.config.memory_limit as f64 * self.config.spill_threshold) as usize;
        let (on_left, on_right): (Vec<Expr>, Vec<Expr>) = self.on.iter().cloned().unzip();
        let build_keys: Vec<Expr> = if swapped { on_right } else { on_left };

        let sj_trace = std::env::var("QE_SPILL_DEBUG").is_ok();
        // spill-join-correctness-2 epic, task 003: see this file's own
        // "Fault injection: forced spill" module doc comment.
        let chaos_after_batches = chaos_force_spill_after_batches();

        // Phase 1: reserve, possibly spill. Stream in, tracking a running
        // total as batches arrive from every build-side input partition
        // concurrently (the streaming analog of
        // `collect_input_partitions_concurrently`'s own parallel-drain
        // benefit for a pipeline-breaking operator's collect side).
        let mut build_stream =
            stream_merge_input_partitions(build_side, &self.memory_pool, "join build input queue")
                .await?;
        let mut flat_batches: Vec<RecordBatch> = Vec::new();
        let mut flat_size: usize = 0;
        let mut flat_rows: usize = 0;

        while let Some(batch) = build_stream.try_next().await? {
            let batch_size = estimate_batch_size(&batch);
            let next_size = flat_size
                .checked_add(batch_size)
                .ok_or_else(|| QueryError::Execution("join build payload size overflow".into()))?;
            let next_rows = flat_rows
                .checked_add(batch.num_rows())
                .ok_or_else(|| QueryError::Execution("join build row count overflow".into()))?;
            let index_size = if build_keys.is_empty() {
                0
            } else {
                super::hash_join::join_index_storage_bound(next_rows)?
            };
            let working_size = next_size
                .checked_add(index_size)
                .ok_or_else(|| QueryError::Execution("join build working size overflow".into()))?;
            let chaos_crossing = chaos_after_batches
                .map(|n| flat_batches.len() >= n)
                .unwrap_or(false);
            // The batch is already in memory when this decision is made: record it.
            self.memory_pool.observe(next_size);
            if working_size > memory_threshold || chaos_crossing {
                if chaos_crossing && sj_trace {
                    eprintln!(
                        "[sj-trace] compute_build_decision CHAOS forcing spill (QE_SPILL_CHAOS_FORCE_SPILL) at flat_batches={} flat_size={}",
                        flat_batches.len(),
                        flat_size
                    );
                }
                // Crossed the threshold: this build side must spill. Checked
                // HERE, at the crossing point, rather than only once a full
                // collection would have finished — an oversized non-INNER
                // or filtered join now fails loudly this much earlier too,
                // without ever needing to pull in the rest of the build
                // side first.
                let prefix: Vec<RecordBatch> = flat_batches
                    .into_iter()
                    .chain(std::iter::once(batch))
                    .collect();
                return self
                    .finish_via_spill(prefix, build_stream, &build_keys, sj_trace)
                    .await;
            }
            flat_size = next_size;
            flat_rows = next_rows;
            self.memory_pool.observe(flat_size);
            flat_batches.push(batch);
        }

        // spill-join-correctness-2 epic, task 003: the build stream is now
        // fully exhausted without ever organically crossing
        // `memory_threshold`. If `QE_SPILL_CHAOS_FORCE_SPILL` requested a
        // crossing point (a batch count) the stream never actually reached
        // — e.g. a small/single-batch build side, common for this
        // mechanism's own differential-testing harness fixtures — force it
        // HERE instead of silently falling through to "fits in memory,"
        // which would make the WHEN lever a no-op for exactly the small
        // inputs it's most useful against. `rest` is empty (nothing left
        // to chain; the stream is already drained).
        if chaos_after_batches.is_some() && !flat_batches.is_empty() {
            if sj_trace {
                eprintln!(
                    "[sj-trace] compute_build_decision CHAOS forcing spill at end-of-stream (requested crossing point never reached; flat_batches={} flat_size={})",
                    flat_batches.len(),
                    flat_size
                );
            }
            return self
                .finish_via_spill(
                    flat_batches,
                    Box::pin(stream::empty()),
                    &build_keys,
                    sj_trace,
                )
                .await;
        }

        // Payload plus the vectorized index costing bound stayed below the
        // threshold. This is not admission proof for every build allocation:
        // the delegate still reserves actual index/row-store storage, and
        // evaluated keys and generic-map paths have separate resource costs.
        // Preserve the producer's declared domain and column identity. Physical
        // batches may encode those values as dictionaries (and change codebooks
        // between batches); MemoryTableExec already adapts actual output types.
        // A materialization must not turn that encoding into the join's schema.
        let build_schema = build_side.schema();
        let build_mem = Arc::new(crate::physical::operators::MemoryTableExec::new(
            "join_build",
            build_schema,
            flat_batches,
            None,
        ));
        let (left, right): (Arc<dyn PhysicalOperator>, Arc<dyn PhysicalOperator>) = if swapped {
            (self.left.clone(), build_mem as Arc<dyn PhysicalOperator>)
        } else {
            (build_mem as Arc<dyn PhysicalOperator>, self.right.clone())
        };
        let hash_join = if self.filter.is_some() {
            let mut hj = crate::physical::operators::HashJoinExec::with_filter(
                left,
                right,
                self.on.clone(),
                self.join_type,
                self.filter.clone(),
            )
            .with_build_right(self.build_right)
            .with_memory_pool(self.memory_pool.clone());
            hj.probe_runtime_filter = self.probe_runtime_filter.clone();
            hj.probe_runtime_filter_pair = self.probe_runtime_filter_pair;
            hj.set_retained(self.retained.clone());
            Arc::new(hj)
        } else {
            let mut hj = crate::physical::operators::HashJoinExec::new(
                left,
                right,
                self.on.clone(),
                self.join_type,
            )
            .with_build_right(self.build_right)
            .with_memory_pool(self.memory_pool.clone());
            hj.probe_runtime_filter = self.probe_runtime_filter.clone();
            hj.probe_runtime_filter_pair = self.probe_runtime_filter_pair;
            hj.set_retained(self.retained.clone());
            Arc::new(hj)
        };
        Ok(BuildDecision::InMemory(hash_join))
    }

    /// Execute the spill path when build side exceeds memory limit.
    /// Only called from partition 0. May be called MORE THAN ONCE for the
    /// same logical query execution (an operator above may legitimately
    /// execute its child more than once — see `BuildDecision::Spill`'s own
    /// doc comment); `state` is the memoized `BuildDecision`, computed
    /// exactly once regardless of how many times this function runs.
    ///
    /// join-spill-streaming task 002: returns a stream that yields matched
    /// batches AS THEY ARE PRODUCED. Before this task the whole join
    /// output was materialized into a `Vec<RecordBatch>` first (Q9 at
    /// SF=100/1G: 1,333,333,320 rows in memory, ~1,396s of a ~1,400s
    /// query) — the output, like the probe side before task 001, was
    /// unbounded by `--memory-limit`. The shape: a `tokio::spawn`ed
    /// producer task (`run_spill_join_producer`) owning an
    /// `Arc<SpillState>` + a cloned `SpillJoinCtx`, sending through a
    /// bounded mpsc channel of `SPILL_JOIN_OUTPUT_CHANNEL_CAPACITY`
    /// batches → `ReceiverStream`. Phase A consumes the probe stream:
    /// resident partitions are probed per batch and their output sent at
    /// once, probe rows routed to spilled partitions are appended to this
    /// call's own probe spill files; phase A' (build-side SEMI/ANTI) sends
    /// the resident partitions' final emission once the probe stream
    /// ends; phase B processes the spilled partitions, sending per chunk
    /// (INNER, build-side SEMI/ANTI) or per partition (probe-side
    /// SEMI/ANTI bitmap). Errors travel through the same channel. Peak
    /// in-flight memory is the channel's capacity plus what the probe
    /// merge channel holds — never the output. A consumer that drops the
    /// stream early stops the producer at its next send (or at the next
    /// probe batch, via `is_closed`).
    ///
    /// Trace semantics (`QE_SPILL_DEBUG`) are preserved: START is printed
    /// here, "probe collected" once the probe stream has been consumed,
    /// DONE (with the same counters) when the producer finishes — i.e.
    /// at the END of the output stream now, not before its first batch.
    async fn execute_spill_path(
        &self,
        state: &Arc<SpillState>,
        probe_side: &Arc<dyn PhysicalOperator>,
        swapped: bool,
    ) -> Result<RecordBatchStream> {
        // QE_SPILL_DEBUG tracing (task 001, spill-join-correctness epic):
        // if some caller ever invokes this more than once for what should
        // be a single logical query execution (e.g.
        // `SpillableHashAggregateExec`'s fused-streaming path aborting and
        // falling back to `collect_input_partitions_concurrently`, which
        // re-executes its input), this prints TWO START/DONE pairs for the
        // SAME join instead of one — direct evidence, not inference. Zero
        // cost when unset beyond one env lookup per call.
        let sj_trace = std::env::var("QE_SPILL_DEBUG").is_ok();
        // Per-call id: names this call's probe spill files so an earlier,
        // abandoned call's still-running producer can never share a file
        // with a repeat call (task 002), and tags its trace lines.
        let call_id = next_sj_trace_id();

        let (on_left, on_right): (Vec<Expr>, Vec<Expr>) = self.on.iter().cloned().unzip();
        let (build_keys, probe_keys) = if swapped {
            (on_right, on_left)
        } else {
            (on_left, on_right)
        };

        // oom-safety-hardening task 007: the in-memory partitions' hash
        // tables are NO LONGER built here. They are built exactly once, in
        // `build_with_partitioning`'s hash-table budgeting pass, under
        // direct memory accounting (resident batches + measured table
        // bytes <= memory_threshold, partitions evicted when the total
        // would cross), and memoized in the build decision alongside the
        // batches they index. This function's old unbudgeted rebuild loop
        // was task 001's root-caused accounting hole (~10-20x the batch
        // bytes the spill decision budgeted, measured 15-24x overshoot).

        if sj_trace {
            let in_mem_parts = state.partitions.iter().filter(|p| p.is_some()).count();
            let spilled_parts = state.spilled.iter().filter(|p| p.is_some()).count();
            let in_mem_build_rows: usize = state
                .partitions
                .iter()
                .flatten()
                .flat_map(|p| p.batches.iter())
                .map(|b| b.num_rows())
                .sum();
            let spilled_build_rows: usize =
                state.spilled.iter().flatten().map(|sp| sp.build_rows).sum();
            eprintln!(
                "[sj-trace] execute_spill_path START spill_dir={:?} in_memory_partitions={} (rows={}) spilled_partitions={} (rows={}) call_id={}",
                state.spill_dir, in_mem_parts, in_mem_build_rows, spilled_parts, spilled_build_rows, call_id
            );
        }

        // join-spill-streaming task 001: the probe side is STREAMED through
        // the partition writers, never collected. Before this the whole
        // probe side was drained into one `Vec<RecordBatch>` first (Q9 at
        // SF=100/1G: 333M rows; the SF=100-class harness join peaked at
        // 5.3-8.0GB against a 256MB budget — the probe side, not the
        // build side, set the peak). `stream_merge_input_partitions` is the
        // same bounded-channel merge the build side already uses: every
        // probe input partition is drained concurrently, a handful of
        // batches can be in flight at once, never the whole side.
        let probe_partitions = probe_side.output_partitions().max(1);
        let probe_stream =
            stream_merge_input_partitions(probe_side, &self.memory_pool, "join probe input queue")
                .await?;

        let (build_side, _) = if swapped {
            (&self.right, &self.left)
        } else {
            (&self.left, &self.right)
        };
        let filter = self.filter.as_ref().map(|f| {
            Arc::new(PairFilter::new(
                f.clone(),
                &build_side.schema(),
                &probe_side.schema(),
                swapped,
            ))
        });
        let ctx = SpillJoinCtx {
            build_keys,
            probe_keys,
            join_type: self.join_type,
            swapped,
            schema: self.schema.clone(),
            full_schema: self.full_schema.clone(),
            retained: self.retained.clone(),
            filter,
            memory_threshold: (self.config.memory_limit as f64 * self.config.spill_threshold)
                as usize,
            memory_pool: self.memory_pool.clone(),
            sj_trace,
            call_id,
            probe_partitions,
            parallelism_override: self.spill_join_parallelism.or_else(|| {
                std::env::var("QE_SPILL_JOIN_PARALLELISM")
                    .ok()
                    .and_then(|v| v.trim().parse::<usize>().ok())
                    .filter(|&k| k >= 1)
            }),
        };
        let state = Arc::clone(state);
        let (tx, rx) =
            tokio::sync::mpsc::channel::<Result<RecordBatch>>(SPILL_JOIN_OUTPUT_CHANNEL_CAPACITY);
        let worker = tokio::spawn(async move {
            let sj_t0 = std::time::Instant::now();
            match run_spill_join_producer(&state, &ctx, probe_stream, &tx).await {
                Ok(Some(stats)) => {
                    // Build-side spill files under `spill_dir` are NOT
                    // removed here — they are memoized in the operator's
                    // build decision and must survive a possible repeat
                    // call (see `SpillState`'s own doc comment).
                    if sj_trace {
                        eprintln!(
                            "[sj-trace] execute_spill_path DONE spill_dir={:?} in_memory_matched={} spilled_matched={} total_matched={} elapsed={:?} call_id={}",
                            state.spill_dir,
                            stats.in_memory_matched,
                            stats.spilled_matched,
                            stats.in_memory_matched + stats.spilled_matched,
                            sj_t0.elapsed(),
                            call_id
                        );
                    }
                }
                Ok(None) => {
                    if sj_trace {
                        eprintln!(
                            "[sj-trace] execute_spill_path ABANDONED spill_dir={:?} (output stream dropped by its consumer) elapsed={:?} call_id={}",
                            state.spill_dir,
                            sj_t0.elapsed(),
                            call_id
                        );
                    }
                }
                Err(e) => {
                    // The consumer sees the error as the stream's next item
                    // (or nothing, if it already went away).
                    let _ = tx.send(Err(e)).await;
                }
            }
        });
        Ok(Box::pin(OwnedTaskOutputStream {
            label: "spill join output",
            receiver: rx,
            worker: Some(worker),
            finished: false,
        }))
    }

    /// Evict partition `idx`'s currently-resident batches to disk right now,
    /// opening/reusing its spill writer — the exact mechanism
    /// `build_with_partitioning`'s own memory-pressure eviction used
    /// inline before spill-join-correctness-2 epic task 003 pulled it out,
    /// so the fault-injection path (which forces a CHOSEN partition to disk
    /// regardless of memory pressure, see this file's own "Fault injection:
    /// forced spill" module doc comment) shares it byte-for-byte with the
    /// organic memory-pressure path rather than risking behavioral drift
    /// between two separate copies of the same spill-write logic. No-op
    /// (returns 0 freed bytes) if the partition is already empty/spilled.
    /// Only ever called on a still-resident partition by either caller, so
    /// `spilled[idx]` is always `None` on entry here in practice — asserted
    /// implicitly by simply overwriting it, matching the pre-refactor code's
    /// own assumption.
    fn evict_build_partition_to_disk(
        &self,
        idx: usize,
        partitions: &mut [Option<BuildPartition>],
        spilled: &mut [Option<SpilledPartition>],
        spill_writers: &mut [Option<ArrowWriter<File>>],
        spill_dir: &PathBuf,
        build_keys: &[Expr],
        sj_trace: bool,
    ) -> Result<usize> {
        let Some(part) = partitions[idx].take() else {
            return Ok(0);
        };
        if part.batches.is_empty() {
            // spill-join-correctness-3 task 004: nothing to evict — keep
            // the partition RESIDENT. Before this guard an empty partition
            // (reachable when the very first build batch alone exceeds the
            // threshold, so `find_largest_partition` runs while every
            // partition is still empty) was turned into a `SpilledPartition`
            // whose `build_file` is only ever created by a later append; if
            // no build row ever routed there, read-back failed with
            // "Failed to open parquet file ... No such file or directory".
            // Dense join keys populate all 64 partitions so this never
            // surfaced; sparse keys (few distinct values) expose it on
            // INNER as well as SEMI/ANTI — pinned by
            // `inner_spill_with_sparse_build_keys_survives_empty_partition_eviction`.
            partitions[idx] = Some(part);
            return Ok(0);
        }
        let path = spill_dir.join(format!("build_{}.parquet", idx));
        let mut write_checksum = if sj_trace {
            Some(KeyChecksum::default())
        } else {
            None
        };
        for b in &part.batches {
            append_batch_streaming(&mut spill_writers[idx], &path, b)?;
            if let Some(cs) = write_checksum.as_mut() {
                cs.accumulate(batch_key_checksum(b, build_keys)?);
            }
        }

        self.memory_pool.record_spill(part.memory_bytes);
        let freed = part.memory_bytes;

        spilled[idx] = Some(SpilledPartition {
            build_file: path,
            build_rows: part.batches.iter().map(|b| b.num_rows()).sum(),
            build_key_checksum: write_checksum,
        });

        Ok(freed)
    }

    #[allow(clippy::type_complexity)]
    async fn build_with_partitioning(
        &self,
        mut build_stream: RecordBatchStream,
        build_keys: &[Expr],
        spill_dir: &PathBuf,
    ) -> Result<(
        Vec<Option<BuildPartition>>,
        Vec<Option<HashMap<JoinKey, Vec<HashEntry>>>>,
        Vec<Option<SpilledPartition>>,
    )> {
        // spill-join-correctness-2 epic, task 001: checked once per call,
        // matching this file's own established convention (no `OnceLock`
        // caching, re-read fresh — see `gpu.rs`'s `QE_GPU_DEBUG` precedent).
        let sj_trace = std::env::var("QE_SPILL_DEBUG").is_ok();
        // spill-join-correctness-2 epic, task 003: see this file's own
        // "Fault injection: forced spill" module doc comment.
        let chaos_partitions = chaos_force_spill_partitions();
        let mut partitions: Vec<Option<BuildPartition>> = (0..NUM_PARTITIONS)
            .map(|_| Some(BuildPartition::new()))
            .collect();
        let mut spilled: Vec<Option<SpilledPartition>> =
            (0..NUM_PARTITIONS).map(|_| None).collect();
        // One incrementally-written Parquet file per spilled partition, kept
        // OPEN for the whole build phase and closed exactly once at the end.
        // This replaces the old per-append read-entire-file+rewrite+rename
        // (`append_to_parquet`), whose cost grew with the total data already
        // spilled for that partition — see `append_batch_streaming`'s doc
        // comment (spill-join-correctness epic, task 002).
        let mut spill_writers: Vec<Option<ArrowWriter<File>>> =
            (0..NUM_PARTITIONS).map(|_| None).collect();
        // oom-safety-hardening task 007: `total_memory` charges each
        // resident partition its batch bytes PLUS the predicted bytes of
        // the join hash table those rows imply
        // (`BuildPartition::charged_bytes`), so residency settles where
        // batches AND tables genuinely fit — not where batch bytes alone
        // hit the threshold with the 10-20x table amplification unbudgeted
        // on top (task 001's root-caused hole). The later budgeting pass
        // (`budget_partition_hash_tables`) then replaces the prediction
        // with DIRECT measurement of the built tables and evicts any
        // residual overshoot.
        let key_cols = build_keys.len();
        let mut total_memory: usize = 0;
        let memory_threshold =
            (self.config.memory_limit as f64 * self.config.spill_threshold) as usize;

        while let Some(batch) = build_stream.try_next().await? {
            let batch_charge = estimate_batch_size(&batch)
                + predicted_hash_table_bytes(batch.num_rows(), key_cols);

            // Check if we need to spill
            // The batch is already in memory when this decision is made: record it.
            self.memory_pool.observe(total_memory + batch_charge);
            if total_memory + batch_charge > memory_threshold {
                // Find the largest partition to spill
                if let Some(idx) = find_largest_partition(&partitions) {
                    // Uncharge the partition's FULL charge (batches +
                    // predicted table), matching what was added below.
                    let charge = partitions[idx]
                        .as_ref()
                        .map(|p| p.charged_bytes(key_cols))
                        .unwrap_or(0);
                    self.evict_build_partition_to_disk(
                        idx,
                        &mut partitions,
                        &mut spilled,
                        &mut spill_writers,
                        spill_dir,
                        build_keys,
                        sj_trace,
                    )?;
                    total_memory = total_memory.saturating_sub(charge);
                }
            }

            // Partition the batch by hash
            let partitioned = partition_batch_by_hash(&batch, build_keys, NUM_PARTITIONS)?;

            for (idx, part_batch) in partitioned.into_iter().enumerate() {
                if let Some(pb) = part_batch {
                    let pb_charge = estimate_batch_size(&pb)
                        + predicted_hash_table_bytes(pb.num_rows(), key_cols);

                    if let Some(ref mut part) = partitions[idx] {
                        part.add_batch(pb);
                        total_memory += pb_charge;
                        self.memory_pool.observe(total_memory);
                        // spill-join-correctness-2 epic, task 003: force
                        // this partition to disk right now if a fault-
                        // injection trial chose it, regardless of memory
                        // pressure — see `evict_build_partition_to_disk`'s
                        // own doc comment.
                        if chaos_partitions.as_ref().is_some_and(|s| s.contains(idx)) {
                            let charge = partitions[idx]
                                .as_ref()
                                .map(|p| p.charged_bytes(key_cols))
                                .unwrap_or(0);
                            self.evict_build_partition_to_disk(
                                idx,
                                &mut partitions,
                                &mut spilled,
                                &mut spill_writers,
                                spill_dir,
                                build_keys,
                                sj_trace,
                            )?;
                            total_memory = total_memory.saturating_sub(charge);
                        }
                    } else if let Some(ref mut sp) = spilled[idx] {
                        // Append to spilled partition as one more row group
                        // in the already-open writer — O(batch), never
                        // re-reads or rewrites this partition's prior data.
                        append_batch_streaming(&mut spill_writers[idx], &sp.build_file, &pb)?;
                        // join-spill-streaming task 003: keep `build_rows`
                        // exact across appends (before, it froze at the
                        // eviction-time count — a diagnostic-only field
                        // until `plan_phase_b` started sizing K from the
                        // largest spilled partition).
                        sp.build_rows += pb.num_rows();
                        if sj_trace {
                            let cs = batch_key_checksum(&pb, build_keys)?;
                            sp.build_key_checksum
                                .get_or_insert_with(KeyChecksum::default)
                                .accumulate(cs);
                        }
                    }
                }
            }
        }

        // oom-safety-hardening task 007: hash-table budgeting pass. The
        // streaming loop above bounded resident batch bytes + PREDICTED
        // table bytes at `memory_threshold`; this pass builds the actual
        // tables, while `partitions`/`spilled`/`spill_writers` are still
        // mutable, and replaces the prediction with DIRECT measurement:
        // resident batch bytes + measured table bytes must stay under the
        // SAME `memory_threshold`, with partitions evicted to disk (the
        // existing eviction mechanism, byte-for-byte) when the running
        // total would cross it. Before this task the tables were built
        // later, in `execute_spill_path`, with zero accounting at ~10-20x
        // the batch bytes the spill decision budgeted (task 001's
        // root-caused hole, measured 15-24x budget overshoot).
        let tables = self.budget_partition_hash_tables(
            &mut partitions,
            &mut spilled,
            &mut spill_writers,
            spill_dir,
            build_keys,
            sj_trace,
        )?;

        close_spill_writers(spill_writers)?;
        Ok((partitions, tables, spilled))
    }

    /// oom-safety-hardening task 007: decide which resident build
    /// partitions may keep an in-memory join hash table, under DIRECT
    /// memory accounting, evicting the rest to disk.
    ///
    /// The running total starts at the sum of all resident partitions'
    /// batch bytes and must never cross `memory_limit * spill_threshold`
    /// — the same formula every other spill decision in this file uses.
    /// (The streaming loop already bounded batch bytes + PREDICTED table
    /// bytes at the same threshold; this pass swaps the prediction for
    /// direct measurement.) Per resident partition, largest first
    /// (keeping the largest resident minimizes both spill I/O and the
    /// biggest per-partition transient read-back cost later):
    ///
    /// 1. a conservative PREDICTED table cost
    ///    (`predicted_hash_table_bytes`, worst-case all-unique keys) gates
    ///    whether the table is even built — so a table that provably
    ///    cannot fit is never materialized at all;
    /// 2. if built, the table's REAL footprint is measured
    ///    (`hash_table_memory_bytes` — real capacity, real per-key Vec
    ///    buffers, real String bytes) and charged against the budget; a
    ///    measured crossing (possible when the prediction under-counts,
    ///    e.g. long String keys) drops the table and evicts the partition,
    ///    bounding the transient overshoot at one partition's table.
    ///
    /// Eviction reuses `evict_build_partition_to_disk` unchanged (same
    /// writer, same spill files, same checksum path), so probe routing is
    /// untouched: an evicted partition simply becomes one more
    /// `SpilledPartition`, exactly as if the streaming loop's own
    /// memory-pressure eviction had chosen it.
    #[allow(clippy::too_many_arguments, clippy::type_complexity)]
    fn budget_partition_hash_tables(
        &self,
        partitions: &mut [Option<BuildPartition>],
        spilled: &mut [Option<SpilledPartition>],
        spill_writers: &mut [Option<ArrowWriter<File>>],
        spill_dir: &PathBuf,
        build_keys: &[Expr],
        sj_trace: bool,
    ) -> Result<Vec<Option<HashMap<JoinKey, Vec<HashEntry>>>>> {
        let memory_threshold =
            (self.config.memory_limit as f64 * self.config.spill_threshold) as usize;
        let mut tables: Vec<Option<HashMap<JoinKey, Vec<HashEntry>>>> =
            (0..NUM_PARTITIONS).map(|_| None).collect();

        // Resident batch bytes are already in memory and stay charged for
        // the operator's lifetime (memoized in the build decision).
        let mut running: usize = partitions
            .iter()
            .flatten()
            .map(|p| p.memory_bytes)
            .sum::<usize>();
        let mut table_bytes_total: usize = 0;
        let mut evicted_for_tables = 0usize;

        let mut order: Vec<usize> = (0..partitions.len())
            .filter(|&i| {
                partitions[i]
                    .as_ref()
                    .is_some_and(|p| !p.batches.is_empty())
            })
            .collect();
        order.sort_by_key(|&i| {
            std::cmp::Reverse(partitions[i].as_ref().map(|p| p.memory_bytes).unwrap_or(0))
        });

        for idx in order {
            let rows: usize = partitions[idx].as_ref().map(|p| p.rows).unwrap_or(0);
            let predicted = predicted_hash_table_bytes(rows, build_keys.len());
            if running + predicted > memory_threshold {
                running = running.saturating_sub(self.evict_build_partition_to_disk(
                    idx,
                    partitions,
                    spilled,
                    spill_writers,
                    spill_dir,
                    build_keys,
                    sj_trace,
                )?);
                evicted_for_tables += 1;
                continue;
            }
            let table = build_hash_table(
                &partitions[idx]
                    .as_ref()
                    .expect("resident partition filtered above")
                    .batches,
                build_keys,
            )?;
            let actual = hash_table_memory_bytes(&table);
            if running + actual > memory_threshold {
                drop(table);
                running = running.saturating_sub(self.evict_build_partition_to_disk(
                    idx,
                    partitions,
                    spilled,
                    spill_writers,
                    spill_dir,
                    build_keys,
                    sj_trace,
                )?);
                evicted_for_tables += 1;
                continue;
            }
            running += actual;
            table_bytes_total += actual;
            self.memory_pool.observe(table_bytes_total);
            tables[idx] = Some(table);
        }

        if sj_trace {
            let resident = tables.iter().filter(|t| t.is_some()).count();
            let resident_batch_bytes: usize =
                partitions.iter().flatten().map(|p| p.memory_bytes).sum();
            eprintln!(
                "[sj-trace] budget_partition_hash_tables resident_partitions={} table_bytes={} batch_bytes={} running_total={} threshold={} evicted_for_table_budget={}",
                resident,
                table_bytes_total,
                resident_batch_bytes,
                running,
                memory_threshold,
                evicted_for_tables
            );
        }

        Ok(tables)
    }
}

// ============================================================================
// Spill-path output stream producer (join-spill-streaming task 002)
// ============================================================================

/// Bound on the join spill path's OUTPUT channel: at most this many
/// produced-but-unconsumed batches exist at once. Small on purpose — the
/// point of the stream is that the output is never materialized; a few
/// batches of slack are enough to keep the producer from stalling on
/// every send.
const SPILL_JOIN_OUTPUT_CHANNEL_CAPACITY: usize = 8;

type SpillJoinOutputSender = tokio::sync::mpsc::Sender<Result<RecordBatch>>;

/// Everything the output stream's producer task needs from the operator,
/// cloned once per `execute_spill_path` call (the stream is `'static` and
/// cannot borrow `&self`). Cheap: key expressions, a schema handle, the
/// retention mask, the threshold, and the memory-pool `Arc`.
#[derive(Clone)]
struct SpillJoinCtx {
    build_keys: Vec<Expr>,
    probe_keys: Vec<Expr>,
    join_type: JoinType,
    swapped: bool,
    schema: SchemaRef,
    /// The unpruned left ++ right output schema (see
    /// `SpillableHashJoinExec::full_schema`).
    full_schema: SchemaRef,
    retained: Option<Vec<bool>>,
    /// spill-boundaries task 002: the ON-clause predicate (compiled once
    /// per call), applied to every candidate pair. `None` = key equality
    /// alone decides.
    filter: Option<Arc<PairFilter>>,
    memory_threshold: usize,
    memory_pool: SharedMemoryPool,
    sj_trace: bool,
    /// Per-call id (see `execute_spill_path`): names this call's probe
    /// spill files and tags its trace lines.
    call_id: u64,
    /// Diagnostic only (the "probe collected" trace line).
    probe_partitions: usize,
    /// join-spill-streaming task 003: explicit K for phase B (operator
    /// setting first, then `QE_SPILL_JOIN_PARALLELISM`), else derived.
    parallelism_override: Option<usize>,
}

/// What the spill path emits for the rows of one side once their match
/// status is final (spill-boundaries task 003, generalizing the SEMI/ANTI
/// `want` flag): nothing (the side is not an output side on its own),
/// the matched rows alone (SEMI), the unmatched rows alone (ANTI), or the
/// unmatched rows NULL-extended with the other side's columns (the
/// preserved side of an outer join).
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum RowEmit {
    None,
    Matched,
    Unmatched,
    UnmatchedNullExtended,
}

impl SpillJoinCtx {
    /// Matched (build row, probe row) pairs are output rows: INNER and the
    /// outer joins. SEMI/ANTI emit one side's rows by match status only.
    fn emit_pairs(&self) -> bool {
        matches!(
            self.join_type,
            JoinType::Inner | JoinType::Left | JoinType::Right | JoinType::Full
        )
    }
    /// The PROBE side is preserved (its unmatched rows are output,
    /// NULL-extended): LEFT with build = right, RIGHT with build = left,
    /// FULL either way.
    fn preserve_probe(&self) -> bool {
        match self.join_type {
            JoinType::Left => self.swapped,
            JoinType::Right => !self.swapped,
            JoinType::Full => true,
            _ => false,
        }
    }
    /// The BUILD side is preserved: LEFT with build = left, RIGHT with
    /// build = right, FULL either way.
    fn preserve_build(&self) -> bool {
        match self.join_type {
            JoinType::Left => !self.swapped,
            JoinType::Right => self.swapped,
            JoinType::Full => true,
            _ => false,
        }
    }
    /// A per-probe-row match bitmap is needed: probe-side-output SEMI/ANTI
    /// (spill-join-correctness-3 task 004) or a preserved probe side.
    fn probe_bitmap(&self) -> bool {
        (matches!(self.join_type, JoinType::Semi | JoinType::Anti) && self.swapped)
            || self.preserve_probe()
    }
    /// A per-build-row match bitmap is needed: build-side-output SEMI/ANTI
    /// or a preserved build side.
    fn build_bitmap(&self) -> bool {
        (matches!(self.join_type, JoinType::Semi | JoinType::Anti) && !self.swapped)
            || self.preserve_build()
    }
    /// What to emit for a probe batch once its bitmap is final.
    fn probe_emit(&self) -> RowEmit {
        match (self.join_type, self.swapped) {
            (JoinType::Semi, true) => RowEmit::Matched,
            (JoinType::Anti, true) => RowEmit::Unmatched,
            _ if self.preserve_probe() => RowEmit::UnmatchedNullExtended,
            _ => RowEmit::None,
        }
    }
    /// What to emit for a build partition / chunk once its bitmap is final.
    fn build_emit(&self) -> RowEmit {
        match (self.join_type, self.swapped) {
            (JoinType::Semi, false) => RowEmit::Matched,
            (JoinType::Anti, false) => RowEmit::Unmatched,
            _ if self.preserve_build() => RowEmit::UnmatchedNullExtended,
            _ => RowEmit::None,
        }
    }
    /// This call's probe spill file for partition `idx` — PER CALL (the
    /// probe side is re-executed and re-partitioned on every call, and an
    /// earlier call's producer may still be draining when a repeat call
    /// starts), never shared.
    fn probe_file(&self, spill_dir: &Path, idx: usize) -> PathBuf {
        spill_dir.join(format!("probe_{}_{}.parquet", self.call_id, idx))
    }
}

/// Counters for the DONE trace.
struct SpillJoinStats {
    in_memory_matched: usize,
    spilled_matched: usize,
}

/// What phase A leaves for phase B: this call's probe spill files (one per
/// spilled partition that received probe rows), their write-time key
/// checksums, and the counters — plus whether the consumer went away
/// mid-phase (in which case nothing more is produced, but the files still
/// need removing).
struct ProbePhase {
    /// Diagnostic: size of this call's phase-A pool.
    phase_a_threads: usize,
    probe_spill_files: Vec<Option<PathBuf>>,
    probe_key_checksums: Vec<Option<KeyChecksum>>,
    probe_rows: usize,
    in_memory_matched: usize,
    abandoned: bool,
    file_owner: Arc<ProbeSpillFiles>,
}

/// Send one output batch; `false` means the consumer dropped the stream.
async fn emit_join_batch(
    tx: &SpillJoinOutputSender,
    batch: RecordBatch,
    counter: &mut usize,
) -> bool {
    *counter += batch.num_rows();
    tx.send(Ok(batch)).await.is_ok()
}

/// Per-call files outlive every writer and reader, including blocking work
/// whose awaiting async producer has been cancelled. Retaining the build state
/// also prevents its directory from disappearing before these users finish.
struct ProbeSpillFiles {
    state: Arc<SpillState>,
    call_id: u64,
}
impl Drop for ProbeSpillFiles {
    fn drop(&mut self) {
        for idx in 0..NUM_PARTITIONS {
            let path = self
                .state
                .spill_dir
                .join(format!("probe_{}_{}.parquet", self.call_id, idx));
            let _ = std::fs::remove_file(path);
        }
    }
}

/// The producer behind `execute_spill_path`'s output stream: phase A
/// (`probe_with_spilling`), then phase B (`process_spilled_partition` per
/// spilled partition). Returns `Ok(None)` when the consumer dropped the
/// stream before the end (nothing is wrong; the remaining work is simply
/// not done), `Ok(Some(stats))` on completion. This call's probe spill
/// files are removed on every exit path; the build files stay (memoized).
async fn run_spill_join_producer(
    state: &Arc<SpillState>,
    ctx: &SpillJoinCtx,
    probe_stream: RecordBatchStream,
    tx: &SpillJoinOutputSender,
) -> Result<Option<SpillJoinStats>> {
    let phase_a = probe_with_spilling(state, ctx, probe_stream, tx).await?;
    if phase_a.abandoned {
        return Ok(None);
    }
    if ctx.sj_trace {
        // Same line as before task 001, now printed once the probe stream
        // has been consumed (the count is accumulated as batches flow, not
        // from a materialized Vec).
        eprintln!(
            "[sj-trace] execute_spill_path probe collected: probe_partitions={} probe_rows={} (streamed, phase_a_threads={}) call_id={}",
            ctx.probe_partitions, phase_a.probe_rows, phase_a.phase_a_threads, ctx.call_id
        );
    }

    // Phase B: spilled partitions — this call's own freshly-written probe
    // spill file (if any) for each partition, paired with the MEMOIZED
    // build spill file from `state.spilled`. The read-back is CPU + disk
    // work with no await points, so it runs on the blocking pool and
    // pushes batches through `blocking_send` (bounded, back-pressured).
    let outcome = process_spilled_partitions(state, ctx, &phase_a, tx).await;
    let spilled_matched = match outcome? {
        Some(n) => n,
        None => return Ok(None),
    };
    Ok(Some(SpillJoinStats {
        in_memory_matched: phase_a.in_memory_matched,
        spilled_matched,
    }))
}

/// Upper bound on phase B's parallelism K (join-spill-streaming task 003):
/// beyond this the read-back is I/O- and channel-bound, and every job's
/// chunk budget (`threshold / K`) gets small enough that chunk count — and
/// with it the number of probe passes — climbs for no wall-time gain.
const SPILL_JOIN_MAX_PARALLELISM: usize = 8;

/// Probe batches probed together inside one read-back job (rayon
/// `par_iter` over the group): 16 × 8,192-row batches = ~131k probe rows
/// in memory per job at a time, whatever the probe partition's size.
const PROBE_GROUP_BATCHES: usize = 16;

/// Rows per batch when a spill file is streamed back (matches the writer's
/// `SPILL_WRITER_ROW_GROUP_ROWS` in `append_batch_streaming`, so batch
/// boundaries are the row groups' and a re-read of the same file yields
/// the same batches in the same order — the probe-side SEMI/ANTI bitmaps
/// below index probe batches by position across re-reads).
const SPILL_READ_BATCH_ROWS: usize = 8_192;

/// The chosen shape of phase B for one call.
struct PhaseBPlan {
    spilled_count: usize,
    /// Concurrent spilled partitions.
    k: usize,
    /// Per-job chunk budget = `memory_threshold / k` — the K jobs SHARE the
    /// operator's one threshold; never `K × threshold`.
    chunk_budget: usize,
    k_hw: usize,
    k_budget: usize,
}

/// join-spill-streaming task 003: pick K.
///
/// `k_hw` = min(available_parallelism, `SPILL_JOIN_MAX_PARALLELISM`).
/// `k_budget` = threshold / (largest spilled partition's predicted table
/// bytes): a partition whose table alone is bigger than the whole budget
/// is read back in ≥ K× more chunks at budget/K, and each chunk re-probes
/// the entire probe partition, so K jobs do K× the lookups in the same
/// wall time — splitting the budget buys nothing there, and the CPU is
/// better spent on the parallel probe WITHIN the partition. K =
/// min(k_hw, k_budget, spilled) ≥ 1, unless overridden (operator setting,
/// then `QE_SPILL_JOIN_PARALLELISM`), in which case the override is only
/// clamped to the spilled count.
fn plan_phase_b(
    spilled: &[Option<SpilledPartition>],
    key_cols: usize,
    memory_threshold: usize,
    parallelism_override: Option<usize>,
) -> PhaseBPlan {
    let spilled_count = spilled.iter().filter(|s| s.is_some()).count();
    let largest_rows = spilled
        .iter()
        .flatten()
        .map(|s| s.build_rows)
        .max()
        .unwrap_or(0);
    let largest_charge = predicted_hash_table_bytes(largest_rows, key_cols).max(1);
    let k_hw = std::thread::available_parallelism()
        .map(|n| n.get())
        .unwrap_or(1)
        .clamp(1, SPILL_JOIN_MAX_PARALLELISM);
    let k_budget = (memory_threshold / largest_charge).max(1);
    let k = parallelism_override
        .unwrap_or_else(|| k_hw.min(k_budget))
        .min(spilled_count.max(1))
        .max(1);
    PhaseBPlan {
        spilled_count,
        k,
        chunk_budget: (memory_threshold / k).max(1),
        k_hw,
        k_budget,
    }
}

/// One finished read-back job: (partition idx, rows sent, consumer still
/// there).
type PhaseBJobResult = Result<(usize, usize, bool)>;

fn absorb_phase_b_result(
    joined: std::result::Result<PhaseBJobResult, tokio::task::JoinError>,
    spilled_matched: &mut usize,
    alive: &mut bool,
    first_err: &mut Option<QueryError>,
) {
    match joined {
        Ok(Ok((_idx, sent, job_alive))) => {
            *spilled_matched += sent;
            if !job_alive {
                *alive = false;
            }
        }
        Ok(Err(e)) => {
            if first_err.is_none() {
                *first_err = Some(e);
            }
        }
        Err(join_err) => {
            if first_err.is_none() {
                *first_err = Some(QueryError::Execution(format!(
                    "join spill read-back task failed: {join_err}"
                )));
            }
        }
    }
}

/// Phase B driver (join-spill-streaming task 003): up to K spilled
/// partitions at once, each on the blocking pool with a chunk budget of
/// `threshold / K`, every partition's batches yielded as its job produces
/// them (output order is irrelevant: set semantics). Returns the number of
/// matched rows sent, or `None` if the consumer went away. On an error the
/// first one is returned once the in-flight jobs have drained (a job
/// cannot be aborted mid-run; each stops at its next send once the
/// receiver is gone).
async fn process_spilled_partitions(
    state: &Arc<SpillState>,
    ctx: &SpillJoinCtx,
    phase_a: &ProbePhase,
    tx: &SpillJoinOutputSender,
) -> Result<Option<usize>> {
    let plan = plan_phase_b(
        &state.spilled,
        ctx.build_keys.len(),
        ctx.memory_threshold,
        ctx.parallelism_override,
    );
    if plan.spilled_count == 0 {
        return Ok(Some(0));
    }
    if ctx.sj_trace {
        eprintln!(
            "[sj-trace] execute_spill_path phase B: spilled_partitions={} parallelism K={} (hw={} budget={} override={:?}) chunk_table_budget={} threshold={} call_id={}",
            plan.spilled_count,
            plan.k,
            plan.k_hw,
            plan.k_budget,
            ctx.parallelism_override,
            plan.chunk_budget,
            ctx.memory_threshold,
            ctx.call_id
        );
    }
    let mut jobs: tokio::task::JoinSet<PhaseBJobResult> = tokio::task::JoinSet::new();
    let mut spilled_matched = 0usize;
    let mut alive = true;
    let mut first_err: Option<QueryError> = None;
    for idx in 0..NUM_PARTITIONS {
        if state.spilled[idx].is_none() {
            continue;
        }
        while jobs.len() >= plan.k {
            match jobs.join_next().await {
                Some(j) => {
                    absorb_phase_b_result(j, &mut spilled_matched, &mut alive, &mut first_err)
                }
                None => break,
            }
        }
        if tx.is_closed() {
            alive = false;
        }
        if !alive || first_err.is_some() {
            break;
        }
        let state2 = Arc::clone(state);
        let ctx2 = ctx.clone();
        let tx2 = tx.clone();
        let probe_file = phase_a.probe_spill_files[idx].clone();
        let probe_key_checksum = phase_a.probe_key_checksums[idx];
        let chunk_budget = plan.chunk_budget;
        let file_owner = phase_a.file_owner.clone();
        jobs.spawn_blocking(move || -> PhaseBJobResult {
            let _file_owner = file_owner;
            let sp = state2.spilled[idx]
                .as_ref()
                .expect("spilled partition checked above");
            let mut sent = 0usize;
            let mut job_alive = true;
            let result = {
                let mut sink = |batch: RecordBatch| -> bool {
                    sent += batch.num_rows();
                    job_alive = tx2.blocking_send(Ok(batch)).is_ok();
                    job_alive
                };
                process_spilled_partition(
                    &ctx2,
                    sp,
                    probe_file.as_ref(),
                    probe_key_checksum,
                    idx,
                    chunk_budget,
                    &mut sink,
                )
            };
            result.map(|()| (idx, sent, job_alive))
        });
    }
    while let Some(j) = jobs.join_next().await {
        absorb_phase_b_result(j, &mut spilled_matched, &mut alive, &mut first_err);
    }
    if let Some(e) = first_err {
        return Err(e);
    }
    if !alive {
        return Ok(None);
    }
    Ok(Some(spilled_matched))
}

/// Probe rows gathered before phase A hands a group to the blocking pool
/// (join-spill-streaming task 003): the group is re-sliced into
/// `SPILL_READ_BATCH_ROWS`-row pieces and partitioned + probed with rayon,
/// then written to the per-partition spill writers in parallel across
/// partitions. Bounds phase A's transient at ~one group of probe rows plus
/// its partitioned copy, whatever the upstream batch size is.
const PHASE_A_GROUP_ROWS: usize = 262_144;
/// Companion cap on batches per group (a source emitting tiny batches).
const PHASE_A_GROUP_BATCHES: usize = 64;

/// Upper bound on phase A's OWN rayon pool (join-spill-streaming task
/// 003), and the budget each worker must be backed by. Measured on the
/// 600M-row harness `semi-join` leg with a 1s RSS sampler, same code and
/// data: on the global 32-thread pool phase A peaked at 583MB vs 207MB
/// single-threaded and the excess PERSISTED into phase B; with
/// `RAYON_NUM_THREADS=8` it was 279MB and with `MIMALLOC_PURGE_DELAY=0`
/// 305MB — i.e. ~12MB per thread of freed memory the allocator keeps per
/// thread that touched a group's short-lived allocations, not live data.
/// So the pool is sized by the OPERATOR'S budget, not the machine: one
/// worker per `PHASE_A_BYTES_PER_WORKER` of `memory_threshold`, at least
/// 1, at most `SPILL_JOIN_PHASE_A_MAX_THREADS` (Q9 at 1G: 8; a 256MB
/// budget: 3; 64M: 1), and it is created per call and dropped when phase
/// A ends so its threads exit and release what they held before phase B
/// runs. Eight threads keep phase A's wall time within ~2x of the
/// 32-thread pool (well under 20s of Q9's ~225s at SF=100/1G).
const SPILL_JOIN_PHASE_A_MAX_THREADS: usize = 8;
const PHASE_A_BYTES_PER_WORKER: usize = 64 * 1024 * 1024;

fn spill_join_phase_a_pool(memory_threshold: usize) -> Result<rayon::ThreadPool> {
    let by_budget = (memory_threshold / PHASE_A_BYTES_PER_WORKER).max(1);
    let by_machine = std::thread::available_parallelism()
        .map(|n| n.get())
        .unwrap_or(1);
    let threads = by_budget
        .min(by_machine)
        .clamp(1, SPILL_JOIN_PHASE_A_MAX_THREADS);
    rayon::ThreadPoolBuilder::new()
        .num_threads(threads)
        .thread_name(|i| format!("sj-phase-a-{i}"))
        .build()
        .map_err(|e| {
            QueryError::Execution(format!(
                "failed to build the join spill path's phase A thread pool: {e}"
            ))
        })
}

/// Phase A's mutable per-call state, moved into each group's blocking job
/// and back (all of it is `Send`; `ArrowWriter<File>` was already carried
/// across awaits before this task).
struct PhaseAState {
    /// This call's phase-A pool (see `spill_join_phase_a_pool`).
    pool: rayon::ThreadPool,
    spill_writers: Vec<Option<ArrowWriter<File>>>,
    probe_spill_files: Vec<Option<PathBuf>>,
    probe_key_checksums: Vec<Option<KeyChecksum>>,
    /// `SpillJoinCtx::build_bitmap` joins only (build-side SEMI/ANTI, a
    /// preserved build side): one bitmap per RESIDENT partition (per build
    /// batch), marked from many probe pieces at once → `AtomicBool`.
    build_matched: Vec<Option<Vec<Vec<std::sync::atomic::AtomicBool>>>>,
    // Last field: writers must drop before the last file owner.
    file_owner: Arc<ProbeSpillFiles>,
}

impl PhaseAState {
    fn new(
        state: &Arc<SpillState>,
        build_side_output: bool,
        memory_threshold: usize,
        call_id: u64,
    ) -> Result<Self> {
        use std::sync::atomic::AtomicBool;
        let build_matched = (0..NUM_PARTITIONS)
            .map(|idx| {
                if !build_side_output || state.tables[idx].is_none() {
                    return None;
                }
                state.partitions[idx].as_ref().map(|p| {
                    p.batches
                        .iter()
                        .map(|b| (0..b.num_rows()).map(|_| AtomicBool::new(false)).collect())
                        .collect()
                })
            })
            .collect();
        Ok(Self {
            pool: spill_join_phase_a_pool(memory_threshold)?,
            spill_writers: (0..NUM_PARTITIONS).map(|_| None).collect(),
            probe_spill_files: (0..NUM_PARTITIONS).map(|_| None).collect(),
            probe_key_checksums: (0..NUM_PARTITIONS).map(|_| None).collect(),
            build_matched,
            file_owner: Arc::new(ProbeSpillFiles {
                state: state.clone(),
                call_id,
            }),
        })
    }
}

/// One phase-A group, on the blocking pool. (1) The group is concatenated
/// into one batch; (2) rayon over `SPILL_READ_BATCH_ROWS`-row ranges
/// computes every row's partition id (`partition_row_ids` — the same
/// routing as `partition_batch_by_hash`, by construction); (3) rayon over
/// PARTITIONS: each partition that received rows `take`s its rows (ONE
/// gather of ~group/64 rows) and, on that same thread, either probes its
/// resident table (INNER pairs and probe-side SEMI/ANTI rows become
/// output batches; build-side SEMI/ANTI marks the partition's own atomic
/// bitmap), appends to its own spill writer (one writer per partition, so
/// partitions are independent), or — ANTI with no build rows at all —
/// emits the rows whole. Returns the state and the output batches for
/// the caller to send.
///
/// Why partition-major rather than piece-major: a first version ran
/// `partition_batch_by_hash` per 8,192-row piece in parallel and then
/// wrote the resulting 64 tiny slices per piece from another thread —
/// ~2,300 sub-kilobyte batches per group allocated on rayon threads and
/// freed elsewhere, which the process-wide allocator retained: the
/// 600M-row harness `semi-join` leg went from 470MB to 858MB peak RSS
/// with everything else equal (traced per phase with `QE_SPILL_DEBUG`
/// + a 1s RSS sampler). This shape does one ~4k-row gather per partition
/// per group, allocated and freed on the same thread, and probes resident
/// tables in 4k-row batches instead of 128-row ones.
fn phase_a_process_group(
    state: &SpillState,
    ctx: &SpillJoinCtx,
    mut st: PhaseAState,
    mut group: Vec<RecordBatch>,
) -> Result<(PhaseAState, Vec<RecordBatch>)> {
    use rayon::prelude::*;
    let probe_keys = &ctx.probe_keys;
    let probe_bitmap = ctx.probe_bitmap();
    let probe_emit = ctx.probe_emit();

    let merged = if group.len() == 1 {
        group.pop().expect("one batch")
    } else {
        let schema = group[0].schema();
        arrow::compute::concat_batches(&schema, group.iter())
            .map_err(|e| QueryError::Execution(e.to_string()))?
    };
    drop(group);
    let n = merged.num_rows();
    if n == 0 {
        return Ok((st, Vec::new()));
    }

    // (2) partition ids, parallel over row ranges.
    let ranges: Vec<(usize, usize)> = (0..n)
        .step_by(SPILL_READ_BATCH_ROWS)
        .map(|s| (s, SPILL_READ_BATCH_ROWS.min(n - s)))
        .collect();
    let pool = &st.pool;
    let ids_per_range: Vec<Vec<u32>> = pool.install(|| {
        ranges
            .par_iter()
            .map(|&(s, len)| partition_row_ids(&merged.slice(s, len), probe_keys, NUM_PARTITIONS))
            .collect::<Result<_>>()
    })?;
    let mut per_partition: Vec<Vec<u32>> = (0..NUM_PARTITIONS).map(|_| Vec::new()).collect();
    for (&(s, _), ids) in ranges.iter().zip(&ids_per_range) {
        for (i, p) in ids.iter().enumerate() {
            per_partition[*p as usize].push((s + i) as u32);
        }
    }
    drop(ids_per_range);

    // (3) per partition, on one thread each.
    let spill_dir = &state.spill_dir;
    let sj_trace = ctx.sj_trace;
    let spilled_bytes = std::sync::atomic::AtomicUsize::new(0);
    let slots: Vec<(
        usize,
        Vec<u32>,
        &mut Option<ArrowWriter<File>>,
        &mut Option<PathBuf>,
        &mut Option<KeyChecksum>,
        Option<&Vec<Vec<std::sync::atomic::AtomicBool>>>,
    )> = per_partition
        .into_iter()
        .zip(st.spill_writers.iter_mut())
        .zip(st.probe_spill_files.iter_mut())
        .zip(st.probe_key_checksums.iter_mut())
        .zip(st.build_matched.iter())
        .enumerate()
        .filter(|(_, ((((rows, _), _), _), _))| !rows.is_empty())
        .map(|(idx, ((((rows, w), f), cs), bm))| (idx, rows, w, f, cs, bm.as_ref()))
        .collect();
    let outputs_per_partition: Vec<Vec<RecordBatch>> = pool.install(|| {
        slots
            .into_par_iter()
            .map(
                |(idx, rows, writer, file, checksum, build_bm)| -> Result<Vec<RecordBatch>> {
                    let indices = UInt32Array::from(rows);
                    let columns: Result<Vec<ArrayRef>> = merged
                        .columns()
                        .iter()
                        .map(|c| compute::take(c.as_ref(), &indices, None).map_err(Into::into))
                        .collect();
                    let pb = RecordBatch::try_new(merged.schema(), columns?)?;
                    let mut outputs: Vec<RecordBatch> = Vec::new();
                    if let Some(ref ht) = state.tables[idx] {
                        // Probe in-memory partition: pairs out (INNER/outer),
                        // the resident partition's build bitmap marked
                        // (build-side SEMI/ANTI, preserved build side), and
                        // — since a probe row's status is final against its
                        // own resident partition — its probe-side emission
                        // right away (probe-side SEMI/ANTI rows, or the
                        // unmatched rows of a preserved probe side,
                        // NULL-extended).
                        let Some(build_part) = state.partitions[idx].as_ref() else {
                            return Ok(outputs);
                        };
                        let mut flags = probe_bitmap.then(|| vec![false; pb.num_rows()]);
                        outputs.extend(probe_batch_against_table(
                            &build_part.batches,
                            &pb,
                            ht,
                            ctx,
                            build_bm.map(|v| v.as_slice()),
                            flags.as_deref_mut(),
                        )?);
                        if let Some(flags) = flags {
                            outputs.extend(emit_probe_rows(ctx, &pb, &flags)?);
                        }
                    } else if state.spilled[idx].is_some() {
                        // Spill probe rows for this partition
                        spilled_bytes.fetch_add(
                            estimate_batch_size(&pb),
                            std::sync::atomic::Ordering::Relaxed,
                        );
                        let path = file.get_or_insert_with(|| ctx.probe_file(spill_dir, idx));
                        append_batch_streaming(writer, path, &pb)?;
                        if sj_trace {
                            let cs = batch_key_checksum(&pb, probe_keys)?;
                            checksum
                                .get_or_insert_with(KeyChecksum::default)
                                .accumulate(cs);
                        }
                    } else if matches!(
                        probe_emit,
                        RowEmit::Unmatched | RowEmit::UnmatchedNullExtended
                    ) {
                        // task 004: this partition holds NO build row at all
                        // (nothing was ever routed here, or it was emptied
                        // before the table pass), so every probe row in it is
                        // unmatched. INNER and SEMI correctly drop the batch;
                        // ANTI must EMIT it whole — the previously silent
                        // drop was exactly the wrong-result hazard for the
                        // probe-side-output ANTI orientation — and a
                        // preserved probe side (task 003) emits it whole,
                        // NULL-extended.
                        let all_false = vec![false; pb.num_rows()];
                        outputs.extend(emit_probe_rows(ctx, &pb, &all_false)?);
                    }
                    Ok(outputs)
                },
            )
            .collect::<Result<_>>()
    })?;
    let spilled = spilled_bytes.into_inner();
    if spilled > 0 {
        ctx.memory_pool.record_spill(spilled);
    }
    Ok((st, outputs_per_partition.into_iter().flatten().collect()))
}

/// Phase A (+ A'): consume the probe stream. Probe batches are gathered
/// into groups of ~`PHASE_A_GROUP_ROWS` rows and each group is processed
/// on the blocking pool (`phase_a_process_group`: rayon-parallel
/// partitioning + resident probing, parallel-across-partitions spill
/// writes); the group's output batches are SENT as soon as the group is
/// done, and probe rows routed to spilled partitions land in this call's
/// probe spill files (one open writer per partition for the whole phase,
/// closed exactly once at the end). Build-side SEMI/ANTI resident emission
/// (A') happens after the stream ends. Never holds more than one group,
/// its partitioned copy and the in-flight output.
///
/// join-spill-streaming task 003: before this, phase A ran single-threaded
/// on the producer task — and once the output was streamed (task 002) it
/// became the pace-setter of the whole pipeline (Q9 at SF=100/1G: the
/// second join's read-back ran at ~1.7 cores of 32 because THIS loop, as
/// its consumer, hashed 333M probe rows and fed 60 spill writers on one
/// thread).
async fn probe_with_spilling(
    state: &Arc<SpillState>,
    ctx: &SpillJoinCtx,
    mut probe_stream: RecordBatchStream,
    tx: &SpillJoinOutputSender,
) -> Result<ProbePhase> {
    // spill-join-correctness-3 task 004: SEMI/ANTI existence semantics
    // on the spill path. Partition routing is the same fixed-seed hash
    // of the join key for build and probe, and a build partition is
    // wholly resident or wholly on disk (`evict_build_partition_to_disk`
    // takes the whole partition), so EVERY build row a probe row could
    // match lives in the probe row's own partition — no cross-partition
    // state is ever needed. Two output orientations exist, decided by
    // the planner (`build_right_for_left`):
    //   swapped  (build = right, probe = LEFT = the output side): a
    //     probe row's status is fully decided against its partition's
    //     table, so resident partitions emit per probe piece right away
    //     (`take_probe_rows`); rows routed to a spilled partition are
    //     spilled and decided in `process_spilled_partition`.
    //   !swapped (build = LEFT = the output side): a resident build row
    //     can be matched by a probe row from ANY probe batch, so its
    //     status is only known once the whole probe stream has been
    //     consumed — one match bitmap per resident partition (per build
    //     batch) is populated across the loop and emitted after it.
    // spill-boundaries task 003: the outer joins reuse exactly these two
    // bitmaps for their PRESERVED side(s) — LEFT with build = right /
    // RIGHT with build = left / FULL keep the probe-side one, LEFT with
    // build = left / RIGHT with build = right / FULL the build-side one —
    // and emit the unmatched rows NULL-extended where SEMI/ANTI emit them
    // bare (`SpillJoinCtx::probe_emit` / `build_emit`); matched pairs are
    // emitted as INNER pairs alongside.
    let build_bitmap = ctx.build_bitmap();
    let mut st = PhaseAState::new(state, build_bitmap, ctx.memory_threshold, ctx.call_id)?;
    let mut in_memory_matched = 0usize;
    // join-spill-streaming task 001: probe rows counted as they flow
    // (QE_SPILL_DEBUG trace), since the probe side is no longer a Vec.
    let mut probe_rows_in: usize = 0;

    // Abandonment (consumer dropped the stream): stop pulling probe
    // batches and writing spill files for output nobody will read. The
    // files written so far are removed by the caller.
    let abandoned = |st: PhaseAState, probe_rows: usize, in_memory_matched: usize| {
        Ok(ProbePhase {
            phase_a_threads: st.pool.current_num_threads(),
            probe_spill_files: st.probe_spill_files,
            probe_key_checksums: st.probe_key_checksums,
            probe_rows,
            in_memory_matched,
            abandoned: true,
            file_owner: st.file_owner,
        })
    };

    let mut group: Vec<RecordBatch> = Vec::new();
    let mut group_rows = 0usize;
    loop {
        let next = probe_stream.try_next().await?;
        let end_of_stream = next.is_none();
        if let Some(batch) = next {
            if tx.is_closed() {
                return abandoned(st, probe_rows_in, in_memory_matched);
            }
            probe_rows_in += batch.num_rows();
            group_rows += batch.num_rows();
            group.push(batch);
        }
        let flush = end_of_stream
            || group_rows >= PHASE_A_GROUP_ROWS
            || group.len() >= PHASE_A_GROUP_BATCHES;
        if flush && !group.is_empty() {
            let g = std::mem::take(&mut group);
            group_rows = 0;
            let state2 = Arc::clone(state);
            let ctx2 = ctx.clone();
            let (st2, outputs) =
                tokio::task::spawn_blocking(move || phase_a_process_group(&state2, &ctx2, st, g))
                    .await
                    .map_err(|e| {
                        QueryError::Execution(format!("join spill probe task failed: {e}"))
                    })??;
            st = st2;
            for out in outputs {
                if !emit_join_batch(tx, out, &mut in_memory_matched).await {
                    return abandoned(st, probe_rows_in, in_memory_matched);
                }
            }
        }
        if end_of_stream {
            break;
        }
    }

    // Phase A' — task 004, build-side bitmap: emit once the ENTIRE probe
    // stream is consumed. A resident partition no probe row ever reached
    // keeps an all-false bitmap: all of its rows are unmatched, so ANTI
    // (and a preserved build side, NULL-extended) emits every one of them
    // and SEMI none — the mirror hazard of the dropped-probe-batch case
    // above. Build rows with NULL keys are never in the table, so they
    // stay unmatched too, matching the in-memory join's own
    // null-never-matches rule.
    if build_bitmap {
        for idx in 0..NUM_PARTITIONS {
            let Some(bm) = st.build_matched[idx].take() else {
                continue;
            };
            let Some(build_part) = state.partitions[idx].as_ref() else {
                continue;
            };
            let flags: Vec<Vec<bool>> = bm
                .iter()
                .map(|v| {
                    v.iter()
                        .map(|a| a.load(std::sync::atomic::Ordering::Relaxed))
                        .collect()
                })
                .collect();
            for out in emit_build_rows(ctx, &build_part.batches, &flags)? {
                if !emit_join_batch(tx, out, &mut in_memory_matched).await {
                    return abandoned(st, probe_rows_in, in_memory_matched);
                }
            }
        }
    }

    // Closed exactly once, between phases A and B — every probe file must
    // be complete before `process_spilled_partition` opens it.
    let phase_a_threads = st.pool.current_num_threads();
    // The pool (and whatever its threads retained) goes away with `st`
    // before phase B starts; the writers are closed exactly once here.
    let PhaseAState {
        pool,
        spill_writers,
        probe_spill_files,
        probe_key_checksums,
        file_owner,
        ..
    } = st;
    drop(pool);
    close_spill_writers(spill_writers)?;
    Ok(ProbePhase {
        phase_a_threads,
        probe_spill_files,
        probe_key_checksums,
        probe_rows: probe_rows_in,
        in_memory_matched,
        abandoned: false,
        file_owner,
    })
}

/// Open a spill file for streaming read-back, one `SPILL_READ_BATCH_ROWS`
/// batch at a time (join-spill-streaming task 003 — `read_parquet` pulls
/// the whole file into memory, which for a spilled partition is the entire
/// partition; the read-back below never holds more than one build chunk
/// and one probe group).
fn open_spill_reader(
    path: &PathBuf,
) -> Result<parquet::arrow::arrow_reader::ParquetRecordBatchReader> {
    let file = File::open(path).map_err(|e| {
        QueryError::Execution(format!("Failed to open parquet file {:?}: {}", path, e))
    })?;
    Ok(ParquetRecordBatchReaderBuilder::try_new(file)?
        .with_batch_size(SPILL_READ_BATCH_ROWS)
        .build()?)
}

/// Phase B for ONE spilled partition: stream the memoized build file back
/// in chunks whose (predicted table + batch) bytes fit `chunk_budget`, and
/// for each chunk stream this call's probe file past the chunk's table,
/// pushing every output batch into `sink` as soon as it exists (`false`
/// from the sink = consumer gone, stop). Synchronous — runs on the
/// blocking pool; the probe work inside a chunk is rayon-parallel over
/// groups of `PROBE_GROUP_BATCHES` probe batches.
///
/// oom-safety-hardening task 007 bounded the read-back's transient hash
/// table at one budget's worth by chunking the build side; task 003 of
/// join-spill-streaming keeps that chunking (budget now `threshold / K`,
/// see `plan_phase_b`) and additionally stops materializing the partition
/// files themselves: the footprint of one job is one build chunk (batches
/// + table ≤ `chunk_budget`), one probe group, the bitmaps, and the output
/// batch in flight — whatever the partition's size. The probe file is
/// re-read once per chunk (it was just written; the page cache serves it),
/// which is the same per-chunk probe pass the previous in-memory
/// `probe_batches` loop made, minus the resident copy.
///
/// Correctness, per join type (chunks partition the build rows
/// DISJOINTLY in every case):
///   INNER: each (build row, probe row) match pair is emitted exactly
///     once and the union over chunks equals the single-table result.
///     Probe routing and `probe_partition` itself are untouched; the
///     parallel probe over a group's batches is per probe batch, so the
///     concatenation of results is the sequential result in a different
///     order.
///   SEMI/ANTI, probe-side output (swapped) — spill-join-correctness-3
///     task 004: a key's build rows may STRADDLE chunks, so per-chunk
///     emission would double-emit a SEMI row (matched in two chunks) and
///     prematurely emit an ANTI row (unmatched in chunk 1, matched in
///     chunk 2). One match bitmap per probe batch (indexed by the batch's
///     position in the file, identical across re-reads) is OR-accumulated
///     across ALL chunks; the rows are emitted exactly once, in a final
///     pass over the probe file after the last chunk. Parallel across
///     probe batches (each batch owns its own bitmap).
///   SEMI/ANTI, build-side output (!swapped): each build row lives in
///     exactly one chunk and is probed against the FULL probe partition
///     there, so its status is complete within its own chunk — per-chunk
///     emission is exact, no cross-chunk state. The chunk's bitmap is
///     `AtomicBool`s so probe batches mark it in parallel (stores of
///     `true` commute). A partition with no probe file has no probe rows:
///     ANTI emits every build row, SEMI none.
///   LEFT/RIGHT/FULL (spill-boundaries task 003): INNER pair emission per
///     chunk PLUS the bitmap(s) of the preserved side(s) exactly as above —
///     a preserved probe side is emitted NULL-extended in the final pass
///     after the last chunk (never earlier: a probe row unmatched in chunk
///     1 may match in chunk 2), a preserved build side per chunk. Both
///     bitmaps live with this partition's job; K-way phase B is
///     unchanged.
fn process_spilled_partition(
    ctx: &SpillJoinCtx,
    sp: &SpilledPartition,
    probe_file: Option<&PathBuf>,
    probe_key_checksum: Option<KeyChecksum>,
    idx: usize,
    chunk_budget: usize,
    sink: &mut dyn FnMut(RecordBatch) -> bool,
) -> Result<()> {
    use rayon::prelude::*;
    use std::sync::atomic::AtomicBool;

    let sj_trace = ctx.sj_trace;
    let t0 = std::time::Instant::now();
    let build_keys = &ctx.build_keys;
    let probe_keys = &ctx.probe_keys;
    let key_cols = build_keys.len();
    let probe_bitmap = ctx.probe_bitmap();
    let build_bitmap = ctx.build_bitmap();

    // spill-join-correctness-2 epic, task 001: recompute the join-key
    // checksum from the data read back off disk and compare it against
    // the checksum recorded when those SAME rows were written (before the
    // spill/unspill round trip) — direct, in-the-act evidence of a
    // Trino-PR#25892-shaped bug (spill-write and unspill-read disagreeing
    // about a row's join key) rather than inference. The build file is
    // read exactly once (chunk by chunk), the probe file's checksum is
    // taken on its FIRST pass; both are reported only once the file has
    // been fully consumed.
    let mut build_read_cs = match (sj_trace, sp.build_key_checksum) {
        (true, Some(_)) => Some(KeyChecksum::default()),
        _ => None,
    };
    let mut probe_read_cs = match (sj_trace, probe_key_checksum, probe_file) {
        (true, Some(_), Some(_)) => Some(KeyChecksum::default()),
        _ => None,
    };

    let mut build_reader = open_spill_reader(&sp.build_file)?;
    let mut pending: Option<RecordBatch> = None;
    // Probe-side bitmap joins: one bitmap per probe batch, by file position.
    let mut probe_matched: Vec<Vec<bool>> = Vec::new();
    // First pass over the probe file done (row count, checksum, bitmaps).
    let mut probe_seen = false;
    let mut build_rows = 0usize;
    let mut build_batches = 0usize;
    let mut probe_rows = 0usize;
    let mut chunks = 0usize;
    let mut alive = true;

    'chunks: loop {
        // Assemble the next chunk: whole batches, at least one, stopping
        // BEFORE (predicted table + batch bytes) would cross the budget.
        let mut chunk: Vec<RecordBatch> = Vec::new();
        let mut chunk_rows = 0usize;
        let mut chunk_bytes = 0usize;
        loop {
            let next = match pending.take() {
                Some(b) => Some(b),
                None => match build_reader.next() {
                    Some(r) => Some(r?),
                    None => None,
                },
            };
            let Some(b) = next else {
                break;
            };
            if b.num_rows() == 0 {
                continue;
            }
            let rows = chunk_rows + b.num_rows();
            let bytes = chunk_bytes + estimate_batch_size(&b);
            if !chunk.is_empty()
                && predicted_hash_table_bytes(rows, key_cols) + bytes > chunk_budget
            {
                pending = Some(b);
                break;
            }
            if let Some(cs) = build_read_cs.as_mut() {
                cs.accumulate(batch_key_checksum(&b, build_keys)?);
            }
            chunk_rows = rows;
            chunk_bytes = bytes;
            chunk.push(b);
        }
        if chunk.is_empty() {
            break 'chunks;
        }
        chunks += 1;
        build_rows += chunk_rows;
        build_batches += chunk.len();
        let table = build_hash_table(&chunk, build_keys)?;
        let build_bm: Vec<Vec<AtomicBool>> = if build_bitmap {
            chunk
                .iter()
                .map(|b| (0..b.num_rows()).map(|_| AtomicBool::new(false)).collect())
                .collect()
        } else {
            Vec::new()
        };

        if let Some(pf) = probe_file {
            let mut reader = open_spill_reader(pf)?;
            let mut batch_pos = 0usize;
            loop {
                let mut group: Vec<RecordBatch> = Vec::with_capacity(PROBE_GROUP_BATCHES);
                while group.len() < PROBE_GROUP_BATCHES {
                    match reader.next() {
                        Some(r) => group.push(r?),
                        None => break,
                    }
                }
                if group.is_empty() {
                    break;
                }
                if !probe_seen {
                    for b in &group {
                        probe_rows += b.num_rows();
                        if let Some(cs) = probe_read_cs.as_mut() {
                            cs.accumulate(batch_key_checksum(b, probe_keys)?);
                        }
                        if probe_bitmap {
                            probe_matched.push(vec![false; b.num_rows()]);
                        }
                    }
                }
                // One pass per probe batch does everything this join needs
                // against the chunk's table: INNER pairs (sent below), the
                // chunk's build bitmap, this batch's probe bitmap.
                let build_bm_ref = build_bitmap.then(|| build_bm.as_slice());
                let outs: Vec<Vec<RecordBatch>> = if probe_bitmap {
                    let flags = &mut probe_matched[batch_pos..batch_pos + group.len()];
                    group
                        .par_iter()
                        .zip(flags.par_iter_mut())
                        .map(|(pb, f)| {
                            probe_batch_against_table(
                                &chunk,
                                pb,
                                &table,
                                ctx,
                                build_bm_ref,
                                Some(f.as_mut_slice()),
                            )
                        })
                        .collect::<Result<_>>()?
                } else {
                    group
                        .par_iter()
                        .map(|pb| {
                            probe_batch_against_table(&chunk, pb, &table, ctx, build_bm_ref, None)
                        })
                        .collect::<Result<_>>()?
                };
                for out in outs.into_iter().flatten() {
                    if !sink(out) {
                        alive = false;
                        break 'chunks;
                    }
                }
                batch_pos += group.len();
            }
            probe_seen = true;
        }
        if build_bitmap {
            let bm: Vec<Vec<bool>> = build_bm
                .iter()
                .map(|v| {
                    v.iter()
                        .map(|a| a.load(std::sync::atomic::Ordering::Relaxed))
                        .collect()
                })
                .collect();
            for out in emit_build_rows(ctx, &chunk, &bm)? {
                if !sink(out) {
                    alive = false;
                    break 'chunks;
                }
            }
        }
    }

    // Probe-side bitmap: the emission pass, after the last chunk. A probe
    // batch with no bitmap (no build chunk ever ran — every probe row
    // unmatched) is all-false: ANTI and a preserved probe side emit it
    // whole (the latter NULL-extended), SEMI drops it.
    if alive && probe_bitmap {
        if let Some(pf) = probe_file {
            for (i, r) in open_spill_reader(pf)?.enumerate() {
                let pb = r?;
                if !probe_seen {
                    probe_rows += pb.num_rows();
                    if let Some(cs) = probe_read_cs.as_mut() {
                        cs.accumulate(batch_key_checksum(&pb, probe_keys)?);
                    }
                }
                let all_false;
                let flags: &[bool] = match probe_matched.get(i) {
                    Some(f) => f,
                    None => {
                        all_false = vec![false; pb.num_rows()];
                        &all_false
                    }
                };
                for out in emit_probe_rows(ctx, &pb, flags)? {
                    if !sink(out) {
                        alive = false;
                        break;
                    }
                }
            }
            probe_seen = true;
        }
    }

    if sj_trace && alive {
        if let (Some(write_cs), Some(read_cs)) = (sp.build_key_checksum, build_read_cs) {
            report_key_checksum("build", idx, write_cs, read_cs);
        }
        if probe_seen {
            if let (Some(write_cs), Some(read_cs)) = (probe_key_checksum, probe_read_cs) {
                report_key_checksum("probe", idx, write_cs, read_cs);
            }
        }
        eprintln!(
            "[sj-trace] process_spilled_partition idx={} done: build_rows={} build_batches={} chunks={} probe_rows={} chunk_table_budget={} elapsed={:?} call_id={}",
            idx,
            build_rows,
            build_batches,
            chunks,
            probe_rows,
            chunk_budget,
            t0.elapsed(),
            ctx.call_id
        );
    }
    Ok(())
}

/// `QE_SPILL_DEBUG` write-vs-read join-key checksum report for one side
/// of one spilled partition (see `SpilledPartition::build_key_checksum`).
fn report_key_checksum(side: &str, idx: usize, write_cs: KeyChecksum, read_cs: KeyChecksum) {
    if read_cs.rows != write_cs.rows || read_cs.xor_hash != write_cs.xor_hash {
        eprintln!(
            "[sj-trace] HASH-MISMATCH {side} partition idx={} write_rows={} write_xor={:016x} read_rows={} read_xor={:016x} write_unhandled={} read_unhandled={}",
            idx,
            write_cs.rows,
            write_cs.xor_hash,
            read_cs.rows,
            read_cs.xor_hash,
            write_cs.unhandled_type_rows,
            read_cs.unhandled_type_rows
        );
    } else {
        eprintln!(
            "[sj-trace] hash-check-ok {side} partition idx={} rows={} xor={:016x} unhandled={}",
            idx, read_cs.rows, read_cs.xor_hash, read_cs.unhandled_type_rows
        );
    }
}

// spill-join-correctness-2 epic, task 002 / join-spill-streaming task 002:
// build-side spill files are memoized ONCE (in `compute_build_decision`)
// and deliberately NOT removed at the end of every `execute_spill_path`
// call — a repeat call (e.g. a fused-streaming aggregate aborting and
// re-executing this join as its input) must still be able to read them
// back. Cleanup happens exactly once, in `SpillState::drop`, when the last
// holder of the memoized state — this operator, or an output stream's
// producer that outlived it — goes away. A join whose build side never
// spilled (`BuildDecision::InMemory`, or `build_decision` never even
// initialized, e.g. an unused partition) has nothing to clean up.

impl fmt::Display for SpillableHashJoinExec {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let on_str: Vec<String> = self
            .on
            .iter()
            .map(|(l, r)| format!("{} = {}", l, r))
            .collect();
        write!(
            f,
            "SpillableHashJoin: {} on [{}]",
            self.join_type,
            on_str.join(", ")
        )
    }
}

// ============================================================================
// Spillable Hash Aggregate
// ============================================================================

/// Hash aggregate execution operator with spilling support
pub struct SpillableHashAggregateExec {
    /// See [`Self::with_disjoint_groups`].
    disjoint_hint: bool,
    input: Arc<dyn PhysicalOperator>,
    group_by: Vec<Expr>,
    aggregates: Vec<AggregateExpr>,
    schema: SchemaRef,
    memory_pool: SharedMemoryPool,
    config: ExecutionConfig,
    /// HAVING predicate applied per output batch (references output columns)
    post_filter: Option<Expr>,
}

/// Aggregate expression with function and input
#[derive(Debug, Clone)]
pub struct AggregateExpr {
    pub func: crate::planner::AggregateFunction,
    pub input: Expr,
    pub distinct: bool,
    /// Optional second argument for functions like APPROX_PERCENTILE
    pub second_arg: Option<Expr>,
}

impl fmt::Debug for SpillableHashAggregateExec {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SpillableHashAggregateExec")
            .field("group_by", &self.group_by)
            .finish()
    }
}

impl SpillableHashAggregateExec {
    pub fn new(
        input: Arc<dyn PhysicalOperator>,
        group_by: Vec<Expr>,
        aggregates: Vec<AggregateExpr>,
        schema: SchemaRef,
        memory_pool: SharedMemoryPool,
        config: ExecutionConfig,
    ) -> Self {
        Self {
            input,
            group_by,
            aggregates,
            schema,
            memory_pool,
            config,
            post_filter: None,
            disjoint_hint: false,
        }
    }

    /// Planner hint: hash-partition the fused-agg input to per-worker
    /// channels (disjoint states, trivial finalize). Set only when the group
    /// key's statistics predict the shared-channel merge will pay a large
    /// overlap penalty — a DENSE integer key space (range ≈ NDV) with
    /// millions of groups, where every worker's partial state spans the
    /// whole range. Q13's c_custkey (NDV=range=15M): shared merge 4.3s,
    /// disjoint 0.1ms. Sparse keys (Q18's l_orderkey, range 4x NDV) LOSE
    /// under scatter (+1.3s), so the default stays shared.
    pub fn with_disjoint_groups(mut self, disjoint: bool) -> Self {
        self.disjoint_hint = disjoint;
        self
    }

    pub fn with_post_filter(mut self, post_filter: Option<Expr>) -> Self {
        self.post_filter = post_filter;
        self
    }

    /// The fused streaming path supports the simple accumulator functions the
    /// morsel aggregation core implements.
    fn fused_streaming_eligible(&self) -> bool {
        use crate::planner::AggregateFunction as F;
        !self.group_by.is_empty()
            && !self.aggregates.is_empty()
            && self.aggregates.iter().all(|a| {
                !a.distinct
                    && a.second_arg.is_none()
                    && matches!(
                        a.func,
                        F::Count | F::Sum | F::Min | F::Max | F::Avg | F::AnyValue | F::Arbitrary
                    )
            })
    }

    /// Bind a spillable partial-state path before input consumption. Unsupported
    /// layouts alone may return None. Once input starts, failures are terminal;
    /// budget pressure flushes partial states without reexecuting the source.
    async fn execute_fused_streaming(&self) -> Result<Option<RecordBatchStream>> {
        crate::physical::morsel_agg::live_spill::execute(
            self.input.clone(),
            &self.group_by,
            &self.aggregates,
            self.schema.clone(),
            &self.memory_pool,
            &self.config,
            self.post_filter.as_ref(),
        )
        .await
    }
}

/// State for an aggregate partition during processing
struct AggregatePartition {
    batches: Vec<RecordBatch>,
    memory_bytes: usize,
    /// Total rows across `batches` — kept incrementally (mirroring
    /// `BuildPartition::rows`, oom-safety-hardening task 007) so the
    /// finalize step's aggregation-state accounting
    /// (`predicted_agg_state_bytes`, task 002) never rescans batches to
    /// price the state this partition's rows imply.
    rows: usize,
}

impl AggregatePartition {
    fn new() -> Self {
        Self {
            batches: Vec::new(),
            memory_bytes: 0,
            rows: 0,
        }
    }

    fn add_batch(&mut self, batch: RecordBatch) {
        self.memory_bytes += estimate_batch_size(&batch);
        self.rows += batch.num_rows();
        self.batches.push(batch);
    }

    fn clear(&mut self) {
        self.batches.clear();
        self.memory_bytes = 0;
        self.rows = 0;
    }
}

/// State for a spilled aggregate partition: the (single, incrementally
/// appended) Parquet file plus running row/byte totals of what was written
/// to it. The totals are what lets the finalize step price a partition's
/// read-back + aggregation-state cost BEFORE materializing anything
/// (oom-safety-hardening task 002, mirroring task 007's accounting
/// discipline for the join spill path's hash tables).
struct SpilledAggPartition {
    file: PathBuf,
    rows: usize,
    /// Estimated IN-MEMORY bytes of the batches written to `file`
    /// (accumulated `estimate_batch_size` at spill time — NOT the
    /// compressed on-disk size, which under-counts what read-back will
    /// actually materialize).
    raw_bytes: usize,
}

#[async_trait]
impl PhysicalOperator for SpillableHashAggregateExec {
    fn schema(&self) -> SchemaRef {
        self.schema.clone()
    }

    fn children(&self) -> Vec<Arc<dyn PhysicalOperator>> {
        vec![self.input.clone()]
    }

    async fn execute(&self, partition: usize) -> Result<RecordBatchStream> {
        // Aggregation always produces a single partition by collecting from all input partitions
        crate::physical::check_partition(self, partition)?;

        // Bind the partial-state route before input is opened. A selected route
        // consumes every partition once; memory pressure spills retained states.
        // Only an unsupported capability can choose the ordinary route below.
        let fused_eligible = self.fused_streaming_eligible();
        if fused_eligible {
            if let Some(result) = self.execute_fused_streaming().await? {
                return Ok(result);
            }
        }

        if std::env::var("QE_SPILL_DEBUG").is_ok() {
            eprintln!("[sj-trace] agg ordinary route: fused_eligible={fused_eligible}; no fused input was consumed");
        }

        // Phase 1: reserve, possibly spill (oom-safety-hardening task 002 —
        // the same Photon-style streaming two-phase reservation
        // `SpillableHashJoinExec::compute_build_decision` ships, mirrored
        // rather than reinvented). The OLD code called
        // `collect_input_partitions_concurrently`, which fully drained the
        // ENTIRE input into one flat `Vec<RecordBatch>` and only THEN
        // compared its total size against `memory_limit * spill_threshold`
        // — so an oversized input could exhaust real memory during that
        // initial collection, before the spill decision ever ran (the
        // harness `agg` scenario: 250M rows / ~4GB streamed into a 256MB
        // budget was kernel-OOM-killed here). Now the input streams in via
        // `stream_merge_input_partitions` (same one-task-per-partition
        // cross-core drain benefit, bounded channel instead of a growing
        // Vec) with a running size total checked as each batch arrives —
        // never buffering more than ~`memory_threshold` bytes of flat,
        // unpartitioned input. The MOMENT the total would cross the
        // threshold, everything collected so far plus the crossing batch
        // plus the rest of the stream feeds `aggregate_with_spilling`'s
        // hash-partition-and-spill-as-needed bookkeeping, entered
        // mid-stream instead of only after a full prior collection.
        let memory_threshold =
            (self.config.memory_limit as f64 * self.config.spill_threshold) as usize;
        let mut drain_trace = InputTrace::new("aggregate_drain", || {
            serde_json::json!({
                "scalar":self.group_by.is_empty(),"input":self.input.name(),"partitions":self.input.output_partitions()
            })
        });
        let mut input_stream =
            stream_merge_input_partitions(&self.input, &self.memory_pool, "aggregate input queue")
                .await?;
        let mut flat_batches: Vec<RecordBatch> = Vec::new();
        let mut flat_size: usize = 0;
        let mut crossing_batch: Option<RecordBatch> = None;
        while let Some(batch) = input_stream.try_next().await? {
            let batch_size = estimate_batch_size(&batch);
            // The batch is already in memory when this decision is made: record it.
            self.memory_pool.observe(flat_size + batch_size);
            if flat_size + batch_size > memory_threshold {
                crossing_batch = Some(batch);
                break;
            }
            flat_size += batch_size;
            self.memory_pool.observe(flat_size);
            flat_batches.push(batch);
        }

        if let Some(t) = drain_trace.as_mut() {
            t.detail["retained_batches"] = serde_json::json!(flat_batches.len());
            t.detail["retained_bytes_estimate"] = serde_json::json!(flat_size);
            t.detail["crossed_threshold"] = serde_json::json!(crossing_batch.is_some());
        }
        InputTrace::finish(&mut drain_trace);

        if crossing_batch.is_none() {
            let mut reduce_trace = InputTrace::new("aggregate_delegate_execute", || {
                serde_json::json!({
                    "scalar":self.group_by.is_empty(),"batches":flat_batches.len()
                })
            });
            // Never crossed the threshold: the input genuinely fits — the
            // ordinary in-memory case, reached without ever risking an
            // unbounded collection to get here.
            let all_batches = flat_batches;
            // Data fits in memory — delegate to the proven HashAggregateExec
            let hash_aggs: Vec<crate::physical::operators::hash_agg::AggregateExpr> = self
                .aggregates
                .iter()
                .map(|a| crate::physical::operators::hash_agg::AggregateExpr {
                    func: a.func,
                    input: a.input.clone(),
                    distinct: a.distinct,
                    second_arg: a.second_arg.clone(),
                })
                .collect();
            let mem = crate::physical::operators::MemoryTableExec::new(
                "agg_input",
                all_batches
                    .first()
                    .map(|b| b.schema())
                    .unwrap_or_else(|| self.schema.clone()),
                all_batches,
                None,
            );
            let hash_agg = crate::physical::operators::HashAggregateExec::new(
                Arc::new(mem),
                self.group_by.clone(),
                hash_aggs,
                self.schema.clone(),
            )
            .with_memory_pool(self.memory_pool.clone());
            let stream = hash_agg.execute(0).await?;
            InputTrace::finish(&mut reduce_trace);
            if let Some(pred) = &self.post_filter {
                let batches: Vec<RecordBatch> = stream.try_collect().await?;
                let batches = crate::physical::operators::filter_batches(batches, pred)?;
                return Ok(Box::pin(stream::iter(batches.into_iter().map(Ok))));
            }
            return Ok(stream);
        }

        // Threshold crossed mid-stream — use the spillable aggregation path.
        self.config.ensure_spill_dir()?;

        let spill_id = SPILL_COUNTER.fetch_add(1, Ordering::Relaxed);
        let spill_dir = self
            .config
            .spill_path
            .join(format!("agg_{}_{}", partition, spill_id));
        let spill_directory = SpillDirectoryOwner::create(spill_dir.clone())?;

        if std::env::var("QE_SPILL_DEBUG").is_ok() {
            eprintln!(
                "[spill-agg] threshold crossed mid-stream at {} buffered batches ({} bytes, \
                 threshold {}) — entering streaming spill path",
                flat_batches.len() + 1,
                flat_size,
                memory_threshold
            );
        }

        // Phase 2: everything gathered so far (`flat_batches`), plus the
        // crossing batch, plus whatever remains of the stream, feeds the
        // bounded, spill-capable structure. Nothing collected in phase 1 is
        // thrown away or re-pulled from the source (mirrors
        // `SpillableHashJoinExec::finish_via_spill`).
        let combined: RecordBatchStream = Box::pin(
            stream::iter(flat_batches.into_iter().chain(crossing_batch).map(Ok))
                .chain(input_stream),
        );

        // Process with partitioning and spilling
        let (mut in_memory_partitions, mut spilled_parts) =
            self.aggregate_with_spilling(combined, &spill_dir).await?;
        if std::env::var("QE_SPILL_DEBUG").is_ok() {
            let mem_rows: usize = in_memory_partitions.iter().flatten().map(|p| p.rows).sum();
            let spilled_rows: usize = spilled_parts.iter().flatten().map(|s| s.rows).sum();
            eprintln!(
                "[spill-agg] in-memory rows {}, spilled files {} (spilled rows {})",
                mem_rows,
                spilled_parts.iter().flatten().count(),
                spilled_rows
            );
        }

        // Each partition holds RAW input rows hash-partitioned by group key, so
        // a given group lives in exactly one partition — possibly split between
        // a spill file and the in-memory remainder that accumulated after the
        // eviction. Aggregate each partition's spilled + in-memory rows TOGETHER,
        // once. Partition results are then disjoint group sets and are simply
        // concatenated. (Re-aggregating partial outputs with the original
        // functions is wrong: COUNT over partial counts returns the number of
        // partials, AVG over partial averages loses the weights.)
        //
        // With an empty GROUP BY every row hashes to the same partition, so the
        // single-result concatenation below is also correct for global aggregates.
        let agg_exprs: Vec<crate::physical::operators::hash_agg::AggregateExpr> = self
            .aggregates
            .iter()
            .map(|a| crate::physical::operators::hash_agg::AggregateExpr {
                func: a.func,
                input: a.input.clone(),
                distinct: a.distinct,
                second_arg: a.second_arg.clone(),
            })
            .collect();

        // Finalize, one partition at a time, under the SAME accounting
        // discipline task 007 established for the join spill path's hash
        // tables: BEFORE materializing a partition's read-back + building
        // its aggregation hash state, price both (raw batch bytes actually
        // written/held for the partition + `predicted_agg_state_bytes`, the
        // conservative worst-case-all-unique-groups analogue of
        // `predicted_hash_table_bytes`) against the same
        // `memory_limit * spill_threshold` threshold. A partition that
        // provably cannot fit is aggregated via the chunked
        // (sub-partitioned) read-back instead
        // (`aggregate_partition_chunked`, the aggregate analogue of task
        // 007's chunked read-back in `process_spilled_partition`) — groups
        // stay whole because sub-partitioning re-hashes the SAME group key
        // at a finer modulus, so the per-sub aggregation still sees every
        // row of each of its groups.
        //
        // Documented residual constants on top of the threshold: the
        // not-yet-processed partitions' resident batches (bounded at
        // ~threshold total by the ingestion loop), one partition's (or
        // sub-partition's) read-back + aggregation state (bounded at
        // ~threshold by this gate), and the accumulated output batches
        // (irreducible — the operator returns a materialized result).
        let group_cols = self.group_by.len();
        let n_aggs = self.aggregates.len();
        let n_distinct = self
            .aggregates
            .iter()
            .filter(|a| {
                a.distinct || matches!(a.func, crate::planner::AggregateFunction::CountDistinct)
            })
            .count();

        let mut all_results = Vec::new();
        for idx in 0..NUM_PARTITIONS {
            let resident = in_memory_partitions[idx].take();
            let spilled = spilled_parts[idx].take();
            let resident_rows = resident.as_ref().map(|p| p.rows).unwrap_or(0);
            let resident_bytes = resident.as_ref().map(|p| p.memory_bytes).unwrap_or(0);
            let spilled_rows = spilled.as_ref().map(|s| s.rows).unwrap_or(0);
            let spilled_bytes = spilled.as_ref().map(|s| s.raw_bytes).unwrap_or(0);
            let rows = resident_rows + spilled_rows;
            if rows == 0 {
                continue;
            }
            let raw_bytes = resident_bytes + spilled_bytes;
            let predicted =
                raw_bytes + predicted_agg_state_bytes(rows, group_cols, n_aggs, n_distinct);
            // An empty GROUP BY cannot be sub-partitioned (one global group
            // — every row hashes identically, so a finer modulus would put
            // everything in one sub anyway); its state is O(1) except for
            // DISTINCT's value set, which is irreducible without a sorted
            // spill of the values themselves (documented residual).
            let result_batches = if !self.group_by.is_empty() && predicted > memory_threshold {
                self.aggregate_partition_chunked(
                    idx,
                    resident,
                    spilled,
                    predicted,
                    memory_threshold,
                    &spill_dir,
                    &agg_exprs,
                )?
            } else {
                let mut batches: Vec<RecordBatch> = Vec::new();
                if let Some(sp) = &spilled {
                    batches.extend(read_parquet(&sp.file)?);
                }
                if let Some(part) = resident {
                    batches.extend(part.batches);
                }
                if batches.is_empty() {
                    continue;
                }
                let result =
                    crate::physical::operators::hash_agg::aggregate_batches_external_with_pool(
                        &batches,
                        &self.group_by,
                        &agg_exprs,
                        &self.schema,
                        &self.memory_pool,
                    )?;
                if result.num_rows() > 0 {
                    vec![result]
                } else {
                    Vec::new()
                }
            };
            all_results.extend(result_batches);
        }

        // All aggregate outputs are materialized; no returned stream reads
        // these files. Errors/cancellation before this point also own cleanup.
        drop(spill_directory);

        if all_results.is_empty() {
            // Return empty result with correct schema
            let empty_batch = RecordBatch::new_empty(self.schema.clone());
            return Ok(Box::pin(stream::once(async { Ok(empty_batch) })));
        }

        let all_results = if let Some(pred) = &self.post_filter {
            crate::physical::operators::filter_batches(all_results, pred)?
        } else {
            all_results
        };
        Ok(Box::pin(stream::iter(all_results.into_iter().map(Ok))))
    }

    fn name(&self) -> &str {
        "SpillableHashAggregate"
    }
}

impl SpillableHashAggregateExec {
    /// Evict one aggregate partition's resident batches to its (single,
    /// incrementally appended) spill file, leaving the partition resident
    /// and empty so it keeps accumulating in memory afterwards — an
    /// aggregate re-reads spilled + resident rows TOGETHER at finalize, so
    /// unlike the join's `evict_build_partition_to_disk` (which retires the
    /// partition entirely) there is no resident-vs-spilled routing
    /// dichotomy to maintain here.
    ///
    /// oom-safety-hardening task 002: this replaces the old
    /// `write_batches_to_parquet` + `merge_parquet_files` (read the whole
    /// existing file + rewrite + rename on EVERY eviction — the same
    /// O(n²)-in-bytes pattern `append_batch_streaming`'s doc comment
    /// records being fixed for the join in spill-join-correctness task
    /// 002) with the join's own open-writer plumbing, reused byte-for-byte:
    /// one `ArrowWriter` per partition, kept open across the whole
    /// ingestion phase, each eviction appending O(batch) row groups.
    fn evict_agg_partition_to_disk(
        &self,
        idx: usize,
        partitions: &mut [Option<AggregatePartition>],
        spilled: &mut [Option<SpilledAggPartition>],
        spill_writers: &mut [Option<ArrowWriter<File>>],
        spill_dir: &Path,
    ) -> Result<usize> {
        let Some(part) = partitions[idx].as_mut() else {
            return Ok(0);
        };
        if part.batches.is_empty() {
            return Ok(0);
        }
        let path = spill_dir.join(format!("agg_part_{}.parquet", idx));
        for b in &part.batches {
            append_batch_streaming(&mut spill_writers[idx], &path, b)?;
        }
        let freed = part.memory_bytes;
        let rows = part.rows;
        self.memory_pool.record_spill(freed);
        let sp = spilled[idx].get_or_insert_with(|| SpilledAggPartition {
            file: path,
            rows: 0,
            raw_bytes: 0,
        });
        sp.rows += rows;
        sp.raw_bytes += freed;
        part.clear();
        Ok(freed)
    }

    /// Process input with hash partitioning and spilling when memory limit
    /// is reached. Consumes `input_stream` batch by batch — combined with
    /// `execute()`'s streaming phase-1 reservation this is what keeps the
    /// spill path's ingestion memory bounded at ~`memory_threshold`
    /// regardless of input size (oom-safety-hardening task 002).
    async fn aggregate_with_spilling(
        &self,
        mut input_stream: RecordBatchStream,
        spill_dir: &PathBuf,
    ) -> Result<(
        Vec<Option<AggregatePartition>>,
        Vec<Option<SpilledAggPartition>>,
    )> {
        let mut partitions: Vec<Option<AggregatePartition>> = (0..NUM_PARTITIONS)
            .map(|_| Some(AggregatePartition::new()))
            .collect();
        let mut spilled: Vec<Option<SpilledAggPartition>> =
            (0..NUM_PARTITIONS).map(|_| None).collect();
        // One incrementally-written Parquet file per spilled partition,
        // kept OPEN for the whole ingestion phase and closed exactly once
        // at the end — the join's `build_with_partitioning` plumbing,
        // reused (see `evict_agg_partition_to_disk`).
        let mut spill_writers: Vec<Option<ArrowWriter<File>>> =
            (0..NUM_PARTITIONS).map(|_| None).collect();

        let mut total_memory: usize = 0;
        let memory_threshold =
            (self.config.memory_limit as f64 * self.config.spill_threshold) as usize;

        while let Some(big) = input_stream.try_next().await? {
            // Re-chunk over-large batches (an mmap-backed IPC scan emits
            // 65536-row slabs) into zero-copy slices. Spill accounting
            // decides BEFORE each addition; fed one slab bigger than the
            // whole budget it could decide nothing — the answer stayed
            // correct but the budget became advisory.
            let mut chunks: Vec<RecordBatch> = Vec::new();
            if big.num_rows() > AGG_CHUNK_ROWS {
                let mut off = 0;
                while off < big.num_rows() {
                    let len = AGG_CHUNK_ROWS.min(big.num_rows() - off);
                    chunks.push(big.slice(off, len));
                    off += len;
                }
            } else {
                chunks.push(big);
            }

            for batch in chunks {
                let batch_size = estimate_batch_size(&batch);

                // Check if we need to spill before adding more data.
                //
                // Ingestion charges resident partitions their BATCH bytes
                // only — deliberately NOT a predicted-state charge the way
                // the join's streaming loop charges predicted table bytes
                // (task 007): during aggregate ingestion no hash/accumulator
                // state exists yet (partitions hold raw rows), and the
                // state that eventually materializes at finalize covers
                // SPILLED rows too, so charging it against residency here
                // could not bound it. The state cost is priced where it
                // actually materializes: `execute()`'s finalize gate
                // (`predicted_agg_state_bytes` + `aggregate_partition_chunked`).
                // The batch is already in memory when this decision is made: record it.
                self.memory_pool.observe(total_memory + batch_size);
                if total_memory + batch_size > memory_threshold {
                    // Spill the largest partition (largest-first, matching
                    // the join: maximizes freed bytes per eviction).
                    if let Some(idx) = find_largest_agg_partition(&partitions) {
                        let freed = self.evict_agg_partition_to_disk(
                            idx,
                            &mut partitions,
                            &mut spilled,
                            &mut spill_writers,
                            spill_dir,
                        )?;
                        total_memory = total_memory.saturating_sub(freed);
                    }
                }

                // Partition the batch by group key hash
                let partitioned =
                    partition_batch_by_group_hash(&batch, &self.group_by, NUM_PARTITIONS)?;

                for (idx, part_batch) in partitioned.into_iter().enumerate() {
                    if let Some(pb) = part_batch {
                        let pb_size = estimate_batch_size(&pb);
                        if let Some(ref mut part) = partitions[idx] {
                            part.add_batch(pb);
                            total_memory += pb_size;
                            self.memory_pool.observe(total_memory);
                        }
                    }
                }
            }
        }

        close_spill_writers(spill_writers)?;
        Ok((partitions, spilled))
    }

    /// Chunked (sub-partitioned) read-back for one aggregate partition
    /// whose priced finalize cost (raw batch bytes + predicted aggregation
    /// state, see `execute()`'s finalize gate) exceeds the memory
    /// threshold — the aggregate analogue of task 007's chunked read-back
    /// in the join's `process_spilled_partition`.
    ///
    /// A join can chunk its build rows arbitrarily (probing is per-row);
    /// an aggregate cannot — every row of a group must reach ONE hash
    /// state. So chunking here is BY GROUP: the partition's rows (spill
    /// file streamed in `AGG_CHUNK_ROWS` batches, then the resident
    /// remainder) are re-routed with the SAME group-key hash at modulus
    /// `NUM_PARTITIONS * fan`. Rows of top-level partition `idx` satisfy
    /// `hash % NUM_PARTITIONS == idx`, so exactly `fan` residues
    /// `{idx + NUM_PARTITIONS * j}` occur; sub-partition `j = i /
    /// NUM_PARTITIONS` therefore holds a group-disjoint subset and each
    /// sub-aggregation sees every row of each of its groups — the same
    /// disjointness argument the top-level partitioning already relies on.
    /// One level only: a sub-partition is aggregated directly (documented
    /// residual: one sub's real state, targeted at ~threshold by `fan`).
    #[allow(clippy::too_many_arguments)]
    fn aggregate_partition_chunked(
        &self,
        idx: usize,
        resident: Option<AggregatePartition>,
        spilled: Option<SpilledAggPartition>,
        predicted_bytes: usize,
        memory_threshold: usize,
        spill_dir: &Path,
        agg_exprs: &[crate::physical::operators::hash_agg::AggregateExpr],
    ) -> Result<Vec<RecordBatch>> {
        let fan = predicted_bytes
            .div_ceil(memory_threshold.max(1))
            .clamp(2, NUM_PARTITIONS);
        let sub_paths: Vec<PathBuf> = (0..fan)
            .map(|j| spill_dir.join(format!("agg_sub_{}_{}.parquet", idx, j)))
            .collect();
        let mut sub_writers: Vec<Option<ArrowWriter<File>>> = (0..fan).map(|_| None).collect();
        if std::env::var("QE_SPILL_DEBUG").is_ok() {
            eprintln!(
                "[spill-agg] partition {} finalize predicted {} bytes > threshold {} — \
                 chunked read-back with fan {}",
                idx, predicted_bytes, memory_threshold, fan
            );
        }

        let group_by = &self.group_by;
        let route =
            |batch: &RecordBatch, sub_writers: &mut [Option<ArrowWriter<File>>]| -> Result<()> {
                let pieces = partition_batch_by_group_hash(batch, group_by, NUM_PARTITIONS * fan)?;
                for (i, pb) in pieces.into_iter().enumerate() {
                    let Some(pb) = pb else { continue };
                    if i % NUM_PARTITIONS != idx {
                        // Would silently split a group across sub-partitions —
                        // the group-hash must route identically at write time
                        // and read-back time. Fail loudly instead of ever
                        // returning wrong aggregates.
                        return Err(QueryError::Execution(format!(
                            "aggregate spill sub-partitioning routed rows of partition {} to \
                         residue {} — group-hash routing diverged across the spill round trip",
                            idx,
                            i % NUM_PARTITIONS
                        )));
                    }
                    let j = i / NUM_PARTITIONS;
                    append_batch_streaming(&mut sub_writers[j], &sub_paths[j], &pb)?;
                }
                Ok(())
            };

        if let Some(sp) = &spilled {
            // Stream the spill file back in bounded batches — never the
            // whole partition at once (that materialization is exactly
            // what this path exists to avoid).
            let file = File::open(&sp.file).map_err(|e| {
                QueryError::Execution(format!(
                    "Failed to open agg spill file {:?}: {}",
                    sp.file, e
                ))
            })?;
            let reader = ParquetRecordBatchReaderBuilder::try_new(file)?
                .with_batch_size(AGG_CHUNK_ROWS)
                .build()?;
            for batch in reader {
                route(&batch?, &mut sub_writers)?;
            }
        }
        if let Some(part) = resident {
            for b in &part.batches {
                route(b, &mut sub_writers)?;
            }
        }
        if let Some(sp) = &spilled {
            let _ = std::fs::remove_file(&sp.file);
        }
        close_spill_writers(sub_writers)?;

        let mut results = Vec::new();
        for path in &sub_paths {
            if !path.exists() {
                continue;
            }
            let batches = read_parquet(path)?;
            let _ = std::fs::remove_file(path);
            if batches.is_empty() {
                continue;
            }
            let result =
                crate::physical::operators::hash_agg::aggregate_batches_external_with_pool(
                    &batches,
                    &self.group_by,
                    agg_exprs,
                    &self.schema,
                    &self.memory_pool,
                )?;
            if result.num_rows() > 0 {
                results.push(result);
            }
        }
        Ok(results)
    }
}

impl fmt::Display for SpillableHashAggregateExec {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "SpillableHashAggregate")
    }
}

// ============================================================================
// External Sort
// ============================================================================

/// Sort execution operator with external merge sort support
pub struct ExternalSortExec {
    input: Arc<dyn PhysicalOperator>,
    order_by: Vec<crate::planner::SortExpr>,
    schema: SchemaRef,
    memory_pool: SharedMemoryPool,
    config: ExecutionConfig,
    /// Optional limit for Top-K optimization
    fetch: Option<usize>,
}

impl fmt::Debug for ExternalSortExec {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("ExternalSortExec")
            .field("order_by", &self.order_by)
            .finish()
    }
}

impl ExternalSortExec {
    pub fn new(
        input: Arc<dyn PhysicalOperator>,
        order_by: Vec<crate::planner::SortExpr>,
        memory_pool: SharedMemoryPool,
        config: ExecutionConfig,
    ) -> Self {
        let schema = input.schema();
        Self {
            input,
            order_by,
            schema,
            memory_pool,
            config,
            fetch: None,
        }
    }

    /// Create an external sort with a fetch limit (Top-K optimization).
    pub fn with_fetch(
        input: Arc<dyn PhysicalOperator>,
        order_by: Vec<crate::planner::SortExpr>,
        memory_pool: SharedMemoryPool,
        config: ExecutionConfig,
        fetch: usize,
    ) -> Self {
        let schema = input.schema();
        Self {
            input,
            order_by,
            schema,
            memory_pool,
            config,
            fetch: Some(fetch),
        }
    }
}

#[async_trait]
impl PhysicalOperator for ExternalSortExec {
    fn schema(&self) -> SchemaRef {
        self.schema.clone()
    }

    fn children(&self) -> Vec<Arc<dyn PhysicalOperator>> {
        vec![self.input.clone()]
    }

    async fn execute(&self, partition: usize) -> Result<RecordBatchStream> {
        // Sort always produces a single partition
        crate::physical::check_partition(self, partition)?;

        // Phase 1: reserve, possibly spill (oom-safety-hardening task 003 —
        // the same Photon-style streaming two-phase reservation the join's
        // `compute_build_decision` and the aggregate's `execute()` (task
        // 002) already ship, mirrored rather than reinvented). The OLD code
        // called `collect_input_partitions_concurrently`, which fully
        // drained the ENTIRE input into one flat `Vec<RecordBatch>` and
        // only THEN compared its total size against
        // `memory_limit * spill_threshold` — so an oversized input could
        // exhaust real memory during that initial collection, before the
        // spill decision ever ran (the harness `sort` scenario: 250M rows /
        // ~4GB streamed into a 256MB budget was kernel-OOM-killed under a
        // 1G cgroup cap, and aborted at ~1.9GB under the rlimit lever).
        // Now the input streams in via `stream_merge_input_partitions`
        // (same one-task-per-partition cross-core drain benefit, bounded
        // channel instead of a growing Vec) with a running size total
        // checked as each batch arrives.
        let memory_threshold =
            (self.config.memory_limit as f64 * self.config.spill_threshold) as usize;
        let mut input_stream =
            stream_merge_input_partitions(&self.input, &self.memory_pool, "sort input queue")
                .await?;
        let mut flat_batches: Vec<RecordBatch> = Vec::new();
        let mut flat_size: usize = 0;
        let mut crossing_batch: Option<RecordBatch> = None;
        while let Some(batch) = input_stream.try_next().await? {
            let batch_size = estimate_batch_size(&batch);
            // The batch is already in memory when this decision is made: record it.
            self.memory_pool.observe(flat_size + batch_size);
            if flat_size + batch_size > memory_threshold {
                crossing_batch = Some(batch);
                break;
            }
            flat_size += batch_size;
            self.memory_pool.observe(flat_size);
            flat_batches.push(batch);
        }

        if crossing_batch.is_none() {
            // Never crossed the threshold: the input genuinely fits — the
            // ordinary in-memory case, reached without ever risking an
            // unbounded collection to get here.
            if flat_batches.is_empty() {
                return Ok(Box::pin(stream::empty()));
            }
            // Data fits in memory — use the regular SortExec path for
            // correctness. Create a temporary MemoryTableExec with our
            // already-collected data.
            let mem = crate::physical::operators::MemoryTableExec::new(
                "sort_input",
                self.schema.clone(),
                flat_batches,
                None,
            );
            let sort = if let Some(fetch) = self.fetch {
                crate::physical::operators::SortExec::with_fetch(
                    Arc::new(mem),
                    self.order_by.clone(),
                    fetch,
                )
            } else {
                crate::physical::operators::SortExec::new(Arc::new(mem), self.order_by.clone())
            };
            return sort.execute(0).await;
        }

        // Threshold crossed mid-stream — external sort with spilling.
        self.config.ensure_spill_dir()?;

        let spill_id = SPILL_COUNTER.fetch_add(1, Ordering::Relaxed);
        let spill_dir = self
            .config
            .spill_path
            .join(format!("sort_{}_{}", partition, spill_id));
        let spill_directory = SpillDirectoryOwner::create(spill_dir.clone())?;

        if std::env::var("QE_SPILL_DEBUG").is_ok() {
            eprintln!(
                "[spill-sort] threshold crossed mid-stream at {} buffered batches ({} bytes, \
                 threshold {}) — entering streaming run-generation path",
                flat_batches.len() + 1,
                flat_size,
                memory_threshold
            );
        }

        // Phase 2: everything gathered so far (`flat_batches`), plus the
        // crossing batch, plus whatever remains of the stream, feeds
        // `generate_runs`'s bounded buffer-to-threshold / cut-sorted-run
        // ingestion loop. Nothing collected in phase 1 is thrown away or
        // re-pulled from the source (mirrors the aggregate's phase 2).
        let combined: RecordBatchStream = Box::pin(
            stream::iter(flat_batches.into_iter().chain(crossing_batch).map(Ok))
                .chain(input_stream),
        );

        // Generate sorted runs, batch by batch.
        let runs = self.generate_runs(combined, &spill_dir).await?;

        if std::env::var("QE_SPILL_DEBUG").is_ok() {
            eprintln!(
                "[spill-sort] {} sorted run(s) generated in {:?}",
                runs.len(),
                spill_dir
            );
        }

        if runs.is_empty() {
            drop(spill_directory);
            return Ok(Box::pin(stream::empty()));
        }

        // Merge the runs on a blocking thread, delivering merged batches
        // through a small bounded channel that IS this operator's output
        // stream — the merged result is never re-materialized into one
        // Vec (the full sorted output is the size of the entire input,
        // exactly what this operator just spilled to AVOID holding). The
        // merge machinery itself is unchanged (same multi-pass reduction,
        // same k-way merge core, same carried-run bookkeeping and
        // buffer-transition flush) — only the DELIVERY of already-built
        // output batches changed from `Vec::push` to a channel send.
        //
        // The merge thread owns spill-dir cleanup: it removes the
        // directory when the merge finishes, errors, OR aborts early
        // because the receiver was dropped (query abandoned / LIMIT
        // satisfied below — the next sink send fails and the merge
        // returns).
        let merger = self.merger();
        let (tx, rx) = tokio::sync::mpsc::channel::<Result<RecordBatch>>(4);
        let worker = tokio::task::spawn_blocking(move || {
            // Capture the owner BEFORE work starts. Closure drop before start,
            // normal return, error and unwind all clean up; started blocking
            // work retains files until its own last use after consumer drop.
            let _spill_directory = spill_directory;
            let batch_tx = tx.clone();
            let mut sink = move |batch: RecordBatch| -> Result<bool> {
                Ok(batch_tx.blocking_send(Ok(batch)).is_ok())
            };
            if let Err(e) = merger.merge_runs_into(&runs, &mut sink) {
                let _ = tx.blocking_send(Err(e));
            }
        });
        let merged = OwnedTaskOutputStream {
            label: "sort merge",
            receiver: rx,
            worker: Some(worker),
            finished: false,
        };

        // Apply the top-K `fetch` limit, mirroring the in-memory branch
        // above (`SortExec::with_fetch`). The top-k fusion rule in
        // `planner.rs` (`LogicalPlan::Limit` folding a `skip == 0` LIMIT
        // directly into `ExternalSortExec::with_fetch` instead of wrapping
        // a separate `LimitExec` around it) means THIS is the only place a
        // spilled `ORDER BY ... LIMIT N` query's row count is ever
        // truncated — the merge produces every row of the sort, not just
        // the top-K prefix (spill-join-correctness-2 task 004's fix,
        // preserved). Applied per arriving batch via the SAME
        // `truncate_batches_to_limit` helper (one implementation of the
        // slicing semantics, not two); once the limit is reached the
        // stream ends, the receiver drops, and the merge thread aborts
        // early instead of merging rows nobody will read.
        match self.fetch {
            Some(fetch) => Ok(Box::pin(SortFetchStream {
                input: Some(merged),
                remaining: fetch,
            })),
            None => Ok(Box::pin(merged)),
        }
    }

    fn name(&self) -> &str {
        "ExternalSort"
    }
}

impl ExternalSortExec {
    async fn generate_runs(
        &self,
        mut input_stream: RecordBatchStream,
        spill_dir: &PathBuf,
    ) -> Result<Vec<PathBuf>> {
        let mut runs = Vec::new();
        let mut buffer: Vec<RecordBatch> = Vec::new();
        let mut buffer_size: usize = 0;
        let memory_threshold =
            (self.config.memory_limit as f64 * self.config.spill_threshold) as usize;

        while let Some(batch) = input_stream.try_next().await? {
            let batch_size = estimate_batch_size(&batch);

            // The batch is already in memory when this decision is made: record it.
            self.memory_pool.observe(buffer_size + batch_size);
            if buffer_size + batch_size > memory_threshold && !buffer.is_empty() {
                // Sort buffer and write run
                let run_path = spill_dir.join(format!("run_{}.parquet", runs.len()));
                self.flush_run(&buffer, &run_path)?;
                runs.push(run_path);

                self.memory_pool.record_spill(buffer_size);
                buffer.clear();
                buffer_size = 0;
            }

            buffer.push(batch);
            buffer_size += batch_size;
            self.memory_pool.observe(buffer_size);
        }

        // Flush remaining buffer. This is still a spill — the run is written to
        // disk — so it must be recorded, otherwise a sort whose input arrives in
        // a single batch spills without ever reporting it in QueryMetrics.
        if !buffer.is_empty() {
            let run_path = spill_dir.join(format!("run_{}.parquet", runs.len()));
            self.flush_run(&buffer, &run_path)?;
            runs.push(run_path);

            self.memory_pool.record_spill(buffer_size);
        }

        Ok(runs)
    }

    fn flush_run(&self, batches: &[RecordBatch], path: &PathBuf) -> Result<()> {
        if batches.is_empty() {
            return Ok(());
        }

        // Concatenate under the batches' OWN actual schema, not the
        // declared/logical one (`self.schema`, derived from `PlanSchema` via
        // `plan_schema_to_arrow`, which has no Dictionary representation and
        // so always reports a string column as plain `Utf8`). A sort large
        // enough to spill over a Dictionary-encoded source (native tables;
        // also small-build join gathers, per the identical reasoning already
        // applied to the in-memory path) previously failed outright here
        // with "column types must match schema types, expected Utf8 but
        // found Dictionary(...)" — found by native-tables-mutation task
        // 006's real-scale (SF=10, 15M-row `orders`) cell-exact validation;
        // reproduces on an UNMUTATED native table too, so this is a
        // pre-existing gap in the spill path specifically, not something
        // mutation introduced. Mirrors the exact "if every batch agrees, use
        // their actual schema; otherwise cast Dictionary columns down to
        // their plain value type against the declared schema" pattern
        // `SortExec::execute()` (sort.rs) and `MemoryTableExec::execute()`
        // (scan.rs) already establish for the in-memory sort path.
        let first_schema = batches[0].schema();
        let all_agree = batches.iter().all(|b| b.schema() == first_schema);

        let combined = if all_agree {
            compute::concat_batches(&first_schema, batches)?
        } else {
            let normalized: Result<Vec<RecordBatch>> = batches
                .iter()
                .map(|b| {
                    let cols: std::result::Result<Vec<ArrayRef>, arrow::error::ArrowError> = b
                        .columns()
                        .iter()
                        .map(|c| match c.data_type() {
                            arrow::datatypes::DataType::Dictionary(_, v) => {
                                compute::cast(c.as_ref(), v)
                            }
                            _ => Ok(c.clone()),
                        })
                        .collect();
                    RecordBatch::try_new(self.schema.clone(), cols?).map_err(Into::into)
                })
                .collect();
            compute::concat_batches(&self.schema, &normalized?)?
        };

        // Sort
        let sorted = sort_batch(&combined, &self.order_by)?;

        // Write to disk
        write_batches_to_parquet(path, &[sorted])?;

        Ok(())
    }

    /// Build the owned, `'static` merge-machinery handle `execute()`'s
    /// spill branch hands to its blocking merge thread. The merge methods
    /// live on `SortRunMerger` (not `&self`) purely so they can be MOVED
    /// onto that thread — every algorithm is byte-for-byte the code that
    /// used to live on `ExternalSortExec` itself.
    fn merger(&self) -> SortRunMerger {
        SortRunMerger {
            order_by: self.order_by.clone(),
            schema: self.schema.clone(),
        }
    }

    /// Test-only Vec-collecting entry point (regression tests
    /// `external_sort_multi_pass_merge_survives_a_leftover_singleton_chunk`
    /// etc. call this); production merging goes through
    /// `SortRunMerger::merge_runs_into`'s sink form.
    #[cfg(test)]
    fn merge_runs(&self, runs: &[PathBuf]) -> Result<Vec<RecordBatch>> {
        let merger = self.merger();
        let mut out = Vec::new();
        let mut sink = |batch: RecordBatch| -> Result<bool> {
            out.push(batch);
            Ok(true)
        };
        merger.merge_runs_into(runs, &mut sink)?;
        Ok(out)
    }

    /// Test-only Vec-collecting entry point (regression test
    /// `k_way_merge_survives_a_run_needing_more_than_one_buffer_load`
    /// calls this).
    #[cfg(test)]
    fn streaming_k_way_merge(
        &self,
        runs: &[PathBuf],
        buffer_rows: usize,
    ) -> Result<Vec<RecordBatch>> {
        let merger = self.merger();
        let mut out = Vec::new();
        let mut sink = |batch: RecordBatch| -> Result<bool> {
            out.push(batch);
            Ok(true)
        };
        merger.streaming_k_way_merge_into(runs, buffer_rows, &mut sink)?;
        Ok(out)
    }
}

/// The run-merge machinery of `ExternalSortExec`, factored onto an owned,
/// `Send + 'static` value so `execute()`'s spill branch can run it on a
/// `spawn_blocking` thread that streams merged batches out through a
/// bounded channel instead of accumulating the ENTIRE sorted output into
/// one `Vec<RecordBatch>` (which is the size of the whole input — exactly
/// the materialization this operator spills to avoid;
/// oom-safety-hardening task 003). The algorithms themselves — multi-pass
/// reduction, carried-run bookkeeping, the k-way merge core with its
/// buffer-transition flush, `batch_with_actual_types` reconciliation —
/// are unchanged from when these methods lived on `ExternalSortExec`.
///
/// Every output-producing method takes a `sink: &mut dyn FnMut(RecordBatch)
/// -> Result<bool>`; a sink returning `Ok(false)` means "stop producing"
/// (the consumer is gone — query abandoned, or a fused `LIMIT` already
/// satisfied) and the merge returns early and cleanly.
struct SortRunMerger {
    order_by: Vec<crate::planner::SortExpr>,
    schema: SchemaRef,
}

impl SortRunMerger {
    /// Maximum number of runs to merge at once.
    const MAX_MERGE_FANIN: usize = 8;
    /// Maximum rows to buffer per run during merge.
    const MERGE_BUFFER_ROWS: usize = 8192;

    /// Merge `runs` (already individually sorted) into globally-sorted
    /// output batches, delivered through `sink`.
    fn merge_runs_into(
        &self,
        runs: &[PathBuf],
        sink: &mut dyn FnMut(RecordBatch) -> Result<bool>,
    ) -> Result<()> {
        if runs.is_empty() {
            return Ok(());
        }

        if runs.len() == 1 {
            // A single run is already globally sorted — stream it straight
            // off disk in bounded reads (the old code's `read_parquet`
            // one-shot load, made incremental).
            if !runs[0].is_file() {
                return Ok(());
            }
            let file = File::open(&runs[0]).map_err(|e| {
                QueryError::Execution(format!("Failed to open run file {:?}: {}", runs[0], e))
            })?;
            let reader = ParquetRecordBatchReaderBuilder::try_new(file)?
                .with_batch_size(Self::MERGE_BUFFER_ROWS)
                .build()?;
            for batch in reader {
                if !sink(batch?)? {
                    return Ok(());
                }
            }
            return Ok(());
        }

        // If we have too many runs, reduce in multiple passes first.
        if runs.len() > Self::MAX_MERGE_FANIN {
            let reduced = self.reduce_runs_to_fanin(runs, Self::MAX_MERGE_FANIN)?;
            return self.streaming_k_way_merge_into(&reduced, Self::MERGE_BUFFER_ROWS, sink);
        }

        // Single-pass k-way merge with bounded memory.
        self.streaming_k_way_merge_into(runs, Self::MERGE_BUFFER_ROWS, sink)
    }

    /// Multi-pass reduction for when there are too many runs: repeatedly
    /// merge `fanin`-sized chunks of runs into new on-disk runs until at
    /// most `fanin` remain (the FINAL merge is the caller's, so it can
    /// stream). Each chunk's merged output is sunk straight into an open
    /// `ArrowWriter` (`append_batch_streaming`, the join/agg spill paths'
    /// own open-writer plumbing) instead of the previous
    /// collect-into-a-Vec-then-`write_batches_to_parquet` — a chunk of
    /// `fanin` runs each ~`memory_threshold`-sized would otherwise
    /// materialize `fanin * threshold` bytes per intermediate pass.
    fn reduce_runs_to_fanin(&self, runs: &[PathBuf], fanin: usize) -> Result<Vec<PathBuf>> {
        let mut current_runs = runs.to_vec();
        let mut pass = 0;

        // Get spill directory from first run's parent
        let spill_dir = runs[0].parent().unwrap_or(std::path::Path::new("/tmp"));

        while current_runs.len() > fanin {
            let mut next_runs = Vec::new();

            for chunk in current_runs.chunks(fanin) {
                if chunk.len() == 1 {
                    next_runs.push(chunk[0].clone());
                } else {
                    // Merge this chunk into a new run, streamed batch by
                    // batch into an open writer (lazily created on the
                    // first batch, so an empty chunk merge creates no file
                    // and pushes no run — mirrors the old
                    // `if !merged.is_empty()` guard).
                    let output_path =
                        spill_dir.join(format!("merged_pass{}_{}.parquet", pass, next_runs.len()));
                    let mut writer_slot: Option<ArrowWriter<File>> = None;
                    {
                        let mut sink = |batch: RecordBatch| -> Result<bool> {
                            append_batch_streaming(&mut writer_slot, &output_path, &batch)?;
                            Ok(true)
                        };
                        self.streaming_k_way_merge_into(chunk, Self::MERGE_BUFFER_ROWS, &mut sink)?;
                    }
                    if let Some(writer) = writer_slot {
                        writer.close()?;
                        next_runs.push(output_path);
                    }
                }
            }

            // Clean up old runs from previous pass (except original runs).
            //
            // A chunk of exactly one leftover run (`chunk.len() == 1` above,
            // whenever `current_runs.len()` isn't an exact multiple of
            // `fanin`) is carried forward into `next_runs` UNCHANGED — same
            // path, not rewritten to a new `merged_pass{N}_*.parquet` file.
            // Unconditionally deleting every path in `current_runs` here
            // (the previous behavior) deleted that carried-forward file too,
            // even though `next_runs` (this iteration's own output, about to
            // become `current_runs` for the NEXT iteration or the final
            // merge below) still points at it — a real, deterministic crash
            // ("Failed to open run file ... No such file or directory") on
            // any multi-pass merge whose leftover-chunk arithmetic hits this
            // shape, not a rare/timing-dependent one. Skip deleting any path
            // that's still referenced by `next_runs`.
            if pass > 0 {
                let still_needed: std::collections::HashSet<&PathBuf> = next_runs.iter().collect();
                for run in &current_runs {
                    if !still_needed.contains(run) {
                        let _ = std::fs::remove_file(run);
                    }
                }
            }

            current_runs = next_runs;
            pass += 1;
        }

        Ok(current_runs)
    }

    /// Streaming k-way merge with bounded memory usage, delivering each
    /// built output batch through `sink` as soon as it exists instead of
    /// accumulating a `result_batches` Vec (whose total size is the whole
    /// merged output). The merge ALGORITHM — row-by-row min-scan, the
    /// buffer-transition flush, `build_merged_batch`(+`_final` fallback)
    /// construction — is unchanged.
    ///
    /// One hoist, semantics-preserving (oom-safety-hardening task 003):
    /// sort-key columns are evaluated ONCE per LOADED buffer
    /// (`eval_key_cols`), not twice per row-COMPARISON as the old
    /// `compare_rows` closure did — `evaluate_expr` is deterministic per
    /// batch, so per-comparison re-evaluation only cost time (billions of
    /// calls for a 250M-row merge: rows × fan-in × keys × 2), never
    /// changed a result. A key expression that fails to evaluate is
    /// skipped for the comparison (both sides), exactly as the old
    /// `.ok()`-based closure did.
    fn streaming_k_way_merge_into(
        &self,
        runs: &[PathBuf],
        buffer_rows: usize,
        sink: &mut dyn FnMut(RecordBatch) -> Result<bool>,
    ) -> Result<()> {
        use std::cmp::Ordering;

        if runs.is_empty() {
            return Ok(());
        }

        // Open iterators for each run
        let mut run_iterators: Vec<
            Box<dyn Iterator<Item = std::result::Result<RecordBatch, arrow::error::ArrowError>>>,
        > = Vec::new();
        let mut run_buffers: Vec<Option<RecordBatch>> = Vec::new();
        let mut run_indices: Vec<usize> = Vec::new(); // Current row index in each buffer
                                                      // Hoisted sort-key columns for each run's CURRENT buffer, one
                                                      // entry per `order_by` expression (None = that key failed to
                                                      // evaluate against this buffer — skipped in comparisons, matching
                                                      // the old per-comparison `.ok()` behavior).
        let mut run_keys: Vec<Vec<Option<ArrayRef>>> = Vec::new();

        let eval_key_cols = |batch: &RecordBatch| -> Vec<Option<ArrayRef>> {
            self.order_by
                .iter()
                .map(|s| evaluate_expr(batch, &s.expr).ok())
                .collect()
        };

        for run in runs {
            let file = File::open(run).map_err(|e| {
                QueryError::Execution(format!("Failed to open run file {:?}: {}", run, e))
            })?;
            let builder =
                ParquetRecordBatchReaderBuilder::try_new(file)?.with_batch_size(buffer_rows);
            let reader = builder.build()?;
            run_iterators.push(Box::new(reader));
            run_buffers.push(None);
            run_indices.push(0);
            run_keys.push(Vec::new());
        }

        // Load initial batch from each run
        for (i, iter) in run_iterators.iter_mut().enumerate() {
            if let Some(batch_result) = iter.next() {
                let batch = batch_result?;
                run_keys[i] = eval_key_cols(&batch);
                run_buffers[i] = Some(batch);
                run_indices[i] = 0;
            }
        }

        // Build output batches using a simple row-by-row merge
        // For better performance, we'd want to do vectorized merge, but this is memory-safe
        let mut output_rows: Vec<(usize, usize)> = Vec::new(); // (run_idx, row_idx)

        // Helper to compare rows via the hoisted key columns.
        let compare_rows = |keys_a: &[Option<ArrayRef>],
                            row_a: usize,
                            keys_b: &[Option<ArrayRef>],
                            row_b: usize,
                            order_by: &[crate::planner::SortExpr]|
         -> std::cmp::Ordering {
            for (key_idx, sort_expr) in order_by.iter().enumerate() {
                if let (Some(a), Some(b)) = (&keys_a[key_idx], &keys_b[key_idx]) {
                    let cmp = compare_array_values(a, row_a, b, row_b);
                    let cmp = if sort_expr.direction == crate::planner::SortDirection::Desc {
                        cmp.reverse()
                    } else {
                        cmp
                    };
                    if cmp != Ordering::Equal {
                        return cmp;
                    }
                }
            }
            Ordering::Equal
        };

        // Simple merge: repeatedly find minimum across all runs
        loop {
            // Find run with minimum current row
            let mut min_run: Option<usize> = None;

            for (run_idx, buffer) in run_buffers.iter().enumerate() {
                if let Some(ref batch) = buffer {
                    if run_indices[run_idx] < batch.num_rows() {
                        min_run = match min_run {
                            None => Some(run_idx),
                            Some(current_min) => {
                                let cmp = compare_rows(
                                    &run_keys[run_idx],
                                    run_indices[run_idx],
                                    &run_keys[current_min],
                                    run_indices[current_min],
                                    &self.order_by,
                                );
                                if cmp == Ordering::Less {
                                    Some(run_idx)
                                } else {
                                    Some(current_min)
                                }
                            }
                        };
                    }
                }
            }

            match min_run {
                None => break, // All runs exhausted
                Some(run_idx) => {
                    output_rows.push((run_idx, run_indices[run_idx]));
                    run_indices[run_idx] += 1;

                    // Check if current buffer is exhausted
                    if let Some(ref batch) = run_buffers[run_idx] {
                        if run_indices[run_idx] >= batch.num_rows() {
                            // `output_rows` holds (run_idx, row_idx) pairs
                            // where row_idx indexes into `run_buffers
                            // [run_idx]`'s CURRENT in-memory batch — a
                            // reference that goes stale (silently wrong, or
                            // out-of-bounds and panicking) the instant that
                            // slot is overwritten below. A run whose
                            // Parquet file needs more than one
                            // `buffer_rows`-sized read (any spill run
                            // larger than `MERGE_BUFFER_ROWS` = 8192 rows —
                            // the common case for a real spill, not an edge
                            // case) reloads mid-merge, and any row pushed
                            // from an EARLIER load of this exact slot that
                            // had not yet been flushed becomes a dangling
                            // reference: `build_merged_batch` would gather
                            // it from the NEW batch at the OLD row_idx —
                            // silently wrong data if the new batch happens
                            // to be at least that long, or an out-of-bounds
                            // panic ("the len is N but the index is N")
                            // otherwise. Found by native-tables-mutation
                            // task 006's real-scale (SF=10, 15M-row
                            // `orders`) `ORDER BY` validation — a spill
                            // large enough to need >1 run AND any run
                            // >8192 rows reaches this every time; TPC-H's
                            // own suite apparently never spills a sort this
                            // large. Flushing HERE, before the slot is
                            // overwritten, guarantees every row in
                            // `output_rows` always indexes into whichever
                            // batch is CURRENTLY loaded for its run — the
                            // invariant `build_merged_batch` requires.
                            if !output_rows.is_empty() {
                                let batch = self.build_merged_batch(&run_buffers, &output_rows)?;
                                output_rows.clear();
                                if !sink(batch)? {
                                    return Ok(());
                                }
                            }
                            // Try to load next batch from this run
                            if let Some(next_batch) = run_iterators[run_idx].next() {
                                let batch = next_batch?;
                                run_keys[run_idx] = eval_key_cols(&batch);
                                run_buffers[run_idx] = Some(batch);
                                run_indices[run_idx] = 0;
                            } else {
                                run_buffers[run_idx] = None;
                                run_keys[run_idx] = Vec::new();
                            }
                        }
                    }

                    // Flush output when buffer is full
                    if output_rows.len() >= buffer_rows {
                        let batch = self.build_merged_batch(&run_buffers, &output_rows)?;
                        output_rows.clear();
                        if !sink(batch)? {
                            return Ok(());
                        }
                    }
                }
            }
        }

        // Flush remaining output. With the flush-before-buffer-transition
        // fix above, every run's exhaustion (buffer -> None) flushes
        // `output_rows` first, and the loop only exits once every run has
        // exhausted — so in practice `output_rows` is always already empty
        // here. Kept as a defensive fallback (not proven unreachable by an
        // exhaustive proof, just by construction of the loop above) rather
        // than deleted outright.
        if !output_rows.is_empty() {
            // For the final batch, we need to reload any exhausted buffers
            // that are referenced in output_rows
            let batch = self.build_merged_batch_final(runs, &output_rows, buffer_rows)?;
            if !sink(batch)? {
                return Ok(());
            }
        }

        Ok(())
    }

    /// Build a merged batch from the given row references.
    ///
    /// Fast path (oom-safety-hardening task 003, semantics-preserving):
    /// when every referenced run buffer is present, wide enough, and the
    /// referenced buffers agree on column types, gather with ONE
    /// `arrow::compute::interleave` call per column — the kernel built for
    /// exactly this (row_idx, batch)-addressed k-way-merge output shape —
    /// instead of the generic path below, which materializes a fresh
    /// 1-ROW array per output row per column and then concatenates
    /// thousands of them (the dominant merge cost at real spill scale:
    /// 2 arrays/row/column). The generic path is KEPT verbatim as the
    /// fallback for any shape the fast path can't prove safe (missing
    /// buffer, short batch, cross-run type disagreement), and both paths
    /// end in the same `batch_with_actual_types` reconciliation.
    fn build_merged_batch(
        &self,
        run_buffers: &[Option<RecordBatch>],
        rows: &[(usize, usize)],
    ) -> Result<RecordBatch> {
        if rows.is_empty() {
            return Ok(RecordBatch::new_empty(self.schema.clone()));
        }

        let num_cols = self.schema.fields().len();

        // ---- interleave fast path ------------------------------------
        let mut referenced: Vec<usize> = rows.iter().map(|&(run_idx, _)| run_idx).collect();
        referenced.sort_unstable();
        referenced.dedup();

        let mut fast_ok = referenced
            .iter()
            .all(|&r| matches!(&run_buffers[r], Some(b) if b.num_columns() >= num_cols));
        if fast_ok {
            if let Some((&first_ref, rest)) = referenced.split_first() {
                let first = run_buffers[first_ref].as_ref().unwrap();
                'cols: for col_idx in 0..num_cols {
                    let dt = first.column(col_idx).data_type();
                    for &r in rest {
                        if run_buffers[r].as_ref().unwrap().column(col_idx).data_type() != dt {
                            fast_ok = false;
                            break 'cols;
                        }
                    }
                }
            }
        }
        if fast_ok {
            // Dense position of each referenced run in the interleave
            // input array list.
            let mut dense_pos = vec![usize::MAX; run_buffers.len()];
            for (pos, &r) in referenced.iter().enumerate() {
                dense_pos[r] = pos;
            }
            let indices: Vec<(usize, usize)> = rows
                .iter()
                .map(|&(run_idx, row_idx)| (dense_pos[run_idx], row_idx))
                .collect();
            let mut final_columns: Vec<ArrayRef> = Vec::with_capacity(num_cols);
            for col_idx in 0..num_cols {
                let arrays: Vec<&dyn arrow::array::Array> = referenced
                    .iter()
                    .map(|&r| run_buffers[r].as_ref().unwrap().column(col_idx).as_ref())
                    .collect();
                final_columns.push(compute::interleave(&arrays, &indices)?);
            }
            return batch_with_actual_types(&self.schema, final_columns);
        }
        // ---- generic fallback (pre-existing path, unchanged) ---------

        // Group rows by run
        let mut run_row_groups: HashMap<usize, Vec<(usize, usize)>> = HashMap::new();
        for (output_idx, &(run_idx, row_idx)) in rows.iter().enumerate() {
            run_row_groups
                .entry(run_idx)
                .or_default()
                .push((output_idx, row_idx));
        }

        // Build output columns
        let mut output_columns: Vec<Vec<(usize, ArrayRef)>> = vec![Vec::new(); num_cols];

        for (run_idx, row_list) in run_row_groups {
            if let Some(ref batch) = run_buffers[run_idx] {
                let take_indices: Vec<u32> = row_list.iter().map(|(_, r)| *r as u32).collect();
                let indices_arr = UInt32Array::from(take_indices);

                for col_idx in 0..num_cols.min(batch.num_columns()) {
                    let taken = compute::take(batch.column(col_idx), &indices_arr, None)?;
                    for (i, (out_idx, _)) in row_list.iter().enumerate() {
                        let single =
                            compute::take(&taken, &UInt32Array::from(vec![i as u32]), None)?;
                        output_columns[col_idx].push((*out_idx, single));
                    }
                }
            }
        }

        // Sort and concatenate columns
        let mut final_columns: Vec<ArrayRef> = Vec::new();
        for col_parts in output_columns {
            let mut sorted_parts = col_parts;
            sorted_parts.sort_by_key(|(idx, _)| *idx);
            let arrays: Vec<&dyn arrow::array::Array> =
                sorted_parts.iter().map(|(_, arr)| arr.as_ref()).collect();
            if arrays.is_empty() {
                final_columns.push(arrow::array::new_null_array(
                    self.schema.field(final_columns.len()).data_type(),
                    rows.len(),
                ));
            } else {
                final_columns.push(compute::concat(&arrays)?);
            }
        }

        batch_with_actual_types(&self.schema, final_columns)
    }

    /// Build final merged batch, reloading data from files if needed
    fn build_merged_batch_final(
        &self,
        runs: &[PathBuf],
        rows: &[(usize, usize)],
        _buffer_rows: usize,
    ) -> Result<RecordBatch> {
        if rows.is_empty() {
            return Ok(RecordBatch::new_empty(self.schema.clone()));
        }

        // For the final batch, we may need to re-read some runs
        // Group by run and load only what we need
        let mut run_row_groups: HashMap<usize, Vec<(usize, usize)>> = HashMap::new();
        for (output_idx, &(run_idx, row_idx)) in rows.iter().enumerate() {
            run_row_groups
                .entry(run_idx)
                .or_default()
                .push((output_idx, row_idx));
        }

        let num_cols = self.schema.fields().len();
        let mut output_columns: Vec<Vec<(usize, ArrayRef)>> = vec![Vec::new(); num_cols];

        for (run_idx, row_list) in run_row_groups {
            // Read the run
            let batches = read_parquet(&runs[run_idx])?;
            if batches.is_empty() {
                continue;
            }

            // Concatenate all batches from this run
            let combined = compute::concat_batches(&batches[0].schema(), &batches)?;

            let take_indices: Vec<u32> = row_list.iter().map(|(_, r)| *r as u32).collect();
            let indices_arr = UInt32Array::from(take_indices);

            for col_idx in 0..num_cols.min(combined.num_columns()) {
                let taken = compute::take(combined.column(col_idx), &indices_arr, None)?;
                for (i, (out_idx, _)) in row_list.iter().enumerate() {
                    let single = compute::take(&taken, &UInt32Array::from(vec![i as u32]), None)?;
                    output_columns[col_idx].push((*out_idx, single));
                }
            }
        }

        // Sort and concatenate columns
        let mut final_columns: Vec<ArrayRef> = Vec::new();
        for col_parts in output_columns {
            let mut sorted_parts = col_parts;
            sorted_parts.sort_by_key(|(idx, _)| *idx);
            let arrays: Vec<&dyn arrow::array::Array> =
                sorted_parts.iter().map(|(_, arr)| arr.as_ref()).collect();
            if arrays.is_empty() {
                final_columns.push(arrow::array::new_null_array(
                    self.schema.field(final_columns.len()).data_type(),
                    rows.len(),
                ));
            } else {
                final_columns.push(compute::concat(&arrays)?);
            }
        }

        batch_with_actual_types(&self.schema, final_columns)
    }
}

/// Build a `RecordBatch` from columns whose ACTUAL data types may not match
/// `declared`'s (a `plan_schema_to_arrow`-derived schema, which has no
/// Dictionary representation and so always claims a string column is plain
/// `Utf8` even when the real data — native table segments, small-build join
/// gathers, or either round-tripped through this operator's own Parquet
/// spill files, which faithfully preserve Dictionary via the embedded
/// `ARROW:schema` metadata `ArrowWriter`/`ParquetRecordBatchReaderBuilder`
/// already use — is `Dictionary(Int32, Utf8)`). Widens the declared field
/// type to the actual column's type wherever they disagree, mirroring the
/// identical fix already established for the in-memory sort path
/// (`SortExec::execute()` in sort.rs, `MemoryTableExec::execute()`'s
/// `rewrap` in scan.rs) and for joins (`hash_join.rs`'s own
/// `batch_with_actual_types`, not reused directly across the module
/// boundary — this file follows the same local-duplication convention
/// those two other sites already established rather than introducing a
/// new cross-module dependency for a three-line function). Found by
/// native-tables-mutation task 006's real-scale (SF=10, 15M-row `orders`)
/// cell-exact `ORDER BY` validation — reproduces on an unmutated native
/// table too, so this is a pre-existing gap in the external-sort spill
/// path specifically, not something mutation introduced.
fn batch_with_actual_types(declared: &SchemaRef, columns: Vec<ArrayRef>) -> Result<RecordBatch> {
    let types_match = columns
        .iter()
        .zip(declared.fields())
        .all(|(c, f)| c.data_type() == f.data_type());
    let schema = if types_match {
        declared.clone()
    } else {
        Arc::new(Schema::new(
            declared
                .fields()
                .iter()
                .zip(&columns)
                .map(|(f, c)| {
                    if f.data_type() == c.data_type() {
                        f.as_ref().clone()
                    } else {
                        f.as_ref()
                            .clone()
                            .with_data_type(c.data_type().clone())
                            .with_nullable(true)
                    }
                })
                .collect::<Vec<_>>(),
        ))
    };
    RecordBatch::try_new(schema, columns).map_err(Into::into)
}

impl fmt::Display for ExternalSortExec {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let order: Vec<String> = self
            .order_by
            .iter()
            .map(|s| format!("{}", s.expr))
            .collect();
        write!(f, "ExternalSort: [{}]", order.join(", "))
    }
}

// ============================================================================
// Helper Functions
// ============================================================================

/// Truncate a sequence of already-globally-sorted batches to the first
/// `limit` rows total, dropping/slicing batches as needed. Used by
/// `ExternalSortExec::execute()`'s spill branch to apply a `LIMIT` fused
/// into a `fetch` (see the top-k fusion rule in `planner.rs`) — the merge
/// step produces every row of the sort, not just the top-K prefix, so this
/// is the only place that prefix gets cut down to exactly `limit` rows.
fn truncate_batches_to_limit(batches: Vec<RecordBatch>, limit: usize) -> Vec<RecordBatch> {
    let mut remaining = limit;
    let mut out = Vec::new();
    for batch in batches {
        if remaining == 0 {
            break;
        }
        if batch.num_rows() <= remaining {
            remaining -= batch.num_rows();
            out.push(batch);
        } else {
            out.push(batch.slice(0, remaining));
            remaining = 0;
        }
    }
    out
}

/// Estimate the memory size of a RecordBatch
/// Bytes a batch LOGICALLY holds, computed slice-aware.
///
/// `get_array_memory_size()` reports the CAPACITY of the underlying buffers,
/// which for an array sliced out of a larger allocation — every batch an
/// mmap-backed IPC read produces — counts the whole mapping per batch. Spill
/// decisions made on that number spill everything unconditionally (and the
/// spilled join's build-side estimate was off by ~50x, and by ~4,000x for a
/// Dictionary-column-heavy build side — see below). Offsets-based sizing
/// counts the rows the batch actually references; unknown types fall back to
/// a slice-aware generic computation (see below), which over- rather than
/// under-counts (the safe direction for a spill decision) but never counts
/// an mmap segment's whole on-disk size.
///
/// `spill-size-estimate-fix` epic, task 001 (2026-08-28): the generic
/// fallback used to be `c.get_array_memory_size()`, which walks each
/// `Buffer`'s `capacity()` — and for a `Buffer` built by
/// `Buffer::from_custom_allocation` (every column read through
/// `ipc_cache.rs`'s mmap path, i.e. every native-table and IPC-sidecar
/// scan), `capacity()` unconditionally returns the FULL LENGTH PASSED AT
/// MMAP TIME, forever, regardless of how small a slice/sub-buffer is later
/// carved out of it (`Bytes::capacity()`'s `Deallocation::Custom(_, size)`
/// arm returns the original `size`, not the current view's length — see
/// arrow-buffer's `bytes.rs`). One mmap `Buffer` backs an ENTIRE segment
/// file and is shared by every column's every sub-buffer in that segment,
/// so ANY type reaching this fallback reported the whole segment file's
/// on-disk size as its own — confirmed via `examples/
/// spill_size_estimate_check.rs`: Q12's real ~42MB Dictionary-column-heavy
/// build side estimated at ~167.7GB (~4,000x over), which crossed the spill
/// threshold and forced an unnecessary spill.
///
/// Fix: fall back to `ArrayData::get_slice_memory_size()` (arrow-data)
/// instead. It computes size purely from the array's own LOGICAL length and
/// data-type layout — for `Dictionary(K, V)` specifically: `self.len *
/// size_of::<K>()` for the keys (the type's own `layout()` delegates to the
/// key type's fixed-width layout) PLUS the dictionary VALUES array's own
/// real content bytes, computed by recursing into `child_data[0]` (arrow
/// stores a `DictionaryArray`'s values as its first — and only — child
/// `ArrayData`) — i.e. exactly `keys.len() * key_width +
/// dictionary_values_actual_bytes`, this function's own target formula, but
/// generalized by arrow itself to ANY key/value type combination rather
/// than hand-rolled against one hard-coded `Int32Type`/`StringArray` shape.
/// It NEVER reads `Buffer::capacity()`. This generalizes the SAME fix to
/// every other type that previously reached this fallback and could carry
/// the identical mmap-capacity-vs-logical-content problem — `LargeUtf8`/
/// `LargeBinary` (content-aware via `typed_offsets::<i64>()`, the exact
/// same offsets-delta approach this function's own Utf8/Binary branch
/// above already uses by hand), `FixedSizeBinary`/`Union` (fixed-width,
/// scaled by `self.len`, not by buffer capacity), and `List`/`LargeList`/
/// `Struct`/`Map`/`FixedSizeList`/`RunEndEncoded` (offsets sized by
/// `self.len`, recursing into child `ArrayData` the same way Dictionary's
/// values do) — audited against this engine's actual mmap-backed write
/// surface: `NativeManifest::ManifestDataType::from_arrow` (`src/storage/
/// native_manifest.rs`) is the ONLY schema gate a native table (or an IPC
/// sidecar, which mirrors the same coercion) can be written through, and it
/// explicitly REJECTS every nested type (List/Struct/Map/Union/
/// FixedSizeList/RunEndEncoded) at write time — so those are not reachable
/// via this engine's own mmap-backed tables today, but are still fixed here
/// defensively (never worse than the old behavior, no correctness/
/// performance cost when unreached) rather than left as a live landmine for
/// a future writer that adds them. `.unwrap_or_else(|_| c.
/// get_array_memory_size())` is a defensive-only fallback for the
/// `Result`'s error path (not expected to fire for any type this function
/// can be called with) — if it ever does, it lands back on the OLD,
/// over-counting-safe behavior, never a new failure mode.
fn estimate_batch_size(batch: &RecordBatch) -> usize {
    use arrow::array::Array;
    batch
        .columns()
        .iter()
        .map(|c| {
            let rows = c.len();
            let null_bytes = rows.div_ceil(8);
            match c.data_type() {
                t if t.primitive_width().is_some() => {
                    rows * t.primitive_width().unwrap_or(8) + null_bytes
                }
                arrow::datatypes::DataType::Boolean => rows.div_ceil(8) + null_bytes,
                arrow::datatypes::DataType::Utf8 | arrow::datatypes::DataType::Binary => {
                    let data: usize = match c.as_any().downcast_ref::<arrow::array::StringArray>() {
                        Some(a) if rows > 0 => {
                            (a.value_offsets()[rows] - a.value_offsets()[0]) as usize
                        }
                        _ => match c.as_any().downcast_ref::<arrow::array::BinaryArray>() {
                            Some(a) if rows > 0 => {
                                (a.value_offsets()[rows] - a.value_offsets()[0]) as usize
                            }
                            _ => 0,
                        },
                    };
                    data + rows * 4 + null_bytes
                }
                _ => c
                    .to_data()
                    .get_slice_memory_size()
                    .unwrap_or_else(|_| c.get_array_memory_size()),
            }
        })
        .sum()
}

/// Find the index of the largest partition
fn find_largest_partition(partitions: &[Option<BuildPartition>]) -> Option<usize> {
    partitions
        .iter()
        .enumerate()
        .filter_map(|(idx, p)| p.as_ref().map(|part| (idx, part.memory_bytes)))
        .max_by_key(|(_, size)| *size)
        .map(|(idx, _)| idx)
}

/// Find the index of the largest aggregate partition
fn find_largest_agg_partition(partitions: &[Option<AggregatePartition>]) -> Option<usize> {
    partitions
        .iter()
        .enumerate()
        .filter_map(|(idx, p)| p.as_ref().map(|part| (idx, part.memory_bytes)))
        .max_by_key(|(_, size)| *size)
        .map(|(idx, _)| idx)
}

/// Compare two array values at given indices
fn compare_array_values(
    a: &ArrayRef,
    row_a: usize,
    b: &ArrayRef,
    row_b: usize,
) -> std::cmp::Ordering {
    use std::cmp::Ordering;

    // Handle nulls
    let a_null = a.is_null(row_a);
    let b_null = b.is_null(row_b);

    match (a_null, b_null) {
        (true, true) => return Ordering::Equal,
        (true, false) => return Ordering::Greater, // nulls last
        (false, true) => return Ordering::Less,
        (false, false) => {}
    }

    // Compare based on type
    if let Some(arr_a) = a.as_any().downcast_ref::<Int64Array>() {
        if let Some(arr_b) = b.as_any().downcast_ref::<Int64Array>() {
            return arr_a.value(row_a).cmp(&arr_b.value(row_b));
        }
    }

    if let Some(arr_a) = a.as_any().downcast_ref::<arrow::array::Int32Array>() {
        if let Some(arr_b) = b.as_any().downcast_ref::<arrow::array::Int32Array>() {
            return arr_a.value(row_a).cmp(&arr_b.value(row_b));
        }
    }

    if let Some(arr_a) = a.as_any().downcast_ref::<Float64Array>() {
        if let Some(arr_b) = b.as_any().downcast_ref::<Float64Array>() {
            let va = arr_a.value(row_a);
            let vb = arr_b.value(row_b);
            return va.partial_cmp(&vb).unwrap_or(Ordering::Equal);
        }
    }

    if let Some(arr_a) = a.as_any().downcast_ref::<StringArray>() {
        if let Some(arr_b) = b.as_any().downcast_ref::<StringArray>() {
            return arr_a.value(row_a).cmp(arr_b.value(row_b));
        }
    }

    if let Some(arr_a) = a.as_any().downcast_ref::<Date32Array>() {
        if let Some(arr_b) = b.as_any().downcast_ref::<Date32Array>() {
            return arr_a.value(row_a).cmp(&arr_b.value(row_b));
        }
    }

    Ordering::Equal
}

/// Partition a batch by hash of key columns
/// The join spill path's ONE partition-routing definition (join-spill-
/// streaming task 003): the partition id of every row of `batch`. Used by
/// `partition_batch_by_hash` (build side, single-batch probe callers) and
/// by phase A's grouped probe path (`phase_a_process_group`), so both
/// route a key identically by construction.
fn partition_row_ids(
    batch: &RecordBatch,
    key_exprs: &[Expr],
    num_partitions: usize,
) -> Result<Vec<u32>> {
    // task 004: `join_key_arrays` (Dictionary keys decoded; everything
    // else byte-identical to the previous inline evaluation).
    let key_arrays = join_key_arrays(batch, key_exprs)?;
    let mut ids: Vec<u32> = Vec::with_capacity(batch.num_rows());
    for row in 0..batch.num_rows() {
        let key = extract_join_key(&key_arrays, row);
        // EXPLICITLY seeded: partition routing must give the same answer for
        // the same key from every call site. hashbrown 0.14's default hasher
        // happened to be deterministic across instances (ahash with fixed
        // fallback keys); 0.17's foldhash seeds PER INSTANCE, which shattered
        // groups across partitions. Never rely on a default for this.
        let mut hasher = xxhash_rust::xxh64::Xxh64::new(0x517c_c1b7_2722_0a95);
        key.hash(&mut hasher);
        ids.push(((hasher.finish() as usize) % num_partitions) as u32);
    }
    Ok(ids)
}

fn partition_batch_by_hash(
    batch: &RecordBatch,
    key_exprs: &[Expr],
    num_partitions: usize,
) -> Result<Vec<Option<RecordBatch>>> {
    // Compute partition for each row
    let mut partition_indices: Vec<Vec<usize>> = (0..num_partitions).map(|_| Vec::new()).collect();
    for (row, p) in partition_row_ids(batch, key_exprs, num_partitions)?
        .into_iter()
        .enumerate()
    {
        partition_indices[p as usize].push(row);
    }

    // Build batches for each partition
    let mut result: Vec<Option<RecordBatch>> = Vec::with_capacity(num_partitions);

    for indices in partition_indices {
        if indices.is_empty() {
            result.push(None);
        } else {
            let indices_arr =
                UInt32Array::from(indices.iter().map(|&i| i as u32).collect::<Vec<_>>());
            let columns: Result<Vec<ArrayRef>> = batch
                .columns()
                .iter()
                .map(|col| compute::take(col.as_ref(), &indices_arr, None).map_err(Into::into))
                .collect();
            let part_batch = RecordBatch::try_new(batch.schema(), columns?)?;
            result.push(Some(part_batch));
        }
    }

    Ok(result)
}

/// `SpillableHashAggregateExec`'s partition routing (oom-safety-hardening
/// task 002): the same fixed-seed `hash % num_partitions` loop as
/// `partition_batch_by_hash`, with ONE aggregate-specific difference — a
/// `Dictionary`-encoded group-key column is decoded to its value type
/// before key extraction. `extract_join_key`'s downcast chain has no
/// Dictionary arm (it falls through to `JoinValue::Null`), which for the
/// JOIN is merely degenerate routing, but for an aggregate would (a) route
/// EVERY row of a Dictionary-keyed GROUP BY into one partition (still
/// correct — groups never split — but the memory bounding this operator
/// exists for degenerates to nothing) and (b) make the finalize step's
/// sub-partitioning (`aggregate_partition_chunked`) structurally unable to
/// split such a partition. Decoding makes the routing value the SAME
/// string `hash_agg::extract_group_value` resolves a Dictionary key to,
/// and it is applied identically at ingestion time and read-back time
/// (Parquet spill files preserve Dictionary via the embedded Arrow
/// schema), so routing is stable across the spill round trip.
///
/// Deliberately a SEPARATE function rather than a change to
/// `partition_batch_by_hash`: that function is part of the join's
/// build/probe partition routing, which oom-safety-hardening task 002 is
/// hard-bounded from touching (the open ~0.34% duplicate-counting bug
/// lives somewhere in that logic; its routing must stay byte-identical).
fn partition_batch_by_group_hash(
    batch: &RecordBatch,
    group_by: &[Expr],
    num_partitions: usize,
) -> Result<Vec<Option<RecordBatch>>> {
    let key_arrays: Result<Vec<ArrayRef>> = group_by
        .iter()
        .map(|e| {
            let arr = evaluate_expr(batch, e)?;
            match arr.data_type() {
                arrow::datatypes::DataType::Dictionary(_, value_type) => {
                    compute::cast(arr.as_ref(), value_type).map_err(Into::into)
                }
                _ => Ok(arr),
            }
        })
        .collect();
    let key_arrays = key_arrays?;

    let mut partition_indices: Vec<Vec<usize>> = (0..num_partitions).map(|_| Vec::new()).collect();
    for row in 0..batch.num_rows() {
        let key = extract_join_key(&key_arrays, row);
        // Same EXPLICITLY seeded hasher as `partition_batch_by_hash` (see
        // its comment): routing must give the same answer for the same key
        // from every call site — including this function called at modulus
        // `NUM_PARTITIONS` (ingestion) and `NUM_PARTITIONS * fan`
        // (chunked read-back), whose residues must agree mod NUM_PARTITIONS.
        let mut hasher = xxhash_rust::xxh64::Xxh64::new(0x517c_c1b7_2722_0a95);
        key.hash(&mut hasher);
        let partition = (hasher.finish() as usize) % num_partitions;
        partition_indices[partition].push(row);
    }

    let mut result: Vec<Option<RecordBatch>> = Vec::with_capacity(num_partitions);
    for indices in partition_indices {
        if indices.is_empty() {
            result.push(None);
        } else {
            let indices_arr =
                UInt32Array::from(indices.iter().map(|&i| i as u32).collect::<Vec<_>>());
            let columns: Result<Vec<ArrayRef>> = batch
                .columns()
                .iter()
                .map(|col| compute::take(col.as_ref(), &indices_arr, None).map_err(Into::into))
                .collect();
            let part_batch = RecordBatch::try_new(batch.schema(), columns?)?;
            result.push(Some(part_batch));
        }
    }
    Ok(result)
}

/// Write batches to a Parquet file
fn write_batches_to_parquet(path: &PathBuf, batches: &[RecordBatch]) -> Result<()> {
    if batches.is_empty() {
        return Ok(());
    }

    let file = File::create(path).map_err(|e| {
        QueryError::Execution(format!("Failed to create parquet file {:?}: {}", path, e))
    })?;

    let props = WriterProperties::builder()
        .set_compression(Compression::SNAPPY)
        .build();

    let mut writer = ArrowWriter::try_new(file, batches[0].schema(), Some(props))?;

    for batch in batches {
        writer.write(batch)?;
    }

    writer.close()?;
    Ok(())
}

/// Append one batch to a spilled partition's Parquet file as a new row
/// group, via an ALREADY-OPEN streaming writer kept alive across many calls
/// (one per spilled partition, for the whole build or probe phase — see
/// `build_with_partitioning`/`probe_with_spilling`).
///
/// Replaces the previous `append_to_parquet`, which reopened the file on
/// EVERY call: read the schema back off disk, streamed the ENTIRE existing
/// file into a fresh temp file, wrote the one new batch, then renamed the
/// temp file over the original. With `NUM_PARTITIONS` = 64 partitions
/// spilling almost immediately and hundreds of build batches (plus the full
/// probe side) appended progressively, that made each append cost
/// O(current file size) — i.e. the whole build/probe phase cost O(n^2) in
/// bytes read+written for a partition that accumulates n batches.
/// Confirmed (spill-join-correctness epic, task 001) to be a strong,
/// evidenced candidate for why even a CORRECT run of a large spilling join
/// took 140+ seconds, on top of the still-open, unrelated wrong-answer bug
/// investigated by that same epic. `writer_slot` is created lazily on the
/// first call for a given partition (mirrors the old function's "no
/// existing file yet" branch — nothing is written, and no file appears on
/// disk, for a partition that never receives a batch) and reused for every
/// subsequent one, so the cost of any single append no longer grows with
/// how much has already been spilled for that partition. The on-disk
/// SHAPE is unchanged (still exactly one Parquet file per partition) —
/// `read_parquet`/`process_spilled_partition` need no changes.
///
/// **`oom-safety-hardening` epic (2026-08-29): the "kept open for the
/// whole build/probe phase" design above has a real, confirmed memory-
/// accounting hole this fixes.** `ArrowWriter::write()` does NOT flush a
/// batch to disk per call — it buffers into the CURRENT row group's
/// in-progress column encoders until `parquet`'s own row-group limit is
/// hit (this file previously relied on the crate's row-COUNT default,
/// 1,048,576, via an unset `WriterProperties`) or `.close()` runs. With
/// `NUM_PARTITIONS` = 64 spilled partitions and a real build side's rows
/// hash-partitioned roughly evenly across them, MOST spilled partitions
/// never individually accumulate 1M+ rows before the build/probe phase
/// ends — so their data sits fully memory-resident inside the writer's
/// own internal buffer for the ENTIRE phase, invisible to `total_memory`
/// (which already decremented as if that data were freed the moment
/// `evict_build_partition_to_disk` ran). Confirmed live, not just by
/// reading the code: `examples/_control_int32_repro.rs` (a PLAIN Int32
/// build side, no Dictionary column at all — ruling out any connection
/// to this epic's own Dictionary-sizing fix) with a 500MB configured
/// `memory_limit` was genuinely OOM-killed by the kernel at ~3.1GB RSS
/// under a real `systemd-run -p MemoryMax=3G` cap (`journalctl -k`:
/// "Memory cgroup out of memory: Killed process ... (_control_int32_)");
/// `examples/spill_dictionary_oversized_build_repro.rs` at a 30MB limit
/// survived under a 900M cap but peaked at 723MB RSS — 24x its own
/// configured budget.
///
/// **First attempt (byte-based `set_max_row_group_bytes`) measured, and
/// REJECTED — a second instance of the exact bug class this epic exists
/// to fix.** `parquet`'s own doc comment on that setter says row groups
/// "are flushed when their ESTIMATED ENCODED SIZE exceeds this
/// threshold" — encoded/compressed, not raw. Both repros above use
/// deliberately low-cardinality, highly repetitive keys (a 7-entry
/// dictionary; `i % 7` for the control's plain Int32), so their
/// COMPRESSED footprint stays tiny no matter how many raw rows are
/// buffered — the estimate this setting flushes against can be
/// arbitrarily smaller than the actual uncompressed memory being held,
/// the identical "estimate vs. real content" failure mode
/// `estimate_batch_size` was fixed for elsewhere in this file. Measured,
/// not assumed: re-ran both repros with only that fix — peak RSS was
/// UNCHANGED (723MB → 740MB for the dictionary case, within noise; the
/// control case was STILL genuinely OOM-killed at the same ~3G cap).
///
/// Fix that actually measures bounded: `set_max_row_group_row_count`
/// (in addition to, not instead of, the byte cap above as a secondary
/// net for genuinely wide rows) — a ROW-count limit bounds RAW buffered
/// rows directly, immune to how well those rows happen to compress.
/// `SPILL_WRITER_ROW_GROUP_ROWS` (8,192) matches this same file's own
/// `CHUNK_ROWS` precedent (`SpillableHashAggregateExec::
/// aggregate_with_spilling`) rather than inventing a new magic number.
///
/// **CORRECTION (`oom-safety-hardening` task 001, 2026-08-29): the
/// paragraph this one replaced claimed the row-count cap made the
/// control repro "complete cleanly" — that was WRONG** (contradicted by
/// `spill-size-estimate-fix` 001's own Outcome section, which is the
/// honest record: peak RSS unchanged, control still OOM-killed at a 3G
/// cap). This writer-flush fix is real and worth keeping, but it was
/// never the dominant driver. The actual dominant driver, root-caused
/// with the (fixed) `QE_ALLOC_PROFILE` diagnostic allocator: the
/// UNBUDGETED `HashMap<JoinKey, Vec<HashEntry>>` hash tables
/// `execute_spill_path` builds over the in-memory partitions (and each
/// read-back spilled partition) cost ~120-200 bytes/row across three
/// allocations per key — ~10-20x the raw batch bytes the spill decision
/// budgeted — and are never checked against `memory_limit`. See
/// `.claude/epics/oom-safety-hardening/updates/001/stream-A.md` for the
/// full evidence (profiler call-site snapshots, cap-sweep numbers).
fn append_batch_streaming(
    writer_slot: &mut Option<ArrowWriter<File>>,
    path: &PathBuf,
    batch: &RecordBatch,
) -> Result<()> {
    /// Secondary net for genuinely wide rows whose compressed size tracks
    /// their raw size reasonably closely. Matches `DEFAULT_PAGE_SIZE`
    /// (1MB), already used elsewhere in this codebase as a natural unit.
    const SPILL_WRITER_ROW_GROUP_BYTES: usize = 1024 * 1024;
    /// The binding limit for narrow/repetitive rows (see this function's
    /// own doc comment for why the byte-based cap alone measured as a
    /// no-op): bounds RAW buffered rows directly, regardless of how well
    /// they compress. Matches this file's own `CHUNK_ROWS` precedent.
    const SPILL_WRITER_ROW_GROUP_ROWS: usize = 8_192;

    if writer_slot.is_none() {
        let file = File::create(path).map_err(|e| {
            QueryError::Execution(format!("Failed to create spill file {:?}: {}", path, e))
        })?;
        let props = WriterProperties::builder()
            .set_compression(Compression::SNAPPY)
            .set_max_row_group_bytes(Some(SPILL_WRITER_ROW_GROUP_BYTES))
            .set_max_row_group_row_count(Some(SPILL_WRITER_ROW_GROUP_ROWS))
            .build();
        *writer_slot = Some(ArrowWriter::try_new(file, batch.schema(), Some(props))?);
    }
    writer_slot
        .as_mut()
        .expect("just created above if it was None")
        .write(batch)?;
    Ok(())
}

/// Close every open spill writer exactly once, flushing the final row group
/// and Parquet footer so the file is valid and readable. Must run after a
/// build/probe phase's loop finishes — every `SpilledPartition` file has to
/// be complete before `process_spilled_partition` opens it.
fn close_spill_writers(writers: Vec<Option<ArrowWriter<File>>>) -> Result<()> {
    for writer in writers.into_iter().flatten() {
        writer.close()?;
    }
    Ok(())
}

/// Read batches from a Parquet file
fn read_parquet(path: &PathBuf) -> Result<Vec<RecordBatch>> {
    let file = File::open(path).map_err(|e| {
        QueryError::Execution(format!("Failed to open parquet file {:?}: {}", path, e))
    })?;

    let builder = ParquetRecordBatchReaderBuilder::try_new(file)?;
    let reader = builder.build()?;

    let batches: Vec<RecordBatch> = reader.collect::<std::result::Result<Vec<_>, _>>()?;
    Ok(batches)
}

/// Sort a record batch
fn sort_batch(batch: &RecordBatch, order_by: &[crate::planner::SortExpr]) -> Result<RecordBatch> {
    use crate::planner::SortDirection;
    use arrow::compute::{lexsort_to_indices, SortColumn, SortOptions};

    if batch.num_rows() == 0 {
        return Ok(batch.clone());
    }

    let sort_columns: Result<Vec<SortColumn>> = order_by
        .iter()
        .map(|s| {
            let values = evaluate_expr(batch, &s.expr)?;
            Ok(SortColumn {
                values,
                options: Some(SortOptions {
                    descending: s.direction == SortDirection::Desc,
                    nulls_first: matches!(s.nulls, crate::planner::NullOrdering::NullsFirst),
                }),
            })
        })
        .collect();
    let sort_columns = sort_columns?;

    let indices = lexsort_to_indices(&sort_columns, None)?;

    let sorted_columns: Result<Vec<ArrayRef>> = batch
        .columns()
        .iter()
        .map(|col| compute::take(col.as_ref(), &indices, None).map_err(Into::into))
        .collect();

    RecordBatch::try_new(batch.schema(), sorted_columns?).map_err(Into::into)
}

// ============================================================================
// Join Key and Hash Table (reused from hash_join.rs)
// ============================================================================

#[derive(Clone)]
struct JoinKey {
    values: Vec<JoinValue>,
}

#[derive(Clone)]
enum JoinValue {
    Null,
    Int64(i64),
    Float64(ordered_float::OrderedFloat<f64>),
    String(String),
}

impl PartialEq for JoinKey {
    fn eq(&self, other: &Self) -> bool {
        if self.values.len() != other.values.len() {
            return false;
        }
        self.values
            .iter()
            .zip(other.values.iter())
            .all(|(a, b)| match (a, b) {
                (JoinValue::Null, JoinValue::Null) => true,
                (JoinValue::Int64(a), JoinValue::Int64(b)) => a == b,
                (JoinValue::Float64(a), JoinValue::Float64(b)) => a == b,
                (JoinValue::String(a), JoinValue::String(b)) => a == b,
                _ => false,
            })
    }
}

impl Eq for JoinKey {}

impl Hash for JoinKey {
    fn hash<H: Hasher>(&self, state: &mut H) {
        for v in &self.values {
            match v {
                JoinValue::Null => 0u8.hash(state),
                JoinValue::Int64(i) => {
                    1u8.hash(state);
                    i.hash(state);
                }
                JoinValue::Float64(f) => {
                    2u8.hash(state);
                    f.hash(state);
                }
                JoinValue::String(s) => {
                    3u8.hash(state);
                    s.hash(state);
                }
            }
        }
    }
}

#[derive(Clone)]
struct HashEntry {
    batch_idx: usize,
    row_idx: usize,
}

fn extract_join_key(arrays: &[ArrayRef], row: usize) -> JoinKey {
    let values: Vec<JoinValue> = arrays
        .iter()
        .map(|arr| {
            if arr.is_null(row) {
                return JoinValue::Null;
            }

            if let Some(a) = arr.as_any().downcast_ref::<Int64Array>() {
                return JoinValue::Int64(a.value(row));
            }
            if let Some(a) = arr.as_any().downcast_ref::<arrow::array::Int32Array>() {
                return JoinValue::Int64(a.value(row) as i64);
            }
            if let Some(a) = arr.as_any().downcast_ref::<UInt64Array>() {
                return JoinValue::Int64(a.value(row) as i64);
            }
            if let Some(a) = arr.as_any().downcast_ref::<arrow::array::Float64Array>() {
                return JoinValue::Float64(ordered_float::OrderedFloat(a.value(row)));
            }
            if let Some(a) = arr.as_any().downcast_ref::<arrow::array::StringArray>() {
                return JoinValue::String(a.value(row).to_string());
            }

            JoinValue::Null
        })
        .collect();

    JoinKey { values }
}

/// Diagnostic-only (`QE_SPILL_DEBUG`) checksum of a batch of join-key
/// values, spill-join-correctness-2 epic task 001. Order-independent (XOR
/// accumulation) so it survives any row reordering across a spill/unspill
/// round trip. Deliberately built on the SAME `extract_join_key` function
/// used by `build_hash_table`/`partition_batch_by_hash` themselves — a
/// mismatch caught by comparing two `KeyChecksum`s can only come from the
/// underlying ARRAY DATA differing between the two calls (e.g. a Parquet
/// round trip changing a column's concrete Arrow type or values), never
/// from the checksum's own logic disagreeing with the real join mechanism.
#[derive(Clone, Copy, Default)]
struct KeyChecksum {
    rows: usize,
    xor_hash: u64,
    /// Rows whose key extraction fell through to `JoinValue::Null` despite
    /// the underlying array being NON-null at that row — i.e. an unhandled
    /// `extract_join_key` array type (see its downcast chain), not a
    /// genuine SQL NULL. Tracked separately so a real mismatch reads as
    /// "spill round-trip changed the data", not conflated with this
    /// already-known, structurally different key-extraction gap.
    unhandled_type_rows: usize,
}

impl KeyChecksum {
    fn accumulate(&mut self, other: KeyChecksum) {
        self.rows += other.rows;
        self.xor_hash ^= other.xor_hash;
        self.unhandled_type_rows += other.unhandled_type_rows;
    }
}

/// Compute a [`KeyChecksum`] for one batch's join keys (`key_exprs`
/// evaluated against `batch`, then `extract_join_key` per row — the exact
/// path `build_hash_table` and `partition_batch_by_hash` use).
fn batch_key_checksum(batch: &RecordBatch, key_exprs: &[Expr]) -> Result<KeyChecksum> {
    let key_arrays = join_key_arrays(batch, key_exprs)?;
    let mut cs = KeyChecksum::default();
    for row in 0..batch.num_rows() {
        let key = extract_join_key(&key_arrays, row);
        let source_is_null = key_arrays.iter().any(|a| a.is_null(row));
        let key_is_all_null = key.values.iter().all(|v| matches!(v, JoinValue::Null));
        if key_is_all_null && !source_is_null {
            cs.unhandled_type_rows += 1;
        }
        // A dedicated, fixed seed — distinct from `partition_batch_by_hash`'s
        // own routing-hash seed, since this checksum only ever needs to
        // agree with ITSELF (write time vs. read time), never with the
        // routing function.
        let mut hasher = xxhash_rust::xxh64::Xxh64::new(0x9e37_79b9_7f4a_7c15);
        key.hash(&mut hasher);
        cs.xor_hash ^= hasher.finish();
        cs.rows += 1;
    }
    Ok(cs)
}

/// Approximate per-heap-allocation bookkeeping overhead (allocator bin
/// rounding + header amortization under mimalloc). Every 1-element
/// `Vec<JoinValue>` / `Vec<HashEntry>` a join hash table holds is its own
/// heap allocation, so at millions of keys this overhead is a first-order
/// term, not noise — oom-safety-hardening task 001's profiler evidence
/// measured ~300MB of exactly these untracked small allocations at the
/// dict repro's 640MB peak.
const HEAP_ALLOC_OVERHEAD_BYTES: usize = 16;

/// Amortized hashbrown bucket cost per OCCUPIED entry for
/// `HashMap<JoinKey, Vec<HashEntry>>`: `size_of::<(JoinKey,
/// Vec<HashEntry>)>() = 48` plus 1 control byte, times hashbrown's 8/7
/// inverse load factor ≈ 56 bytes. Used by the PREDICTED (pre-build)
/// estimate; the post-build measurement uses the table's real `capacity()`
/// instead.
const HASH_TABLE_BUCKET_BYTES_AMORTIZED: usize =
    (std::mem::size_of::<(JoinKey, Vec<HashEntry>)>() + 1) * 8 / 7;

/// Conservative PREDICTED heap footprint of the `HashMap<JoinKey,
/// Vec<HashEntry>>` that `build_hash_table` would produce over `rows` rows
/// with `key_cols` join-key columns — the worst (all-unique-keys) case,
/// which is exactly the shape both oom-safety-hardening repros (and any
/// PK-keyed build side) hit. Per row:
///   ~56B amortized hashbrown bucket
/// + key-values `Vec<JoinValue>` heap buffer (`key_cols` × 32B + overhead)
/// + entries `Vec<HashEntry>` heap buffer (16B + overhead)
/// ≈ 136B/row for a single-column key — vs the ~12B/row of raw batch data
/// `estimate_batch_size` accounts, i.e. the measured 10-20x amplification
/// task 001 root-caused. Duplicate-heavy key sets cost LESS than this
/// (shared buckets/entry vecs), so the prediction only ever errs toward
/// spilling more readily — the safe direction. String keys' character
/// bytes are NOT predicted here (unknowable pre-build); the post-build
/// `hash_table_memory_bytes` measurement catches them, at the cost of one
/// partition table's transient overshoot.
fn predicted_hash_table_bytes(rows: usize, key_cols: usize) -> usize {
    let per_row = HASH_TABLE_BUCKET_BYTES_AMORTIZED
        + (std::mem::size_of::<JoinValue>() * key_cols.max(1) + HEAP_ALLOC_OVERHEAD_BYTES)
        + (std::mem::size_of::<HashEntry>() + HEAP_ALLOC_OVERHEAD_BYTES);
    rows.saturating_mul(per_row)
}

// Keep admission estimates coupled to the actual aggregate layouts.
const AGG_ACCUMULATOR_STATE_BYTES: usize = super::hash_agg::ACCUMULATOR_STATE_BYTES;
const AGG_GROUP_VALUE_BYTES: usize = super::hash_agg::GROUP_VALUE_BYTES;
const AGG_DISTINCT_ENTRY_BYTES: usize = (AGG_GROUP_VALUE_BYTES + 1) * 2;

/// Conservative PREDICTED heap footprint of the `HashMap<GroupKey,
/// Vec<AccumulatorState>>` (plus DISTINCT value sets) that
/// `aggregate_batches_external` would build over `rows` rows — the
/// aggregate analogue of `predicted_hash_table_bytes`, priced the same
/// worst-case way (task 007's discipline): every row is its own group.
/// Duplicate-heavy group keys cost LESS than this (shared buckets/states),
/// so the prediction only ever errs toward the chunked read-back
/// (`aggregate_partition_chunked`) — the safe direction, whose cost is
/// bounded extra I/O over one already-spilling partition, never a wrong
/// answer or an unbudgeted allocation. DISTINCT aggregates additionally
/// pay a real (not worst-case) per-row set entry — every row inserts into
/// its group's `distinct_set` regardless of group cardinality — so
/// `n_distinct` charges per row unconditionally. String contents
/// (group-key bytes, distinct String values) are NOT predicted here
/// (unknowable pre-build), mirroring `predicted_hash_table_bytes`'s own
/// documented String gap.
fn predicted_agg_state_bytes(
    rows: usize,
    group_cols: usize,
    n_aggs: usize,
    n_distinct: usize,
) -> usize {
    // (GroupKey, Vec<AccumulatorState>) is the same 48-byte
    // (24B Vec-holding struct + 24B Vec header) map-entry shape as the
    // join's (JoinKey, Vec<HashEntry>), so the amortized bucket constant
    // is shared deliberately.
    let per_group = HASH_TABLE_BUCKET_BYTES_AMORTIZED
        + (AGG_GROUP_VALUE_BYTES * group_cols.max(1) + HEAP_ALLOC_OVERHEAD_BYTES)
        + (AGG_ACCUMULATOR_STATE_BYTES * n_aggs.max(1) + HEAP_ALLOC_OVERHEAD_BYTES);
    let per_row = per_group + n_distinct * AGG_DISTINCT_ENTRY_BYTES;
    rows.saturating_mul(per_row)
}

/// DIRECT measurement of a built join hash table's heap footprint: the
/// hashbrown bucket array at its REAL `capacity()`, plus every key's
/// `Vec<JoinValue>` buffer (and any `String` key's character buffer), plus
/// every entry list's `Vec<HashEntry>` buffer, each with
/// `HEAP_ALLOC_OVERHEAD_BYTES` of allocator overhead. O(keys) walk —
/// negligible next to the O(rows) build that produced the table. This is
/// the number the spill path's memory accounting charges against the
/// budget (oom-safety-hardening task 007); `estimate_batch_size` only ever
/// covered the batches underneath.
fn hash_table_memory_bytes(table: &HashMap<JoinKey, Vec<HashEntry>>) -> usize {
    let bucket_bytes = std::mem::size_of::<(JoinKey, Vec<HashEntry>)>() + 1;
    let mut total = table.capacity().saturating_mul(bucket_bytes);
    for (key, entries) in table.iter() {
        if key.values.capacity() > 0 {
            total += key.values.capacity() * std::mem::size_of::<JoinValue>()
                + HEAP_ALLOC_OVERHEAD_BYTES;
        }
        for v in &key.values {
            if let JoinValue::String(s) = v {
                if s.capacity() > 0 {
                    total += s.capacity() + HEAP_ALLOC_OVERHEAD_BYTES;
                }
            }
        }
        if entries.capacity() > 0 {
            total +=
                entries.capacity() * std::mem::size_of::<HashEntry>() + HEAP_ALLOC_OVERHEAD_BYTES;
        }
    }
    total
}

fn build_hash_table(
    batches: &[RecordBatch],
    key_exprs: &[Expr],
) -> Result<HashMap<JoinKey, Vec<HashEntry>>> {
    let mut table: HashMap<JoinKey, Vec<HashEntry>> = HashMap::new();

    for (batch_idx, batch) in batches.iter().enumerate() {
        let key_arrays = join_key_arrays(batch, key_exprs)?;

        for row_idx in 0..batch.num_rows() {
            let key = extract_join_key(&key_arrays, row_idx);

            if key.values.iter().any(|v| matches!(v, JoinValue::Null)) {
                continue;
            }

            table
                .entry(key)
                .or_default()
                .push(HashEntry { batch_idx, row_idx });
        }
    }

    Ok(table)
}

/// spill-boundaries task 002: the ON-clause predicate of a spilling join,
/// applied to the candidate (build row, probe row) pairs the hash lookup
/// produces — INNER keeps the passing pairs, SEMI/ANTI count a probe/build
/// row as matched only through a passing pair. Evaluated where the pair is
/// formed (`visit_candidate_pairs`), never as a post-filter: a post-filter
/// cannot see which probe row an SEMI/ANTI decision belonged to, and for
/// the outer joins task 003 adds it would delete the NULL-extended rows.
///
/// Two evaluation paths, decided per batch:
/// - `compiled`: hash_join's `CompiledFilter` (one build column compared
///   with one probe column, Int64/Int32/Float64/Utf8) evaluated straight
///   from the arrays per pair — no gather at all. Guarded here by the
///   ACTUAL array types (a Dictionary-encoded column, or a Date, would
///   make `CompiledFilter::evaluate` return `false` for every pair) and by
///   NULL slots (SQL: a comparison with NULL is not TRUE).
/// - otherwise: the candidate pairs are gathered into a combined-schema
///   batch (build ++ probe, or probe ++ build when swapped — the same
///   left ++ right order the planner's `filter_inside_join` expression was
///   bound against) in chunks of `PAIR_FILTER_CHUNK_PAIRS`, the expression
///   is evaluated ONCE per chunk with `evaluate_expr`, and a pair passes
///   iff its mask slot is valid AND true.
struct PairFilter {
    expr: Expr,
    compiled: Option<super::hash_join::CompiledFilter>,
}

/// Candidate pairs gathered per filter evaluation on the generic path —
/// bounds the transient combined batch whatever the probe batch's fan-out.
const PAIR_FILTER_CHUNK_PAIRS: usize = 65_536;

impl PairFilter {
    fn new(expr: Expr, build_schema: &Schema, probe_schema: &Schema, swapped: bool) -> Self {
        let compiled = super::hash_join::CompiledFilter::try_compile(
            &expr,
            build_schema,
            probe_schema,
            swapped,
        );
        Self { expr, compiled }
    }

    /// The compiled fast path, if it applies to THESE batches' actual
    /// column types.
    fn compiled_for(
        &self,
        build_batches: &[RecordBatch],
        probe_batch: &RecordBatch,
    ) -> Option<&super::hash_join::CompiledFilter> {
        use arrow::datatypes::DataType;
        let cf = self.compiled.as_ref()?;
        let (b, p) = cf.column_indices();
        let ok = |dt: &DataType| {
            matches!(
                dt,
                DataType::Int64 | DataType::Int32 | DataType::Float64 | DataType::Utf8
            )
        };
        let first = build_batches.first()?;
        if b >= first.num_columns() || p >= probe_batch.num_columns() {
            return None;
        }
        (ok(first.column(b).data_type()) && ok(probe_batch.column(p).data_type())).then_some(cf)
    }

    /// Mask over `pairs` (parallel `build_indices`/`probe_indices`) on the
    /// generic path: gather, evaluate once, `valid && value`.
    fn evaluate_pairs(
        &self,
        build_batches: &[RecordBatch],
        probe_batch: &RecordBatch,
        build_indices: &[(usize, usize)],
        probe_indices: &[usize],
        swapped: bool,
    ) -> Result<Vec<bool>> {
        let combined_schema: SchemaRef = {
            let build_fields: Vec<_> = build_batches
                .first()
                .map(|b| b.schema().fields().iter().cloned().collect())
                .unwrap_or_default();
            let probe_fields: Vec<_> = probe_batch.schema().fields().iter().cloned().collect();
            let fields: Vec<_> = if swapped {
                probe_fields.into_iter().chain(build_fields).collect()
            } else {
                build_fields.into_iter().chain(probe_fields).collect()
            };
            Arc::new(Schema::new(fields))
        };
        let combined = super::hash_join::create_combined_batch(
            build_batches,
            build_indices,
            probe_batch,
            probe_indices,
            swapped,
            &combined_schema,
        )?;
        let result = evaluate_expr(&combined, &self.expr)?;
        use arrow::array::Array;
        let mask = result
            .as_any()
            .downcast_ref::<arrow::array::BooleanArray>()
            .ok_or_else(|| {
                QueryError::Execution(format!(
                    "join spill path: ON-clause filter evaluated to {:?}, not Boolean",
                    result.data_type()
                ))
            })?;
        Ok((0..mask.len())
            .map(|i| mask.is_valid(i) && mask.value(i))
            .collect())
    }
}

/// THE candidate-pair enumeration of the join spill path (spill-boundaries
/// task 002): every (build row, probe row) pair of ONE probe batch against
/// ONE hash table that shares a non-NULL key AND passes the ON filter (all
/// key matches when there is none). `visit(build_batch_idx, build_row,
/// probe_row)` is called per passing pair; `first_only` stops each probe
/// row at its first passing pair (existence is all SEMI/ANTI need on the
/// probe side); `skip(probe_row)` rows are not probed at all (a probe row
/// already known to match in an earlier chunk). INNER pair emission, both
/// SEMI/ANTI orientations and the outer joins all go through here, so the
/// filter can never be applied in one place and forgotten in another.
#[allow(clippy::too_many_arguments)]
fn visit_candidate_pairs(
    build_batches: &[RecordBatch],
    probe_batch: &RecordBatch,
    hash_table: &HashMap<JoinKey, Vec<HashEntry>>,
    probe_key_exprs: &[Expr],
    filter: Option<&PairFilter>,
    swapped: bool,
    first_only: bool,
    skip: &dyn Fn(usize) -> bool,
    visit: &mut dyn FnMut(usize, usize, usize),
) -> Result<()> {
    let key_arrays = join_key_arrays(probe_batch, probe_key_exprs)?;
    let n = probe_batch.num_rows();
    let entries_of = |probe_row: usize| -> Option<&Vec<HashEntry>> {
        let key = extract_join_key(&key_arrays, probe_row);
        if key.values.iter().any(|v| matches!(v, JoinValue::Null)) {
            return None;
        }
        hash_table.get(&key)
    };
    let Some(filter) = filter else {
        for probe_row in 0..n {
            if skip(probe_row) {
                continue;
            }
            if let Some(entries) = entries_of(probe_row) {
                if first_only {
                    if let Some(e) = entries.first() {
                        visit(e.batch_idx, e.row_idx, probe_row);
                    }
                } else {
                    for e in entries {
                        visit(e.batch_idx, e.row_idx, probe_row);
                    }
                }
            }
        }
        return Ok(());
    };
    if let Some(cf) = filter.compiled_for(build_batches, probe_batch) {
        let (bcol, pcol) = cf.column_indices();
        let probe_col = probe_batch.column(pcol);
        for probe_row in 0..n {
            if skip(probe_row) || probe_col.is_null(probe_row) {
                continue;
            }
            let Some(entries) = entries_of(probe_row) else {
                continue;
            };
            for e in entries {
                let bb = &build_batches[e.batch_idx];
                if bb.column(bcol).is_null(e.row_idx) {
                    continue;
                }
                if cf.evaluate(bb, e.row_idx, probe_batch, probe_row) {
                    visit(e.batch_idx, e.row_idx, probe_row);
                    if first_only {
                        break;
                    }
                }
            }
        }
        return Ok(());
    }
    // Generic path: gather the candidate pairs in bounded chunks (a probe
    // row's pairs never straddle a chunk, so `first_only` de-duplication
    // is local to the chunk) and evaluate the expression once per chunk.
    let mut bi: Vec<(usize, usize)> = Vec::new();
    let mut pi: Vec<usize> = Vec::new();
    let flush = |bi: &mut Vec<(usize, usize)>,
                 pi: &mut Vec<usize>,
                 visit: &mut dyn FnMut(usize, usize, usize)|
     -> Result<()> {
        if bi.is_empty() {
            return Ok(());
        }
        let mask = filter.evaluate_pairs(build_batches, probe_batch, bi, pi, swapped)?;
        let mut decided_row = usize::MAX;
        for i in 0..bi.len() {
            if !mask[i] {
                continue;
            }
            if first_only {
                if pi[i] == decided_row {
                    continue;
                }
                decided_row = pi[i];
            }
            visit(bi[i].0, bi[i].1, pi[i]);
        }
        bi.clear();
        pi.clear();
        Ok(())
    };
    for probe_row in 0..n {
        if skip(probe_row) {
            continue;
        }
        if let Some(entries) = entries_of(probe_row) {
            for e in entries {
                bi.push((e.batch_idx, e.row_idx));
                pi.push(probe_row);
            }
        }
        if bi.len() >= PAIR_FILTER_CHUNK_PAIRS {
            flush(&mut bi, &mut pi, visit)?;
        }
    }
    flush(&mut bi, &mut pi, visit)
}

/// THE per-batch probe of the spill path: ONE probe batch against ONE
/// hash table, doing everything the join needs in a single pass over the
/// candidate pairs (`visit_candidate_pairs`, so key equality and the ON
/// filter are applied exactly once, in one place):
/// - the passing pairs become the returned joined batch when the join
///   emits pairs (INNER and the outer joins);
/// - `build_matched` (the table's build batches' bitmap — a resident
///   partition's across the whole probe stream, a read-back chunk's) is
///   marked for build-side SEMI/ANTI and a preserved build side;
/// - `probe_matched` (this probe batch's bitmap — carried across chunks by
///   the caller for a spilled partition) is marked for probe-side
///   SEMI/ANTI and a preserved probe side.
/// When only the probe bitmap is wanted, a probe row already flagged is
/// skipped and the walk stops at its first passing pair (existence is all
/// that is needed). NULL keys never match on either side.
fn probe_batch_against_table(
    build_batches: &[RecordBatch],
    probe_batch: &RecordBatch,
    hash_table: &HashMap<JoinKey, Vec<HashEntry>>,
    ctx: &SpillJoinCtx,
    build_matched: Option<&[Vec<std::sync::atomic::AtomicBool>]>,
    probe_matched: Option<&mut [bool]>,
) -> Result<Vec<RecordBatch>> {
    use std::sync::atomic::Ordering::Relaxed;
    let emit_pairs = ctx.emit_pairs();
    let existence_only = !emit_pairs && build_matched.is_none();
    let already: Option<Vec<bool>> = match (&probe_matched, existence_only) {
        (Some(f), true) => Some(f.to_vec()),
        _ => None,
    };
    let skip = |row: usize| already.as_ref().is_some_and(|a| a[row]);
    let mut build_indices: Vec<(usize, usize)> = Vec::new();
    let mut probe_indices: Vec<usize> = Vec::new();
    let mut probe_hits: Vec<usize> = Vec::new();
    let want_probe_hits = probe_matched.is_some();
    visit_candidate_pairs(
        build_batches,
        probe_batch,
        hash_table,
        &ctx.probe_keys,
        ctx.filter.as_deref(),
        ctx.swapped,
        existence_only,
        &skip,
        &mut |b, r, p| {
            if emit_pairs {
                build_indices.push((b, r));
                probe_indices.push(p);
            }
            if let Some(bm) = build_matched {
                bm[b][r].store(true, Relaxed);
            }
            if want_probe_hits {
                probe_hits.push(p);
            }
        },
    )?;
    if let Some(flags) = probe_matched {
        for p in probe_hits {
            flags[p] = true;
        }
    }
    if !emit_pairs || build_indices.is_empty() {
        return Ok(Vec::new());
    }
    // Pairs are emitted in bounded slices (duplicate keys can fan one probe
    // batch out to far more pairs than rows).
    let slice = spill_emit_rows();
    build_indices
        .chunks(slice)
        .zip(probe_indices.chunks(slice))
        .map(|(bi, pi)| {
            create_joined_batch(
                build_batches,
                probe_batch,
                bi,
                pi,
                ctx.swapped,
                &ctx.schema,
                ctx.retained.as_deref(),
            )
        })
        .collect()
}

/// NULL arrays for the NON-preserved side of an outer-join emission, typed
/// from the declared full output schema: `first` selects the leading
/// (`swapped` = probe = left) or trailing block of `full_schema`.
fn null_side_columns(
    full_schema: &SchemaRef,
    first: bool,
    width: usize,
    rows: usize,
) -> Vec<ArrayRef> {
    let total = full_schema.fields().len();
    let offset = if first { 0 } else { total - width };
    (0..width)
        .map(|i| arrow::array::new_null_array(full_schema.field(offset + i).data_type(), rows))
        .collect()
}

/// Apply the join-output retention mask (see `create_joined_batch`).
fn apply_retained(columns: Vec<ArrayRef>, retained: Option<&[bool]>) -> Vec<ArrayRef> {
    match retained {
        Some(mask) if mask.len() == columns.len() => columns
            .into_iter()
            .zip(mask)
            .filter(|(_, keep)| **keep)
            .map(|(c, _)| c)
            .collect(),
        _ => columns,
    }
}

/// Emit a probe batch's rows once its match bitmap is final, per
/// `SpillJoinCtx::probe_emit`: SEMI's matched rows / ANTI's unmatched rows
/// bare (`take_probe_rows`), or a preserved probe side's unmatched rows
/// NULL-extended on the build side (spill-boundaries task 003).
fn emit_probe_rows(
    ctx: &SpillJoinCtx,
    probe_batch: &RecordBatch,
    flags: &[bool],
) -> Result<Vec<RecordBatch>> {
    match ctx.probe_emit() {
        RowEmit::None => Ok(Vec::new()),
        RowEmit::Matched => take_probe_rows(probe_batch, flags, true, &ctx.schema),
        RowEmit::Unmatched => take_probe_rows(probe_batch, flags, false, &ctx.schema),
        RowEmit::UnmatchedNullExtended => {
            let keep: Vec<u32> = flags
                .iter()
                .enumerate()
                .filter(|(_, &f)| !f)
                .map(|(i, _)| i as u32)
                .collect();
            keep.chunks(spill_emit_rows())
                .map(|slice| {
                    let rows = slice.len();
                    let idx = UInt32Array::from(slice.to_vec());
                    let probe_columns: Vec<ArrayRef> = probe_batch
                        .columns()
                        .iter()
                        .map(|c| compute::take(c.as_ref(), &idx, None).map_err(Into::into))
                        .collect::<Result<_>>()?;
                    let build_width = ctx.full_schema.fields().len() - probe_columns.len();
                    // Probe = left when swapped: probe columns first, build
                    // NULLs (the trailing block) after; else build NULLs
                    // (leading block) first.
                    let build_nulls =
                        null_side_columns(&ctx.full_schema, !ctx.swapped, build_width, rows);
                    let columns: Vec<ArrayRef> = if ctx.swapped {
                        probe_columns.into_iter().chain(build_nulls).collect()
                    } else {
                        build_nulls.into_iter().chain(probe_columns).collect()
                    };
                    let columns = apply_retained(columns, ctx.retained.as_deref());
                    batch_with_actual_types(&ctx.schema, columns)
                })
                .collect()
        }
    }
}

/// Emit a build partition's / chunk's rows once its match bitmap is final,
/// per `SpillJoinCtx::build_emit`: SEMI's matched rows / ANTI's unmatched
/// rows bare (`take_build_rows`), or a preserved build side's unmatched
/// rows NULL-extended on the probe side (spill-boundaries task 003).
fn emit_build_rows(
    ctx: &SpillJoinCtx,
    build_batches: &[RecordBatch],
    flags: &[Vec<bool>],
) -> Result<Vec<RecordBatch>> {
    match ctx.build_emit() {
        RowEmit::None => Ok(Vec::new()),
        RowEmit::Matched => take_build_rows(build_batches, flags, true, &ctx.schema),
        RowEmit::Unmatched => take_build_rows(build_batches, flags, false, &ctx.schema),
        RowEmit::UnmatchedNullExtended => {
            let indices = flagged_build_indices(flags, false);
            if indices.is_empty() || build_batches.is_empty() {
                return Ok(Vec::new());
            }
            indices
                .chunks(spill_emit_rows())
                .map(|slice| {
                    let rows = slice.len();
                    let build_columns: Vec<ArrayRef> = (0..build_batches[0].num_columns())
                        .map(|c| gather_column(build_batches, c, slice))
                        .collect::<Result<_>>()?;
                    let probe_width = ctx.full_schema.fields().len() - build_columns.len();
                    // Build = right when swapped: probe NULLs (the leading
                    // block) first; else build first, probe NULLs
                    // (trailing) after.
                    let probe_nulls =
                        null_side_columns(&ctx.full_schema, ctx.swapped, probe_width, rows);
                    let columns: Vec<ArrayRef> = if ctx.swapped {
                        probe_nulls.into_iter().chain(build_columns).collect()
                    } else {
                        build_columns.into_iter().chain(probe_nulls).collect()
                    };
                    let columns = apply_retained(columns, ctx.retained.as_deref());
                    batch_with_actual_types(&ctx.schema, columns)
                })
                .collect()
        }
    }
}

/// spill-join-correctness-3 task 004: join-key arrays for one batch — THE
/// single key-evaluation point of the join spill path (`build_hash_table`,
/// `partition_batch_by_hash`, `probe_partition`, `batch_key_checksum` and
/// every SEMI/ANTI probe below all go through it), so build, probe,
/// routing and the write/read checksum can never disagree about a key's
/// representation.
///
/// A `Dictionary`-encoded key column (what native tables give every
/// low-cardinality string column) is decoded to its value type first, the
/// same way `partition_batch_by_group_hash` already does for the
/// aggregate: `extract_join_key`'s downcast chain has no Dictionary arm and
/// fell through to `JoinValue::Null`, so before this every Dictionary-keyed
/// row was routed to the NULL partition, never inserted into a table
/// (`build_hash_table` skips NULL keys) and never matched — a spilling
/// INNER/SEMI join on such a key returned ZERO rows (pinned by
/// `semi_anti_spill_dictionary_keys_are_cell_exact`, which also covers
/// INNER). Non-Dictionary keys are evaluated exactly as before, so
/// partition routing for them is byte-identical to the routing task 001
/// recalibrated (0 wrong / 6,041 trials).
fn join_key_arrays(batch: &RecordBatch, key_exprs: &[Expr]) -> Result<Vec<ArrayRef>> {
    key_exprs
        .iter()
        .map(|e| {
            let arr = evaluate_expr(batch, e)?;
            match arr.data_type() {
                arrow::datatypes::DataType::Dictionary(_, value_type) => {
                    compute::cast(arr.as_ref(), value_type).map_err(Into::into)
                }
                _ => Ok(arr),
            }
        })
        .collect()
}

/// Rows per emitted batch for the GATHERED emissions of the spill path
/// (spill-boundaries 003 follow-up): a preserved build side's unmatched rows
/// of one read-back chunk (hundreds of thousands), a resident partition's
/// SEMI/ANTI/outer emission (millions), or one probe batch's pairs under
/// duplicate keys are emitted in slices of this many rows instead of one
/// batch each. The output channel bounds batch COUNT
/// (`SPILL_JOIN_OUTPUT_CHANNEL_CAPACITY`), so this is what bounds its
/// BYTES. `QE_SPILL_EMIT_ROWS` overrides (diagnostic; 0 = unbounded).
const SPILL_EMIT_ROWS: usize = 8_192;

fn spill_emit_rows() -> usize {
    match std::env::var("QE_SPILL_EMIT_ROWS")
        .ok()
        .and_then(|v| v.trim().parse::<usize>().ok())
    {
        Some(0) => usize::MAX,
        Some(n) => n,
        None => SPILL_EMIT_ROWS,
    }
}

/// Emit the probe rows whose flag equals `want` (SEMI: matched; ANTI:
/// unmatched) with probe-side columns only, against the declared SEMI/ANTI
/// output schema (the LEFT schema — the probe side IS the left side in this
/// orientation). `batch_with_actual_types` absorbs the same declared-vs-
/// actual encoding drift (Dictionary vs Utf8 after a Parquet round trip)
/// the INNER emitter already handles.
fn take_probe_rows(
    probe_batch: &RecordBatch,
    flags: &[bool],
    want: bool,
    output_schema: &SchemaRef,
) -> Result<Vec<RecordBatch>> {
    let keep: Vec<u32> = flags
        .iter()
        .enumerate()
        .filter(|(_, &f)| f == want)
        .map(|(i, _)| i as u32)
        .collect();
    keep.chunks(spill_emit_rows())
        .map(|slice| {
            let idx = UInt32Array::from(slice.to_vec());
            let columns: Result<Vec<ArrayRef>> = probe_batch
                .columns()
                .iter()
                .map(|c| compute::take(c.as_ref(), &idx, None).map_err(Into::into))
                .collect();
            batch_with_actual_types(output_schema, columns?)
        })
        .collect()
}

/// Emit the build rows whose flag equals `want` (SEMI: matched; ANTI:
/// unmatched) with build-side columns only — the build side IS the left
/// (output) side in this orientation. Same gather as the in-memory join's
/// `create_semi_anti_batch`.
fn take_build_rows(
    build_batches: &[RecordBatch],
    flags: &[Vec<bool>],
    want: bool,
    output_schema: &SchemaRef,
) -> Result<Vec<RecordBatch>> {
    let indices = flagged_build_indices(flags, want);
    if indices.is_empty() || build_batches.is_empty() {
        return Ok(Vec::new());
    }
    indices
        .chunks(spill_emit_rows())
        .map(|slice| {
            let columns: Result<Vec<ArrayRef>> = (0..build_batches[0].num_columns())
                .map(|c| gather_column(build_batches, c, slice))
                .collect();
            batch_with_actual_types(output_schema, columns?)
        })
        .collect()
}

/// (batch_idx, row_idx) of every build row whose flag equals `want`.
fn flagged_build_indices(flags: &[Vec<bool>], want: bool) -> Vec<(usize, usize)> {
    flags
        .iter()
        .enumerate()
        .flat_map(|(b, v)| {
            v.iter()
                .enumerate()
                .filter(move |(_, &f)| f == want)
                .map(move |(r, _)| (b, r))
        })
        .collect()
}

#[allow(clippy::too_many_arguments)]
fn create_joined_batch(
    build_batches: &[RecordBatch],
    probe_batch: &RecordBatch,
    build_indices: &[(usize, usize)],
    probe_indices: &[usize],
    swapped: bool,
    output_schema: &SchemaRef,
    retained: Option<&[bool]>,
) -> Result<RecordBatch> {
    // Gather build columns
    let build_columns: Result<Vec<ArrayRef>> = if build_batches.is_empty() {
        Ok(vec![])
    } else {
        (0..build_batches[0].num_columns())
            .map(|col_idx| gather_column(build_batches, col_idx, build_indices))
            .collect()
    };
    let build_columns = build_columns?;

    // Gather probe columns
    let probe_indices_arr: Vec<u32> = probe_indices.iter().map(|&i| i as u32).collect();
    let probe_index_arr = UInt32Array::from(probe_indices_arr);

    let probe_columns: Result<Vec<ArrayRef>> = probe_batch
        .columns()
        .iter()
        .map(|col| compute::take(col.as_ref(), &probe_index_arr, None).map_err(Into::into))
        .collect();
    let probe_columns = probe_columns?;

    let columns: Vec<ArrayRef> = if swapped {
        probe_columns.into_iter().chain(build_columns).collect()
    } else {
        build_columns.into_iter().chain(probe_columns).collect()
    };

    // Retention mask (join-output pruning): the spill path gathers full
    // width and drops the unreferenced columns here — correctness only,
    // the delegate path is where pruning saves the gather itself.
    let columns: Vec<ArrayRef> = match retained {
        Some(mask) if mask.len() == columns.len() => columns
            .into_iter()
            .zip(mask)
            .filter(|(_, keep)| **keep)
            .map(|(c, _)| c)
            .collect(),
        _ => columns,
    };

    // Same "declared Utf8 vs actual Dictionary" class as
    // `ExternalSortExec`'s spill path above (`output_schema` is a
    // `plan_schema_to_arrow`-derived declared schema; `columns` are
    // GATHERED via `compute::take`, which preserves whatever the build/
    // probe batches' actual encoding is). Found the same way: a real
    // SF=10 query (Q12, whose join output must carry the low-cardinality,
    // Dictionary-coerced `l_shipmode`) spilling this hash join over a
    // native table crashed here with the identical error before this fix.
    batch_with_actual_types(output_schema, columns)
}

/// Gather `indices` = (batch_idx, row_idx) of column `col_idx` across
/// `batches` into ONE array. spill-boundaries 003 follow-up: one
/// `compute::interleave` per column (a single `take` when every index comes
/// from one batch). The previous shape — one 1-row `compute::take` per
/// OUTPUT ROW, then `concat` of all of them — allocated an Arrow array per
/// gathered row: for a phase-B read-back chunk's 590k unmatched build rows
/// (a preserved build side) or a 16-batch probe group's pairs, that was
/// millions of ~200-byte allocations per chunk, freed on the global rayon
/// pool's threads and retained by the allocator — measured as the
/// ~+700-900MB phase-B excess of the `left-join` / `filtered-join` harness
/// legs over `semi-join` (see `updates/003/stream-A.md`).
/// `QE_SPILL_GATHER=legacy` keeps the old shape for a controlled A/B.
fn gather_column(
    batches: &[RecordBatch],
    col_idx: usize,
    indices: &[(usize, usize)],
) -> Result<ArrayRef> {
    if matches!(std::env::var("QE_SPILL_GATHER").as_deref(), Ok("legacy")) {
        return gather_column_legacy(batches, col_idx, indices);
    }
    let dt = batches[0].column(col_idx).data_type();
    if indices.is_empty() {
        return Ok(arrow::array::new_null_array(dt, 0));
    }
    let first_batch = indices[0].0;
    if batches.len() == 1 || indices.iter().all(|&(b, _)| b == first_batch) {
        let take_arr: UInt32Array = indices.iter().map(|&(_, r)| r as u32).collect();
        return compute::take(
            batches[first_batch].column(col_idx).as_ref(),
            &take_arr,
            None,
        )
        .map_err(Into::into);
    }
    let arrays: Vec<&dyn arrow::array::Array> =
        batches.iter().map(|b| b.column(col_idx).as_ref()).collect();
    compute::interleave(&arrays, indices).map_err(Into::into)
}

fn gather_column_legacy(
    batches: &[RecordBatch],
    col_idx: usize,
    indices: &[(usize, usize)],
) -> Result<ArrayRef> {
    let mut batch_indices: HashMap<usize, Vec<(usize, u32)>> = HashMap::new();
    for (out_idx, &(batch_idx, row_idx)) in indices.iter().enumerate() {
        batch_indices
            .entry(batch_idx)
            .or_default()
            .push((out_idx, row_idx as u32));
    }
    let total_len = indices.len();
    let dt = batches[0].column(col_idx).data_type();
    let mut builders_data: Vec<(usize, ArrayRef)> = Vec::new();
    for (batch_idx, idx_list) in batch_indices {
        let col = batches[batch_idx].column(col_idx);
        let take_indices: Vec<u32> = idx_list.iter().map(|(_, row)| *row).collect();
        let taken = compute::take(col.as_ref(), &UInt32Array::from(take_indices), None)?;
        for (i, (out_idx, _)) in idx_list.iter().enumerate() {
            builders_data.push((
                *out_idx,
                compute::take(&taken, &UInt32Array::from(vec![i as u32]), None)?,
            ));
        }
    }
    builders_data.sort_by_key(|(idx, _)| *idx);
    if builders_data.is_empty() {
        return Ok(arrow::array::new_null_array(dt, total_len));
    }
    let arrays: Vec<&dyn arrow::array::Array> =
        builders_data.iter().map(|(_, arr)| arr.as_ref()).collect();
    compute::concat(&arrays).map_err(Into::into)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_estimate_batch_size() {
        use arrow::array::Int64Array;
        use arrow::datatypes::{DataType, Field, Schema};

        let schema = Arc::new(Schema::new(vec![Field::new("a", DataType::Int64, false)]));
        let batch = RecordBatch::try_new(
            schema,
            vec![Arc::new(Int64Array::from(vec![1, 2, 3, 4, 5]))],
        )
        .unwrap();

        let size = estimate_batch_size(&batch);
        assert!(size > 0);
    }

    /// Regression test for `spill-size-estimate-fix` epic, task 001: builds
    /// a Dictionary column whose values array is sliced out of a single
    /// oversized shared allocation via `Buffer::from_custom_allocation` --
    /// exactly `ipc_cache.rs::read_row_group`'s own mmap mechanics, where
    /// ONE `Buffer` backs an entire native-table segment file and every
    /// column's sub-buffers are views into it. Before the fix,
    /// `estimate_batch_size` fell through to `c.get_array_memory_size()`
    /// for `Dictionary` columns, which sums `Buffer::capacity()` --
    /// and a `Buffer` built by `from_custom_allocation` reports the FULL
    /// length passed at construction time forever, regardless of how small
    /// a slice is later carved out of it (this is `Deallocation::Custom`'s
    /// documented behavior in arrow-buffer's `bytes.rs`). This test proves
    /// two things: (1) the oversized-allocation setup below genuinely
    /// reproduces the precondition (`get_array_memory_size()` on the raw
    /// column is tens of MB for 5 logical rows), and (2)
    /// `estimate_batch_size` on the very same batch is now content-aware --
    /// on the order of the real ~50-ish logical bytes, not the shared
    /// allocation's size.
    #[test]
    fn dictionary_column_estimate_is_content_aware_not_mmap_capacity() {
        use arrow::array::{Array, ArrayData, DictionaryArray};
        use arrow::buffer::Buffer;
        use arrow::datatypes::{DataType, Field, Int32Type, Schema};

        // A 32 MiB "mmap" standing in for one native-table segment file --
        // `ipc_cache.rs::read_row_group`'s single `Buffer::from_custom_allocation`
        // over the whole mapped file, which every column's every buffer in
        // that segment is then sliced out of.
        let oversized_len = 32 * 1024 * 1024;
        let raw: Arc<Box<[u8]>> = Arc::new(vec![0u8; oversized_len].into_boxed_slice());
        let ptr = std::ptr::NonNull::new(raw.as_ptr() as *mut u8).unwrap();
        // SAFETY: `raw` (kept alive via the `Arc` passed as the allocation
        // owner) is a `oversized_len`-byte heap allocation; `ptr`/`oversized_len`
        // describe exactly that allocation.
        let mmap_buffer = unsafe { Buffer::from_custom_allocation(ptr, oversized_len, raw) };

        // Dictionary VALUES ("MAIL"/"SHIP"/"RAIL", Q12's own l_shipmode
        // values): a small Utf8 array whose data buffer is a slice of the
        // oversized shared allocation above -- the same shape
        // `read_dictionary`'s `buffer.slice_with_length(...)` produces.
        let values_bytes = b"MAILSHIPRAIL";
        let values_data_buf = mmap_buffer.slice_with_length(0, values_bytes.len());
        let offsets_buf = Buffer::from_slice_ref(&[0i32, 4, 8, 12]);
        let values_data = ArrayData::builder(DataType::Utf8)
            .len(3)
            .add_buffer(offsets_buf)
            .add_buffer(values_data_buf)
            .build()
            .unwrap();

        // Keys: 5 rows referencing the 3 dictionary entries (a normal,
        // non-oversized buffer -- only the values buffer needs to be
        // mmap-backed to reproduce the bug, since the OLD fallback summed
        // buffer capacities across the Dictionary array AND its child
        // (values) data).
        let keys_buf = Buffer::from_slice_ref(&[0i32, 1, 2, 0, 1]);
        let dict_type = DataType::Dictionary(Box::new(DataType::Int32), Box::new(DataType::Utf8));
        let dict_data = ArrayData::builder(dict_type.clone())
            .len(5)
            .add_buffer(keys_buf)
            .child_data(vec![values_data])
            .build()
            .unwrap();
        let dict_array: DictionaryArray<Int32Type> = DictionaryArray::from(dict_data);

        let schema = Arc::new(Schema::new(vec![Field::new(
            "l_shipmode",
            dict_type,
            false,
        )]));
        let batch = RecordBatch::try_new(schema, vec![Arc::new(dict_array) as ArrayRef]).unwrap();

        let col = batch.column(0);
        let old_buggy_size = col.get_array_memory_size();
        assert!(
            old_buggy_size > 16 * 1024 * 1024,
            "test setup didn't reproduce the mmap-capacity precondition: \
             get_array_memory_size()={old_buggy_size}"
        );

        let fixed_size = estimate_batch_size(&batch);
        assert!(
            fixed_size < 1024,
            "estimate_batch_size should be content-aware (tens of bytes for \
             5 rows over a 3-entry dictionary), got {fixed_size} bytes -- \
             still reading the mmap-backed buffer's capacity instead of its \
             logical content"
        );
    }

    /// `append_batch_streaming` is the task 002 fix for `append_to_parquet`'s
    /// O(n^2) read-entire-file+rewrite-rename-per-append pattern (see its
    /// own doc comment for the full story). This appends many small batches
    /// to the SAME spill file — the exact call pattern
    /// `build_with_partitioning`/`probe_with_spilling` use — through one
    /// shared writer slot, then confirms every row survives the round trip
    /// exactly, in the order written (Parquet preserves row-group write
    /// order and `read_parquet` reads row groups in file order).
    #[test]
    fn append_batch_streaming_preserves_all_rows_across_many_appends() {
        use arrow::datatypes::{DataType, Field, Schema};

        let dir = std::env::temp_dir().join(format!(
            "qe_append_streaming_correctness_{}",
            std::process::id()
        ));
        let _ = std::fs::remove_dir_all(&dir);
        std::fs::create_dir_all(&dir).unwrap();
        let path = dir.join("build_0.parquet");

        let schema = Arc::new(Schema::new(vec![Field::new("v", DataType::Int64, false)]));
        let mut writer: Option<ArrowWriter<File>> = None;
        let n_batches = 50;
        let batch_len = 37; // deliberately not a round number
        let mut expected: Vec<i64> = Vec::new();

        for i in 0..n_batches {
            let start = (i * batch_len) as i64;
            let vals: Vec<i64> = (start..start + batch_len as i64).collect();
            expected.extend_from_slice(&vals);
            let batch =
                RecordBatch::try_new(schema.clone(), vec![Arc::new(Int64Array::from(vals))])
                    .unwrap();
            append_batch_streaming(&mut writer, &path, &batch)
                .expect("streaming append must not fail");
        }
        close_spill_writers(vec![writer]).expect("closing the writer must not fail");

        let read_back = read_parquet(&path).expect("spill file must be readable after close");
        let mut actual: Vec<i64> = Vec::new();
        for batch in &read_back {
            let arr = batch
                .column(0)
                .as_any()
                .downcast_ref::<Int64Array>()
                .unwrap();
            actual.extend(arr.values().iter().copied());
        }
        assert_eq!(
            actual, expected,
            "every appended batch's rows must survive, in write order"
        );

        let _ = std::fs::remove_dir_all(&dir);
    }

    /// Direct evidence for task 002's own acceptance criterion: "cost per
    /// append does not grow with the total data already spilled for that
    /// partition." Times one append early (right after the file already has
    /// one batch in it) and one late (after ~300 more appends), through the
    /// SAME writer slot/file `build_with_partitioning` would use, and
    /// asserts the late append is not dramatically more expensive than the
    /// early one. A generous multiplier avoids flaking on scheduler jitter
    /// while still clearly failing if the old O(n)-per-append cost (which
    /// would make append #301 roughly 150x the cost of append #2, since the
    /// file being fully re-read+rewritten on every call would have grown
    /// ~150x between the two measurements) ever regresses back in.
    #[test]
    fn append_batch_streaming_cost_does_not_grow_with_prior_data() {
        use arrow::datatypes::{DataType, Field, Schema};
        use std::time::{Duration, Instant};

        let dir =
            std::env::temp_dir().join(format!("qe_append_streaming_cost_{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        std::fs::create_dir_all(&dir).unwrap();
        let path = dir.join("build_0.parquet");

        let schema = Arc::new(Schema::new(vec![
            Field::new("k", DataType::Int64, false),
            Field::new("v", DataType::Float64, false),
        ]));
        let make_batch = || {
            let n = 500usize;
            RecordBatch::try_new(
                schema.clone(),
                vec![
                    Arc::new(Int64Array::from((0..n as i64).collect::<Vec<_>>())),
                    Arc::new(Float64Array::from(vec![1.5f64; n])),
                ],
            )
            .unwrap()
        };

        let mut writer: Option<ArrowWriter<File>> = None;

        // Prime the file with one batch, then time append #2.
        append_batch_streaming(&mut writer, &path, &make_batch()).unwrap();
        let t0 = Instant::now();
        append_batch_streaming(&mut writer, &path, &make_batch()).unwrap();
        let early = t0.elapsed();

        // 300 more appends — under the OLD read-rewrite-rename
        // implementation, the file being re-read+rewritten on every call
        // here would have grown ~150x between the early and late
        // measurement below.
        for _ in 0..300 {
            append_batch_streaming(&mut writer, &path, &make_batch()).unwrap();
        }

        let t1 = Instant::now();
        append_batch_streaming(&mut writer, &path, &make_batch()).unwrap();
        let late = t1.elapsed();

        close_spill_writers(vec![writer]).unwrap();
        let total_rows: usize = read_parquet(&path)
            .unwrap()
            .iter()
            .map(|b| b.num_rows())
            .sum();
        assert_eq!(total_rows, 500 * (2 + 300 + 1));

        assert!(
            late < early * 20 + Duration::from_millis(25),
            "append cost grew with prior data (early={:?}, late={:?}) — \
             the O(n^2) read-rewrite-rename pattern may have regressed",
            early,
            late
        );

        let _ = std::fs::remove_dir_all(&dir);
    }

    /// Disjoint fused aggregation must produce EXACTLY what the plain
    /// aggregate produces, at a group count high enough that worker states
    /// abandon their perfect-hash arrays mid-build. The first disjoint
    /// finalize skipped the per-state raw prep and silently emitted only the
    /// raw-map groups — Q11 at SF=100 lost ~70% of every SUM while still
    /// returning the right ROW COUNT. Row counts are not answers.
    #[tokio::test]
    async fn disjoint_aggregation_matches_plain_aggregation_exactly() {
        use arrow::array::{Float64Array, Int64Array};
        use arrow::datatypes::{DataType, Field, Schema};

        // 3M rows over 300k dense keys: big enough for raw/perfect-hash
        // transitions inside worker states, keyed densely like c_custkey.
        let n_rows = 3_000_000usize;
        let n_keys = 300_000i64;
        let schema = Arc::new(Schema::new(vec![
            Field::new("k", DataType::Int64, false),
            Field::new("v", DataType::Float64, false),
        ]));
        let mut batches = Vec::new();
        for chunk in 0..(n_rows / 8192) {
            let start = chunk * 8192;
            let keys: Vec<i64> = (start..start + 8192)
                .map(|i| (i as i64 * 2654435761i64.wrapping_abs()) % n_keys)
                .collect();
            let vals: Vec<f64> = keys.iter().map(|k| (*k % 97) as f64 + 0.5).collect();
            batches.push(
                RecordBatch::try_new(
                    schema.clone(),
                    vec![
                        Arc::new(Int64Array::from(keys)),
                        Arc::new(Float64Array::from(vals)),
                    ],
                )
                .unwrap(),
            );
        }
        let input: Arc<dyn PhysicalOperator> = Arc::new(
            crate::physical::operators::MemoryTableExec::new("t", schema.clone(), batches, None),
        );

        let group_by = vec![Expr::column("k")];
        let aggs = vec![AggregateExpr {
            func: crate::planner::AggregateFunction::Sum,
            input: Expr::column("v"),
            distinct: false,
            second_arg: None,
        }];
        let out_schema = Arc::new(Schema::new(vec![
            Field::new("k", DataType::Int64, false),
            Field::new("sum_v", DataType::Float64, true),
        ]));

        let pool = crate::execution::create_memory_pool(8 * 1024 * 1024 * 1024);
        let config = ExecutionConfig::default();

        let mut results = Vec::new();
        for disjoint in [false, true] {
            let agg = SpillableHashAggregateExec::new(
                input.clone(),
                group_by.clone(),
                aggs.clone(),
                out_schema.clone(),
                pool.clone(),
                config.clone(),
            )
            .with_disjoint_groups(disjoint);
            let mut stream = agg.execute(0).await.unwrap();
            let mut rows: Vec<(i64, f64)> = Vec::new();
            use futures::TryStreamExt;
            while let Some(b) = stream.try_next().await.unwrap() {
                let k = b.column(0).as_any().downcast_ref::<Int64Array>().unwrap();
                let v = b.column(1).as_any().downcast_ref::<Float64Array>().unwrap();
                for i in 0..b.num_rows() {
                    rows.push((k.value(i), v.value(i)));
                }
            }
            rows.sort_by(|a, b| a.0.cmp(&b.0));
            results.push(rows);
        }
        assert_eq!(results[0].len(), results[1].len(), "group count differs");
        for (a, b) in results[0].iter().zip(results[1].iter()) {
            assert_eq!(a.0, b.0, "group keys diverge");
            assert!(
                (a.1 - b.1).abs() < 1e-6,
                "sum for key {} differs: {} vs {}",
                a.0,
                a.1,
                b.1
            );
        }
    }

    /// Gate C (`SpillableHashJoinExec::set_retained`) must never diverge
    /// from Gate B (`HashJoinExec::set_retained`). The wrapper narrows its
    /// OWN `schema()` to the retained mask immediately in `set_retained`,
    /// then separately hands the exact same mask to the inner
    /// `HashJoinExec` it delegates to for the in-memory build path
    /// (`hj.set_retained(self.retained.clone())`). If that inner gate ever
    /// declined a mask this wrapper's gate accepted, `self.schema()` would
    /// promise fewer columns than the delegate's stream actually returns —
    /// a unit test on `HashJoinExec` alone can never see this, because it
    /// never goes through the wrapper's OWN (separate) gate check.
    #[tokio::test]
    async fn spillable_hash_join_retained_mask_matches_delegate_schema() {
        use arrow::array::Array;
        use arrow::datatypes::{DataType, Field, Schema};
        use futures::TryStreamExt;

        let left_schema = Arc::new(Schema::new(vec![
            Field::new("id", DataType::Int64, false),
            Field::new("keep_left", DataType::Int64, false),
            Field::new("filter_left", DataType::Int64, false),
            Field::new("drop_left", DataType::Int64, false),
        ]));
        let left_batch = RecordBatch::try_new(
            left_schema.clone(),
            vec![
                Arc::new(Int64Array::from(vec![1, 2, 3, 4, 5, 6])),
                Arc::new(Int64Array::from(vec![10, 20, 30, 40, 50, 60])),
                // Odd ids pass the ON-filter (>5), even ids fail it — a
                // build-side (left) column referenced ONLY by the filter,
                // never selected downstream: without force-keep this would
                // be pruned away before the filter can evaluate it.
                Arc::new(Int64Array::from(vec![10, 3, 10, 3, 10, 3])),
                Arc::new(Int64Array::from(vec![111, 222, 333, 444, 555, 666])),
            ],
        )
        .unwrap();

        let right_schema = Arc::new(Schema::new(vec![
            Field::new("rid", DataType::Int64, false),
            Field::new("keep_right", DataType::Int64, false),
            Field::new("drop_right", DataType::Int64, false),
        ]));
        let right_batch = RecordBatch::try_new(
            right_schema.clone(),
            vec![
                Arc::new(Int64Array::from(vec![1, 2, 3, 4, 5, 6])),
                Arc::new(Int64Array::from(vec![100, 200, 300, 400, 500, 600])),
                Arc::new(Int64Array::from(vec![999, 998, 997, 996, 995, 994])),
            ],
        )
        .unwrap();

        let left: Arc<dyn PhysicalOperator> =
            Arc::new(crate::physical::operators::MemoryTableExec::new(
                "left_t",
                left_schema,
                vec![left_batch],
                None,
            ));
        let right: Arc<dyn PhysicalOperator> =
            Arc::new(crate::physical::operators::MemoryTableExec::new(
                "right_t",
                right_schema,
                vec![right_batch],
                None,
            ));

        let pool = crate::execution::create_memory_pool(64 * 1024 * 1024);
        let config = ExecutionConfig::default();
        let mut join = SpillableHashJoinExec::new(
            left,
            right,
            vec![(Expr::column("id"), Expr::column("rid"))],
            JoinType::Left,
            pool,
            config,
        )
        .with_filter(Some(
            Expr::column("filter_left").gt(Expr::literal(crate::planner::ScalarValue::Int64(5))),
        ));

        // Force-keep (filter_left, referenced only by the ON predicate) +
        // downstream need (keep_left, keep_right); drop the join keys and
        // the two never-referenced columns. Order: id, keep_left,
        // filter_left, drop_left, rid, keep_right, drop_right.
        let mask = vec![false, true, true, false, false, true, false];
        join.set_retained(Some(mask));

        assert_eq!(
            join.schema().fields().len(),
            3,
            "wrapper schema should already reflect the retained mask"
        );
        let join_schema = join.schema();
        let field_names: Vec<&str> = join_schema
            .fields()
            .iter()
            .map(|f| f.name().as_str())
            .collect();
        assert_eq!(field_names, vec!["keep_left", "filter_left", "keep_right"]);

        let mut stream = join.execute(0).await.unwrap();
        let mut rows: Vec<(i64, i64, Option<i64>)> = Vec::new();
        while let Some(batch) = stream.try_next().await.unwrap() {
            // Gate B/Gate C lockstep check: the ACTUAL batch schema must
            // match the wrapper's advertised (already-narrowed) schema, in
            // both width and field order/names — this is what would fail
            // (column-count mismatch) if the two gates ever disagreed.
            assert_eq!(
                batch.schema().fields().len(),
                join.schema().fields().len(),
                "delegate produced a different column count than the wrapper's schema() promised"
            );
            for (a, b) in batch.schema().fields().iter().zip(join.schema().fields()) {
                assert_eq!(a.name(), b.name());
            }
            let keep_left = batch
                .column(0)
                .as_any()
                .downcast_ref::<Int64Array>()
                .unwrap();
            let filter_left = batch
                .column(1)
                .as_any()
                .downcast_ref::<Int64Array>()
                .unwrap();
            let keep_right = batch
                .column(2)
                .as_any()
                .downcast_ref::<Int64Array>()
                .unwrap();
            for i in 0..batch.num_rows() {
                rows.push((
                    keep_left.value(i),
                    filter_left.value(i),
                    if keep_right.is_null(i) {
                        None
                    } else {
                        Some(keep_right.value(i))
                    },
                ));
            }
        }
        rows.sort_by_key(|r| r.0);
        assert_eq!(
            rows,
            vec![
                (10, 10, Some(100)),
                (20, 3, None),
                (30, 10, Some(300)),
                (40, 3, None),
                (50, 10, Some(500)),
                (60, 3, None),
            ],
            "Left join + force-kept filter column + pruned join keys/unused columns"
        );
    }

    /// A `Dictionary(Int32, Utf8)`-encoded column reaching `ExternalSortExec`'s
    /// SPILL path (not its in-memory `SortExec` delegate, already exercised
    /// elsewhere) previously failed outright: "column types must match
    /// schema types, expected Utf8 but found Dictionary(Int32, Utf8)".
    /// `flush_run`/`build_merged_batch`/`build_merged_batch_final` all
    /// constructed their output `RecordBatch` against `self.schema` (a
    /// `plan_schema_to_arrow`-derived DECLARED schema, which has no
    /// Dictionary representation and so always reports a string column as
    /// plain `Utf8`) instead of the batches' own ACTUAL type. Found by
    /// native-tables-mutation task 006's real-scale `ORDER BY` validation
    /// over a native table (whose low-cardinality string columns are always
    /// Dictionary-encoded) large enough to spill; reproduces on an
    /// unmutated native table too, so this is a pre-existing external-sort
    /// gap, not something mutation introduced.
    #[tokio::test]
    async fn external_sort_spill_path_handles_dictionary_encoded_columns() {
        use arrow::array::DictionaryArray;
        use arrow::datatypes::{DataType, Field, Int32Type, Schema};

        // DECLARED schema: plain Utf8 for the string column, mirroring
        // `plan_schema_to_arrow`'s own logical->physical mapping (it has no
        // Dictionary variant, so a string column is always declared Utf8
        // regardless of a provider's actual physical encoding).
        let declared_schema = Arc::new(Schema::new(vec![
            Field::new("k", DataType::Int64, false),
            Field::new("v", DataType::Utf8, false),
        ]));
        // ACTUAL schema of the batches themselves -- what a native table's
        // segments genuinely are on disk. `MemoryTableExec` stores batches
        // and its own declared `schema` independently (reconciling only
        // inside `execute()`), so constructing a batch here must use its
        // OWN real type, exactly like a real provider's scan output would.
        let actual_schema = Arc::new(Schema::new(vec![
            Field::new("k", DataType::Int64, false),
            Field::new(
                "v",
                DataType::Dictionary(Box::new(DataType::Int32), Box::new(DataType::Utf8)),
                false,
            ),
        ]));

        // Several batches whose ACTUAL data is Dictionary-encoded (as a
        // native table's low-cardinality string columns always are), keys
        // in descending order so a correct sort must reverse them.
        let mut batches = Vec::new();
        for chunk in 0..4i64 {
            let start = chunk * 4;
            let keys: Vec<i64> = (start..start + 4).rev().collect();
            let dict: DictionaryArray<Int32Type> = keys
                .iter()
                .map(|k| Some(if k % 2 == 0 { "alpha" } else { "beta" }))
                .collect();
            batches.push(
                RecordBatch::try_new(
                    actual_schema.clone(),
                    vec![Arc::new(Int64Array::from(keys)), Arc::new(dict)],
                )
                .unwrap(),
            );
        }

        let input: Arc<dyn PhysicalOperator> = Arc::new(
            crate::physical::operators::MemoryTableExec::new("t", declared_schema, batches, None),
        );

        // A tiny memory budget forces the SPILL branch (not the in-memory
        // SortExec delegate) even for this handful of rows.
        let pool = crate::execution::create_memory_pool(1024);
        let mut config = ExecutionConfig::default();
        config.memory_limit = 1024;
        config.spill_threshold = 0.1;
        config.spill_path =
            std::env::temp_dir().join(format!("qe_sort_dict_spill_test_{}", std::process::id()));

        let sort = ExternalSortExec::new(
            input,
            vec![crate::planner::SortExpr::new(Expr::column("k"))],
            pool,
            config,
        );

        let mut stream = sort.execute(0).await.expect("spilled sort must not error");
        let mut keys = Vec::new();
        while let Some(batch) = stream.try_next().await.expect("collecting sorted output") {
            let k = batch
                .column(0)
                .as_any()
                .downcast_ref::<Int64Array>()
                .unwrap();
            keys.extend(k.values().iter().copied());
            assert!(
                matches!(batch.column(1).data_type(), DataType::Dictionary(_, _)),
                "sorted output column 1 should still be Dictionary-encoded, got {:?}",
                batch.column(1).data_type()
            );
        }
        assert_eq!(keys.len(), 16);
        assert!(
            keys.windows(2).all(|w| w[0] <= w[1]),
            "output must be sorted ascending by k: {keys:?}"
        );
    }

    /// The k-way merge's `output_rows` buffer held `(run_idx, row_idx)`
    /// pairs indexing into `run_buffers[run_idx]`'s CURRENT in-memory
    /// batch — a reference that went stale (silently wrong, or an
    /// out-of-bounds panic) the instant that slot was reloaded before the
    /// pending rows were flushed. Any run whose Parquet file needs more
    /// than one `buffer_rows`-sized read during merge (the common case for
    /// a real spill: any run over `MERGE_BUFFER_ROWS` = 8192 rows) hit
    /// this. Found by native-tables-mutation task 006's real-scale
    /// `ORDER BY` validation: a real 15M-row sort's spilled-run merge
    /// panicked with "index out of bounds: the len is 5329 but the index
    /// is 5329". This test reproduces the same shape at unit-test scale by
    /// calling `streaming_k_way_merge` directly with a tiny `buffer_rows`
    /// so a 10-row run needs multiple reloads to merge.
    #[tokio::test]
    async fn k_way_merge_survives_a_run_needing_more_than_one_buffer_load() {
        use arrow::datatypes::{DataType, Field, Schema};

        let schema = Arc::new(Schema::new(vec![Field::new("k", DataType::Int64, false)]));
        let dir = std::env::temp_dir().join(format!("qe_kway_merge_test_{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        std::fs::create_dir_all(&dir).unwrap();

        // Run A: 10 rows, sorted -- bigger than the buffer_rows=4 this
        // test uses below, so merging it needs MULTIPLE `next()` reads
        // (the reload this bug loses track of).
        let run_a_vals: Vec<i64> = (0..10).map(|i| i * 2).collect(); // 0,2,4,...,18
        let run_a_batch = RecordBatch::try_new(
            schema.clone(),
            vec![Arc::new(Int64Array::from(run_a_vals.clone()))],
        )
        .unwrap();
        let run_a_path = dir.join("run_a.parquet");
        write_batches_to_parquet(&run_a_path, &[run_a_batch]).unwrap();

        // Run B: 5 rows, interleaved with (a prefix of) A's values.
        let run_b_vals: Vec<i64> = (0..5).map(|i| i * 2 + 1).collect(); // 1,3,5,7,9
        let run_b_batch = RecordBatch::try_new(
            schema.clone(),
            vec![Arc::new(Int64Array::from(run_b_vals.clone()))],
        )
        .unwrap();
        let run_b_path = dir.join("run_b.parquet");
        write_batches_to_parquet(&run_b_path, &[run_b_batch]).unwrap();

        let pool = crate::execution::create_memory_pool(64 * 1024 * 1024);
        let config = ExecutionConfig::default();
        let sort = ExternalSortExec::new(
            Arc::new(crate::physical::operators::MemoryTableExec::new(
                "t",
                schema,
                vec![],
                None,
            )),
            vec![crate::planner::SortExpr::new(Expr::column("k"))],
            pool,
            config,
        );

        // buffer_rows=4: run A (10 rows) needs 3 reloads to merge fully.
        let merged = sort
            .streaming_k_way_merge(&[run_a_path, run_b_path], 4)
            .expect("k-way merge must not crash or lose/misplace rows");

        let mut all_vals: Vec<i64> = Vec::new();
        for batch in &merged {
            let arr = batch
                .column(0)
                .as_any()
                .downcast_ref::<Int64Array>()
                .unwrap();
            all_vals.extend(arr.values().iter().copied());
        }
        let mut expected: Vec<i64> = run_a_vals.into_iter().chain(run_b_vals).collect();
        expected.sort_unstable();
        assert_eq!(
            all_vals, expected,
            "k-way merge must produce every value from both runs, in order, exactly once"
        );

        let _ = std::fs::remove_dir_all(&dir);
    }

    /// Same "declared Utf8 vs actual Dictionary" bug class as
    /// `ExternalSortExec`'s spill path, in `SpillableHashJoinExec`'s own
    /// spill-path join-output constructor (`create_joined_batch`). Found
    /// by native-tables-mutation task 006's real-scale SF=10 benchmark:
    /// Q12 (whose join output carries the Dictionary-coerced `l_shipmode`)
    /// crashed identically once its join spilled over a native table.
    #[test]
    fn create_joined_batch_handles_dictionary_encoded_columns() {
        use arrow::array::DictionaryArray;
        use arrow::datatypes::{DataType, Field, Int32Type, Schema};

        // DECLARED (plan_schema_to_arrow-shaped) output schema: plain
        // Utf8 for the string column.
        let output_schema = Arc::new(Schema::new(vec![
            Field::new("id", DataType::Int64, false),
            Field::new("tag", DataType::Utf8, false),
        ]));

        // ACTUAL build-side batch: Dictionary-encoded `tag`, as a native
        // table's low-cardinality string columns always are.
        let build_schema = Arc::new(Schema::new(vec![
            Field::new("id", DataType::Int64, false),
            Field::new(
                "tag",
                DataType::Dictionary(Box::new(DataType::Int32), Box::new(DataType::Utf8)),
                false,
            ),
        ]));
        let dict: DictionaryArray<Int32Type> = vec![Some("alpha"), Some("beta"), Some("alpha")]
            .into_iter()
            .collect();
        let build_batch = RecordBatch::try_new(
            build_schema,
            vec![Arc::new(Int64Array::from(vec![1, 2, 3])), Arc::new(dict)],
        )
        .unwrap();

        // An empty-schema probe side keeps this test focused on the
        // build-side gather (`compute::take`), which is where the actual
        // Dictionary encoding survives into the joined output.
        let probe_schema = Arc::new(Schema::new(Vec::<Field>::new()));
        let probe_batch = RecordBatch::try_new_with_options(
            probe_schema,
            vec![],
            &arrow::record_batch::RecordBatchOptions::new().with_row_count(Some(3)),
        )
        .unwrap();

        let result = create_joined_batch(
            &[build_batch],
            &probe_batch,
            &[(0, 0), (0, 1), (0, 2)],
            &[0, 1, 2],
            false,
            &output_schema,
            None,
        )
        .expect("must not error on a Dictionary-encoded build column");

        assert_eq!(result.num_rows(), 3);
        assert!(
            matches!(result.column(1).data_type(), DataType::Dictionary(_, _)),
            "joined output column 1 should still be Dictionary-encoded, got {:?}",
            result.column(1).data_type()
        );
    }

    /// spill-join-correctness-2 epic, task 001: `KeyChecksum` is the direct
    /// write-vs-read comparison mechanism this task added to catch a
    /// Trino-PR#25892-shaped bug (spill wrote a join key one way, unspill
    /// read it back differently) in the act. This test pins its two
    /// load-bearing properties: identical logical key data produces an
    /// IDENTICAL checksum regardless of how it's split across batches or
    /// what order the rows appear in (both are true of a real Parquet
    /// spill/unspill round trip — row-group boundaries and, in general,
    /// row order are not guaranteed to match the pre-spill batch shape),
    /// and genuinely DIFFERENT key data produces a different checksum (so
    /// the mechanism would actually catch a real mismatch, not just always
    /// report "ok").
    #[test]
    fn key_checksum_is_order_and_batch_split_independent_but_detects_real_differences() {
        use arrow::datatypes::{DataType, Field, Schema};

        let schema = Arc::new(Schema::new(vec![Field::new("k", DataType::Int64, false)]));
        let key_expr = vec![Expr::column("k")];

        let one_batch = RecordBatch::try_new(
            schema.clone(),
            vec![Arc::new(Int64Array::from(vec![10, 20, 30, 40, 50]))],
        )
        .unwrap();
        let cs_one = batch_key_checksum(&one_batch, &key_expr).unwrap();

        // Same logical rows, split across three batches AND reordered —
        // exactly what a spill (writes in arrival order, across many
        // batches) followed by an unspill (reads back in row-group order,
        // which need not match) can produce.
        let split_a = RecordBatch::try_new(
            schema.clone(),
            vec![Arc::new(Int64Array::from(vec![40, 10]))],
        )
        .unwrap();
        let split_b =
            RecordBatch::try_new(schema.clone(), vec![Arc::new(Int64Array::from(vec![50]))])
                .unwrap();
        let split_c = RecordBatch::try_new(
            schema.clone(),
            vec![Arc::new(Int64Array::from(vec![20, 30]))],
        )
        .unwrap();
        let mut cs_split = KeyChecksum::default();
        for b in [&split_a, &split_b, &split_c] {
            cs_split.accumulate(batch_key_checksum(b, &key_expr).unwrap());
        }

        assert_eq!(
            cs_one.rows, cs_split.rows,
            "row count must match regardless of batch splitting"
        );
        assert_eq!(
            cs_one.xor_hash, cs_split.xor_hash,
            "checksum must be identical for the same logical keys \
             regardless of batch splitting or row order"
        );
        assert_eq!(cs_one.unhandled_type_rows, 0);
        assert_eq!(cs_split.unhandled_type_rows, 0);

        // Genuinely different key data (one value changed) must NOT
        // checksum the same — otherwise this mechanism could never catch a
        // real mismatch.
        let different = RecordBatch::try_new(
            schema,
            vec![Arc::new(Int64Array::from(vec![10, 20, 30, 40, 999]))],
        )
        .unwrap();
        let cs_different = batch_key_checksum(&different, &key_expr).unwrap();
        assert_eq!(cs_different.rows, cs_one.rows);
        assert_ne!(
            cs_different.xor_hash, cs_one.xor_hash,
            "a real difference in key data must change the checksum"
        );
    }

    /// A NULL-valued key (real SQL NULL) must never be flagged as
    /// `unhandled_type_rows` — that counter exists specifically to isolate
    /// `extract_join_key`'s downcast-chain gap (an array type it doesn't
    /// recognize, e.g. a Dictionary-encoded key column) from an ordinary,
    /// expected NULL.
    #[test]
    fn key_checksum_does_not_confuse_real_null_with_an_unhandled_array_type() {
        use arrow::datatypes::{DataType, Field, Schema};

        let schema = Arc::new(Schema::new(vec![Field::new("k", DataType::Int64, true)]));
        let key_expr = vec![Expr::column("k")];
        let batch = RecordBatch::try_new(
            schema,
            vec![Arc::new(Int64Array::from(vec![Some(1), None, Some(3)]))],
        )
        .unwrap();
        let cs = batch_key_checksum(&batch, &key_expr).unwrap();
        assert_eq!(cs.rows, 3);
        assert_eq!(
            cs.unhandled_type_rows, 0,
            "a genuine SQL NULL is a handled case, not an unhandled array type"
        );
    }

    /// spill-join-correctness-2 epic, task 003: pure-parsing unit tests for
    /// the two fault-injection env vars (see this file's own "Fault
    /// injection: forced spill" module doc comment). Deliberately test the
    /// `parse_*`/`ChaosPartitionSpec::parse` functions directly rather than
    /// `std::env::set_var` + the `chaos_force_spill_*` wrappers — this test
    /// binary runs many tests concurrently in one process, and mutating the
    /// real environment here would race any other test reading the same
    /// keys (same reasoning as `gpu.rs`'s `parse_cache_budget_mb` and
    /// `execution::context::parse_merge_concurrency`).
    #[test]
    fn chaos_force_spill_after_batches_parsing() {
        assert_eq!(parse_chaos_force_spill_after_batches(None), None);
        // Set but empty/unparseable: still "force," defaulting to batch 0.
        assert_eq!(parse_chaos_force_spill_after_batches(Some("")), Some(0));
        assert_eq!(
            parse_chaos_force_spill_after_batches(Some("not_a_number")),
            Some(0)
        );
        assert_eq!(parse_chaos_force_spill_after_batches(Some("0")), Some(0));
        assert_eq!(parse_chaos_force_spill_after_batches(Some("7")), Some(7));
        // Whitespace tolerated, matching this file's own `QE_SPILL_DEBUG`-
        // adjacent env-parsing conventions elsewhere.
        assert_eq!(parse_chaos_force_spill_after_batches(Some(" 3 ")), Some(3));
    }

    #[test]
    fn chaos_partition_spec_parsing() {
        assert!(matches!(
            ChaosPartitionSpec::parse("all"),
            ChaosPartitionSpec::All
        ));
        assert!(matches!(
            ChaosPartitionSpec::parse("ALL"),
            ChaosPartitionSpec::All
        ));
        assert!(matches!(
            ChaosPartitionSpec::parse("  all  "),
            ChaosPartitionSpec::All
        ));

        match ChaosPartitionSpec::parse("0,3,17") {
            ChaosPartitionSpec::Indices(set) => {
                assert_eq!(set, [0usize, 3, 17].into_iter().collect())
            }
            other => panic!("expected Indices, got {other:?}"),
        }

        // Whitespace around entries tolerated; unparseable tokens silently
        // skipped rather than panicking (a malformed harness invocation
        // should force nothing, not crash the query it's testing).
        match ChaosPartitionSpec::parse(" 2 , x , 9,") {
            ChaosPartitionSpec::Indices(set) => {
                assert_eq!(set, [2usize, 9].into_iter().collect())
            }
            other => panic!("expected Indices, got {other:?}"),
        }

        match ChaosPartitionSpec::parse("") {
            ChaosPartitionSpec::Indices(set) => assert!(set.is_empty()),
            other => panic!("expected empty Indices, got {other:?}"),
        }

        for idx in 0..NUM_PARTITIONS {
            assert!(ChaosPartitionSpec::All.contains(idx));
        }
        let some = ChaosPartitionSpec::Indices([1usize, 2, 3].into_iter().collect());
        assert!(some.contains(2));
        assert!(!some.contains(4));
    }

    /// spill-join-correctness-2 epic, task 004, bug 2: `ORDER BY ... LIMIT`
    /// under spill (Q2/Q3-shaped, per the archived epic's own `003.md`
    /// characterization). The top-k fusion rule in `planner.rs`
    /// (`LogicalPlan::Limit` with `skip == 0` over a `Sort` folds directly
    /// into `ExternalSortExec::with_fetch` instead of wrapping a separate
    /// `LimitExec` around it) means `ExternalSortExec::execute()`'s SPILL
    /// branch is the only place a spilled top-K query's row count is ever
    /// truncated — before the fix, `self.fetch` was stored but never
    /// consulted again anywhere in that branch, so the full, correctly
    /// globally-sorted output was returned instead of just its first
    /// `fetch` rows: right values, wrong (too large) row count, matching
    /// the archived epic's own exact symptom description.
    #[tokio::test]
    async fn external_sort_spill_path_enforces_limit_under_forced_spill() {
        use arrow::datatypes::{DataType, Field, Schema};

        let schema = Arc::new(Schema::new(vec![Field::new("k", DataType::Int64, false)]));

        // 20 single-row batches, descending values 19..0 — enough rows that
        // a tiny memory budget forces several separate spill runs (not just
        // a trivial single-run passthrough), while staying under
        // `MAX_MERGE_FANIN` = 8 runs so this test stays focused on the
        // LIMIT bug alone, not entangled with the separate multi-pass-merge
        // bug covered by its own test below.
        let mut batches = Vec::new();
        for v in (0..20i64).rev() {
            batches.push(
                RecordBatch::try_new(schema.clone(), vec![Arc::new(Int64Array::from(vec![v]))])
                    .unwrap(),
            );
        }

        let input: Arc<dyn PhysicalOperator> = Arc::new(
            crate::physical::operators::MemoryTableExec::new("t", schema.clone(), batches, None),
        );

        let pool = crate::execution::create_memory_pool(1024);
        let mut config = ExecutionConfig::default();
        config.memory_limit = 64;
        config.spill_threshold = 0.5;
        config.spill_path =
            std::env::temp_dir().join(format!("qe_sort_limit_spill_test_{}", std::process::id()));

        let fetch = 5usize;
        let sort = ExternalSortExec::with_fetch(
            input,
            vec![crate::planner::SortExpr::new(Expr::column("k"))],
            pool,
            config,
            fetch,
        );

        let mut stream = sort
            .execute(0)
            .await
            .expect("spilled sort with LIMIT must not error");
        let mut keys = Vec::new();
        while let Some(batch) = stream
            .try_next()
            .await
            .expect("collecting limited sorted output")
        {
            let k = batch
                .column(0)
                .as_any()
                .downcast_ref::<Int64Array>()
                .unwrap();
            keys.extend(k.values().iter().copied());
        }

        assert_eq!(
            keys.len(),
            fetch,
            "spilled ORDER BY ... LIMIT {fetch} must return exactly {fetch} rows, got {}: {keys:?}",
            keys.len()
        );
        assert_eq!(
            keys,
            (0..fetch as i64).collect::<Vec<_>>(),
            "the LIMIT-ed rows must be the correct top-K prefix (right values), \
             not just the right count: {keys:?}"
        );
    }

    /// spill-join-correctness-2 epic, task 004, bug 3: sort-spill
    /// run-file-not-found crash (Q10-shaped, per the archived epic's own
    /// `003.md`: `Failed to open run file ".../sort_0_27/
    /// merged_pass0_48.parquet": No such file or directory`).
    /// `multi_pass_merge`'s "clean up old runs from previous pass" step
    /// unconditionally deleted every path in that pass's `current_runs` —
    /// including any carried forward UNCHANGED into `next_runs` (a chunk of
    /// exactly one leftover run, whenever a pass's run count isn't an exact
    /// multiple of `MAX_MERGE_FANIN` = 8) — so a later pass, or the final
    /// merge, tried to open a file this same function had just deleted out
    /// from under it. Reproduces the exact arithmetic deterministically:
    /// 129 initial single-row runs -> pass 0's chunking (129 = 16*8 + 1)
    /// leaves a 1-run leftover chunk at the tail, carried into pass 1 as
    /// one of 17 runs; pass 1's own chunking (17 = 2*8 + 1) again leaves a
    /// 1-run leftover chunk at the tail — exactly the run this bug deleted
    /// while pass 1's own `next_runs` (and the final merge right after)
    /// still needed it.
    #[tokio::test]
    async fn external_sort_multi_pass_merge_survives_a_leftover_singleton_chunk() {
        use arrow::datatypes::{DataType, Field, Schema};

        let schema = Arc::new(Schema::new(vec![Field::new("k", DataType::Int64, false)]));
        let dir =
            std::env::temp_dir().join(format!("qe_multi_pass_merge_test_{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        std::fs::create_dir_all(&dir).unwrap();

        // 129 single-row sorted "runs", one per distinct value 0..129.
        const N: i64 = 129;
        let mut run_paths = Vec::new();
        for v in 0..N {
            let batch =
                RecordBatch::try_new(schema.clone(), vec![Arc::new(Int64Array::from(vec![v]))])
                    .unwrap();
            let path = dir.join(format!("run_{v}.parquet"));
            write_batches_to_parquet(&path, &[batch]).unwrap();
            run_paths.push(path);
        }

        let pool = crate::execution::create_memory_pool(64 * 1024 * 1024);
        let config = ExecutionConfig::default();
        let sort = ExternalSortExec::new(
            Arc::new(crate::physical::operators::MemoryTableExec::new(
                "t",
                schema,
                vec![],
                None,
            )),
            vec![crate::planner::SortExpr::new(Expr::column("k"))],
            pool,
            config,
        );

        let merged = sort
            .merge_runs(&run_paths)
            .expect("multi-pass merge must not fail to open a run file it itself deleted");

        let mut vals: Vec<i64> = Vec::new();
        for batch in &merged {
            let arr = batch
                .column(0)
                .as_any()
                .downcast_ref::<Int64Array>()
                .unwrap();
            vals.extend(arr.values().iter().copied());
        }
        let expected: Vec<i64> = (0..N).collect();
        assert_eq!(
            vals, expected,
            "multi-pass merge must produce every run's row, in order, exactly once"
        );

        let _ = std::fs::remove_dir_all(&dir);
    }

    // Deliberately NO unit test here that calls
    // `std::env::set_var("QE_SPILL_CHAOS_FORCE_SPILL"/"_PARTITIONS", ...)`.
    // An earlier version of this task's own work-in-progress added one
    // (guarded by a local `Mutex` around its own set/unset section) and it
    // genuinely broke an unrelated, pre-existing, otherwise-unmodified test
    // in this exact file
    // (`spillable_hash_join_retained_mask_matches_delegate_schema`, a LEFT
    // JOIN case) under a real `cargo test` run: `cargo test`'s default
    // concurrent-test-thread execution ran that LEFT JOIN test WHILE this
    // module's own chaos test held `QE_SPILL_CHAOS_FORCE_SPILL` set, so the
    // LEFT JOIN's `execute()` call was forced into the disk-spill branch's
    // INNER-only guard and errored/panicked — a real, observed instance of
    // exactly the hazard `gpu.rs`'s `parse_cache_budget_mb` and
    // `execution::context::parse_merge_concurrency` already document
    // ("a test that called `std::env::set_var` here would race every other
    // test reading the same key"). A local mutex only serializes against
    // OTHER tests that also acquire IT — it does nothing for the hundreds
    // of unrelated tests in this same shared binary that don't know it
    // exists. The end-to-end "forced spill produces the same result as an
    // unforced run" invariant this would have checked is instead verified
    // by `examples/spill_chaos_harness.rs` — a SEPARATE PROCESS, so no
    // shared-binary env var race is possible — at far greater scale
    // (thousands of trials; see that file's own module doc comment and
    // this task's Outcome in `003.md` for real run counts/results) than
    // any single unit test would exercise anyway.

    // ------------------------------------------------------------------
    // oom-safety-hardening task 007: join spill-path hash-table budgeting
    // ------------------------------------------------------------------

    fn int64_key_batch(schema: &SchemaRef, ids: Vec<i64>) -> RecordBatch {
        RecordBatch::try_new(schema.clone(), vec![Arc::new(Int64Array::from(ids))]).unwrap()
    }

    /// The sizing helpers must reflect the REAL ~10-20x table-over-batch
    /// amplification task 001 measured (~120-200B/row for unique Int64
    /// keys vs ~12B/row of batch data), or the budgeting they drive is
    /// fiction. Bounds are deliberately loose (allocator/capacity
    /// granularity varies) but strict enough that a regression to "tables
    /// cost roughly what batches cost" fails loudly.
    #[test]
    fn hash_table_sizing_reflects_real_amplification() {
        use arrow::datatypes::{DataType, Field, Schema};
        let rows: usize = 10_000;
        let schema: SchemaRef =
            Arc::new(Schema::new(vec![Field::new("id", DataType::Int64, false)]));
        let batch = int64_key_batch(&schema, (0..rows as i64).collect());
        let table = build_hash_table(&[batch.clone()], &[Expr::column("id")]).unwrap();
        assert_eq!(table.len(), rows);

        let measured = hash_table_memory_bytes(&table);
        let predicted = predicted_hash_table_bytes(rows, 1);
        let batch_bytes = estimate_batch_size(&batch);

        // Real per-row cost band from task 001's profiler evidence.
        assert!(
            measured >= rows * 100 && measured <= rows * 300,
            "measured {} bytes for {} unique keys ({}B/row) — outside the \
             100-300B/row band the real allocations occupy",
            measured,
            rows,
            measured / rows
        );
        assert!(
            predicted >= rows * 100 && predicted <= rows * 200,
            "predicted {}B/row outside 100-200B/row",
            predicted / rows
        );
        // The amplification the budget must account for: table >= 8x the
        // batch bytes the old accounting covered.
        assert!(
            measured >= batch_bytes * 8,
            "measured table bytes ({measured}) should be many times the \
             batch bytes ({batch_bytes})"
        );
    }

    /// Duplicate-heavy keys must cost LESS than the all-unique prediction
    /// (shared buckets/entry vecs) — the prediction only ever errs toward
    /// spilling more readily, never toward under-budgeting.
    #[test]
    fn predicted_hash_table_bytes_is_conservative_for_duplicate_keys() {
        use arrow::datatypes::{DataType, Field, Schema};
        let rows: usize = 10_000;
        let schema: SchemaRef =
            Arc::new(Schema::new(vec![Field::new("id", DataType::Int64, false)]));
        // 100 distinct keys, 100 occurrences each.
        let batch = int64_key_batch(&schema, (0..rows as i64).map(|i| i % 100).collect());
        let table = build_hash_table(&[batch], &[Expr::column("id")]).unwrap();
        assert_eq!(table.len(), 100);
        let measured = hash_table_memory_bytes(&table);
        let predicted = predicted_hash_table_bytes(rows, 1);
        assert!(
            measured < predicted,
            "duplicate-heavy table ({measured}) should cost less than the \
             all-unique prediction ({predicted})"
        );
        // Entries themselves (16B x 10_000) must still be counted.
        assert!(measured >= rows * std::mem::size_of::<HashEntry>());
    }

    /// End-to-end: a spilling INNER join over many unique keys must (1)
    /// stay cell-exact, and (2) hold the memoized resident set — batch
    /// bytes PLUS measured hash-table bytes — under `memory_limit *
    /// spill_threshold`. Before task 007 the tables were built with zero
    /// accounting at ~10-20x the budgeted batch bytes (the 15-24x overshoot
    /// of both oom repros); this asserts the budgeting invariant directly
    /// on the build decision, not just survival.
    #[tokio::test]
    async fn spill_path_hash_tables_are_budgeted_and_join_stays_exact() {
        use arrow::datatypes::{DataType, Field, Schema};
        let build_schema: SchemaRef =
            Arc::new(Schema::new(vec![Field::new("id", DataType::Int64, false)]));
        let total_rows: i64 = 200_000;
        let mut build_batches = Vec::new();
        let mut start = 0i64;
        while start < total_rows {
            let end = (start + 8192).min(total_rows);
            build_batches.push(int64_key_batch(&build_schema, (start..end).collect()));
            start = end;
        }
        let build: Arc<dyn PhysicalOperator> =
            Arc::new(crate::physical::operators::MemoryTableExec::new(
                "build",
                build_schema,
                build_batches,
                None,
            ));

        let probe_schema: SchemaRef =
            Arc::new(Schema::new(vec![Field::new("pid", DataType::Int64, false)]));
        // 4 existing keys (one duplicated → 2 output rows) + 1 missing key.
        let probe_ids = vec![0i64, 12_345, 12_345, 199_999, 777_777_777];
        let probe_batch = int64_key_batch(&probe_schema, probe_ids);
        let probe: Arc<dyn PhysicalOperator> =
            Arc::new(crate::physical::operators::MemoryTableExec::new(
                "probe",
                probe_schema,
                vec![probe_batch],
                None,
            ));

        // 256KB limit: the ~1.6MB of build batches must spill, and the
        // ~27MB of worst-case table bytes must be budgeted, not built.
        let limit = 256 * 1024;
        let pool = crate::execution::create_memory_pool(limit);
        let spill_dir =
            std::env::temp_dir().join(format!("qe_join_table_budget_test_{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&spill_dir);
        let config = ExecutionConfig::new()
            .with_memory_limit(limit)
            .with_spill_path(spill_dir.clone());
        let threshold = (limit as f64 * config.spill_threshold) as usize;

        let join = SpillableHashJoinExec::new(
            build,
            probe,
            vec![(Expr::column("id"), Expr::column("pid"))],
            JoinType::Inner,
            pool,
            config,
        );

        let mut matched: Vec<i64> = Vec::new();
        let mut stream = join.execute(0).await.unwrap();
        while let Some(batch) = stream.try_next().await.unwrap() {
            let ids = batch
                .column(0)
                .as_any()
                .downcast_ref::<Int64Array>()
                .unwrap();
            for i in 0..batch.num_rows() {
                matched.push(ids.value(i));
            }
        }
        matched.sort_unstable();
        assert_eq!(
            matched,
            vec![0, 12_345, 12_345, 199_999],
            "spilling join with budgeted tables must stay cell-exact"
        );

        // The budgeting invariant, asserted on the memoized decision.
        match join.build_decision.get() {
            Some(BuildDecision::Spill(state)) => {
                let batch_bytes: usize = state
                    .partitions
                    .iter()
                    .flatten()
                    .map(|p| p.memory_bytes)
                    .sum();
                let table_bytes: usize = state
                    .tables
                    .iter()
                    .flatten()
                    .map(hash_table_memory_bytes)
                    .sum();
                assert!(
                    batch_bytes + table_bytes <= threshold,
                    "resident batches ({batch_bytes}) + measured tables \
                     ({table_bytes}) exceed the budget ({threshold})"
                );
            }
            _ => panic!("expected a memoized Spill decision"),
        }
        drop(join);
        let _ = std::fs::remove_dir_all(&spill_dir);
    }

    /// Read-back (spilled-partition) processing must chunk its transient
    /// hash table under the budget AND stay exact when a key's multiple
    /// build rows straddle a chunk boundary — every (build,probe) pair
    /// emitted exactly once, unioned across chunks. Build keys appear
    /// TWICE (in two well-separated row ranges, so the two occurrences
    /// land in different read-back batches/chunks); every probed key must
    /// come back exactly twice.
    #[tokio::test]
    async fn spilled_partition_chunked_table_build_is_cell_exact() {
        use arrow::datatypes::{DataType, Field, Schema};
        let build_schema: SchemaRef =
            Arc::new(Schema::new(vec![Field::new("id", DataType::Int64, false)]));
        let distinct: i64 = 20_000;
        let mut build_batches = Vec::new();
        for _pass in 0..2 {
            let mut start = 0i64;
            while start < distinct {
                let end = (start + 1024).min(distinct);
                build_batches.push(int64_key_batch(&build_schema, (start..end).collect()));
                start = end;
            }
        }
        let build: Arc<dyn PhysicalOperator> =
            Arc::new(crate::physical::operators::MemoryTableExec::new(
                "build",
                build_schema,
                build_batches,
                None,
            ));

        let probe_schema: SchemaRef =
            Arc::new(Schema::new(vec![Field::new("pid", DataType::Int64, false)]));
        let probe_ids: Vec<i64> = (0..distinct).step_by(7).collect();
        let expected_rows = probe_ids.len() * 2;
        let probe_batch = int64_key_batch(&probe_schema, probe_ids.clone());
        let probe: Arc<dyn PhysicalOperator> =
            Arc::new(crate::physical::operators::MemoryTableExec::new(
                "probe",
                probe_schema,
                vec![probe_batch],
                None,
            ));

        // 64KB limit → ~51KB threshold: every partition's predicted table
        // (~625 rows x ~136B ≈ 85KB) exceeds it, so partitions evict to
        // disk and read-back chunking engages (multiple chunks per
        // partition).
        let limit = 64 * 1024;
        let pool = crate::execution::create_memory_pool(limit);
        let spill_dir = std::env::temp_dir().join(format!(
            "qe_join_chunked_readback_test_{}",
            std::process::id()
        ));
        let _ = std::fs::remove_dir_all(&spill_dir);
        let config = ExecutionConfig::new()
            .with_memory_limit(limit)
            .with_spill_path(spill_dir.clone());

        let join = SpillableHashJoinExec::new(
            build,
            probe,
            vec![(Expr::column("id"), Expr::column("pid"))],
            JoinType::Inner,
            pool,
            config,
        );

        let mut matched: Vec<i64> = Vec::new();
        let mut stream = join.execute(0).await.unwrap();
        while let Some(batch) = stream.try_next().await.unwrap() {
            let ids = batch
                .column(0)
                .as_any()
                .downcast_ref::<Int64Array>()
                .unwrap();
            for i in 0..batch.num_rows() {
                matched.push(ids.value(i));
            }
        }
        matched.sort_unstable();
        let mut expected: Vec<i64> = probe_ids.iter().flat_map(|&k| [k, k]).collect();
        expected.sort_unstable();
        assert_eq!(matched.len(), expected_rows);
        assert_eq!(
            matched, expected,
            "each probed key must match exactly its two build occurrences, \
             even when they land in different read-back chunks"
        );
        drop(join);
        let _ = std::fs::remove_dir_all(&spill_dir);
    }
    // ------------------------------------------------------------------
    // spill-join-correctness-3 task 004: SEMI/ANTI on the join spill path.
    // Every test below compares the SPILL path (tiny budget, memoized
    // `BuildDecision::Spill`) against the same operator under an
    // effectively unlimited budget, which lands on the `BuildDecision::
    // InMemory` delegate — the ordinary `HashJoinExec` — so the reference
    // is the real non-spill semantics, never the spill path itself.
    // ------------------------------------------------------------------

    /// Render every row of an output batch, decoding Dictionary columns to
    /// their value type ONCE per batch so a Parquet round trip that changes
    /// a column's physical encoding can never masquerade as (or hide) a
    /// cell difference.
    fn render_join_batch(batch: &RecordBatch, out: &mut Vec<Vec<String>>) {
        let decoded: Vec<ArrayRef> = batch
            .columns()
            .iter()
            .map(|c| match c.data_type() {
                arrow::datatypes::DataType::Dictionary(_, v) => {
                    compute::cast(c.as_ref(), v).unwrap()
                }
                _ => c.clone(),
            })
            .collect();
        for row in 0..batch.num_rows() {
            out.push(decoded.iter().map(|c| render_cell(c, row)).collect());
        }
    }

    /// Render every row of `batches` (Dictionary decoded, NULL as "NULL").
    fn naive_rows(batches: &[RecordBatch]) -> Vec<Vec<String>> {
        let mut out = Vec::new();
        for b in batches {
            render_join_batch(b, &mut out);
        }
        out
    }

    /// Ground truth independent of BOTH join implementations (spill-
    /// boundaries tasks 002/003 generalized the count-only oracle): plain
    /// per-row key comparison on column 0 (Dictionary decoded, NULL never
    /// matches), an optional ON-filter closure over the rendered
    /// (left row, right row) pair, NULL-extension for LEFT/RIGHT/FULL, an
    /// optional retained mask over the left ++ right columns. Output rows
    /// are left ++ right (INNER/outer) or LEFT rows (SEMI/ANTI) whatever
    /// the build orientation, sorted.
    fn naive_join_rows(
        left: &[RecordBatch],
        right: &[RecordBatch],
        join_type: JoinType,
        filter: Option<&dyn Fn(&[String], &[String]) -> bool>,
        retained: Option<&[bool]>,
    ) -> Vec<Vec<String>> {
        let l = naive_rows(left);
        let r = naive_rows(right);
        let lw = left.first().map(|b| b.num_columns()).unwrap_or(0);
        let rw = right.first().map(|b| b.num_columns()).unwrap_or(0);
        let mut by_key: HashMap<&str, Vec<usize>> = HashMap::new();
        for (i, rr) in r.iter().enumerate() {
            if rr[0] != "NULL" {
                by_key.entry(rr[0].as_str()).or_default().push(i);
            }
        }
        let nulls = |n: usize| vec!["NULL".to_string(); n];
        let pass = |lr: &[String], rr: &[String]| filter.is_none_or(|f| f(lr, rr));
        let mut out: Vec<Vec<String>> = Vec::new();
        let mut r_matched = vec![false; r.len()];
        for lr in &l {
            let mut matched = false;
            if lr[0] != "NULL" {
                if let Some(idxs) = by_key.get(lr[0].as_str()) {
                    for &ri in idxs {
                        let rr = &r[ri];
                        if !pass(lr, rr) {
                            continue;
                        }
                        matched = true;
                        r_matched[ri] = true;
                        match join_type {
                            JoinType::Semi => {
                                out.push(lr.clone());
                                break;
                            }
                            JoinType::Anti => break,
                            _ => out.push(lr.iter().chain(rr.iter()).cloned().collect()),
                        }
                    }
                }
            }
            if !matched {
                match join_type {
                    JoinType::Anti => out.push(lr.clone()),
                    JoinType::Left | JoinType::Full => {
                        out.push(lr.iter().cloned().chain(nulls(rw)).collect())
                    }
                    _ => {}
                }
            }
        }
        if matches!(join_type, JoinType::Right | JoinType::Full) {
            for (ri, m) in r_matched.iter().enumerate() {
                if !m {
                    out.push(nulls(lw).into_iter().chain(r[ri].iter().cloned()).collect());
                }
            }
        }
        if let Some(mask) = retained {
            if !matches!(join_type, JoinType::Semi | JoinType::Anti) {
                out = out
                    .into_iter()
                    .map(|row| {
                        row.into_iter()
                            .zip(mask)
                            .filter(|(_, k)| **k)
                            .map(|(c, _)| c)
                            .collect()
                    })
                    .collect();
            }
        }
        out.sort();
        out
    }

    fn naive_join_count(left: &[RecordBatch], right: &[RecordBatch], join_type: JoinType) -> usize {
        naive_join_rows(left, right, join_type, None, None).len()
    }

    /// Outcome of one `SpillableHashJoinExec` run.
    struct JoinRun {
        rows: Vec<Vec<String>>,
        spilled: bool,
        spilled_partitions: usize,
        max_spilled_build_rows: usize,
        threshold: usize,
    }

    #[allow(clippy::too_many_arguments)]
    async fn run_spillable_join(
        left: (SchemaRef, Vec<RecordBatch>),
        right: (SchemaRef, Vec<RecordBatch>),
        on: Vec<(Expr, Expr)>,
        join_type: JoinType,
        build_right: bool,
        memory_limit: usize,
        tag: &str,
    ) -> JoinRun {
        run_spillable_join_opts(
            left,
            right,
            on,
            join_type,
            build_right,
            memory_limit,
            tag,
            None,
            None,
            None,
        )
        .await
    }

    /// `run_spillable_join` with an explicit phase-B parallelism K
    /// (join-spill-streaming task 003; `None` = derived, which for these
    /// tiny-budget fixtures is K=1 since every spilled partition's table
    /// exceeds the whole threshold).
    #[allow(clippy::too_many_arguments)]
    async fn run_spillable_join_k(
        left: (SchemaRef, Vec<RecordBatch>),
        right: (SchemaRef, Vec<RecordBatch>),
        on: Vec<(Expr, Expr)>,
        join_type: JoinType,
        build_right: bool,
        memory_limit: usize,
        tag: &str,
        parallelism: Option<usize>,
    ) -> JoinRun {
        run_spillable_join_opts(
            left,
            right,
            on,
            join_type,
            build_right,
            memory_limit,
            tag,
            parallelism,
            None,
            None,
        )
        .await
    }

    /// The full runner: explicit K, an ON-clause `filter` (spill-boundaries
    /// task 002) and a `retained` mask over left ++ right (task 003).
    #[allow(clippy::too_many_arguments)]
    async fn run_spillable_join_opts(
        left: (SchemaRef, Vec<RecordBatch>),
        right: (SchemaRef, Vec<RecordBatch>),
        on: Vec<(Expr, Expr)>,
        join_type: JoinType,
        build_right: bool,
        memory_limit: usize,
        tag: &str,
        parallelism: Option<usize>,
        filter: Option<Expr>,
        retained: Option<Vec<bool>>,
    ) -> JoinRun {
        let l: Arc<dyn PhysicalOperator> = Arc::new(
            crate::physical::operators::MemoryTableExec::new("l", left.0, left.1, None),
        );
        let r: Arc<dyn PhysicalOperator> = Arc::new(
            crate::physical::operators::MemoryTableExec::new("r", right.0, right.1, None),
        );
        let pool = crate::execution::create_memory_pool(memory_limit);
        let spill_dir =
            std::env::temp_dir().join(format!("qe_sa_join_{}_{}", tag, std::process::id()));
        let _ = std::fs::remove_dir_all(&spill_dir);
        let config = ExecutionConfig::new()
            .with_memory_limit(memory_limit)
            .with_spill_path(spill_dir.clone());
        let threshold = (memory_limit as f64 * config.spill_threshold) as usize;
        let mut join = SpillableHashJoinExec::new(l, r, on, join_type, pool, config)
            .with_build_right(build_right)
            .with_spill_join_parallelism(parallelism)
            .with_filter(filter);
        join.set_retained(retained);
        let width = join.schema().fields().len();
        let mut rows = Vec::new();
        // INNER output is spread over the probe side's partitions; SEMI/
        // ANTI is single-partition; the spill path serves everything from
        // partition 0 and returns empty streams for the rest.
        for part in 0..join.output_partitions() {
            let mut stream = join.execute(part).await.unwrap();
            while let Some(b) = stream.try_next().await.unwrap() {
                assert_eq!(
                    b.num_columns(),
                    width,
                    "{tag}: output width must equal the declared output schema"
                );
                // spill-boundaries 003 follow-up: every batch the spill path
                // emits is a bounded slice (the output channel bounds batch
                // COUNT; this is what bounds its bytes).
                if memory_limit < SA_UNLIMITED && std::env::var("QE_SPILL_EMIT_ROWS").is_err() {
                    assert!(
                        b.num_rows() <= SPILL_EMIT_ROWS,
                        "{tag}: spill-path batch of {} rows exceeds SPILL_EMIT_ROWS={SPILL_EMIT_ROWS}",
                        b.num_rows()
                    );
                }
                render_join_batch(&b, &mut rows);
            }
        }
        rows.sort();
        let (spilled, spilled_partitions, max_spilled_build_rows) = match join.build_decision.get()
        {
            Some(BuildDecision::Spill(state)) => (
                true,
                state.spilled.iter().filter(|s| s.is_some()).count(),
                state
                    .spilled
                    .iter()
                    .flatten()
                    .map(|s| s.build_rows)
                    .max()
                    .unwrap_or(0),
            ),
            _ => (false, 0, 0),
        };
        drop(join);
        let _ = std::fs::remove_dir_all(&spill_dir);
        JoinRun {
            rows,
            spilled,
            spilled_partitions,
            max_spilled_build_rows,
            threshold,
        }
    }

    /// (nullable Int64 key, Utf8 payload, Int64 value) — the value column
    /// (`i % 7`, never NULL) is the non-key column the ON-filter tests
    /// compare across sides (spill-boundaries task 002).
    fn keyed_schema(key: &str, payload: &str, value: &str) -> SchemaRef {
        use arrow::datatypes::{DataType, Field, Schema};
        Arc::new(Schema::new(vec![
            Field::new(key, DataType::Int64, true),
            Field::new(payload, DataType::Utf8, false),
            Field::new(value, DataType::Int64, false),
        ]))
    }

    /// `n` rows of (nullable Int64 key, Utf8 payload, Int64 value = i % 7)
    /// in batches of `rows_per_batch`; `key_of(i)` = None produces a NULL
    /// key.
    fn keyed_batches(
        schema: &SchemaRef,
        n: i64,
        rows_per_batch: i64,
        key_of: impl Fn(i64) -> Option<i64>,
        tag: &str,
    ) -> Vec<RecordBatch> {
        let mut out = Vec::new();
        let mut start = 0i64;
        while start < n {
            let end = (start + rows_per_batch).min(n);
            let keys: Vec<Option<i64>> = (start..end).map(&key_of).collect();
            let payload: Vec<String> = (start..end).map(|i| format!("{tag}{i}")).collect();
            let values: Vec<i64> = (start..end).map(|i| i % 7).collect();
            out.push(
                RecordBatch::try_new(
                    schema.clone(),
                    vec![
                        Arc::new(Int64Array::from(keys)),
                        Arc::new(StringArray::from(payload)),
                        Arc::new(Int64Array::from(values)),
                    ],
                )
                .unwrap(),
            );
            start = end;
        }
        out
    }

    const SA_LIMIT: usize = 64 * 1024;
    const SA_UNLIMITED: usize = 1 << 40;

    /// The two build-side shapes every orientation is exercised with:
    ///   dense  — keys 0, 3, 6, ... (four passes over the same key set, so
    ///            every key's copies land in far-apart batches → after
    ///            eviction they straddle read-back CHUNKS), plus NULL keys;
    ///   sparse — 40k rows over only THREE distinct keys 6/18/4002 (all in
    ///            the dense set) plus NULLs: at most
    ///            three partitions hold any build row, so ~61 partitions
    ///            see probe rows with NO build rows at all (the ANTI
    ///            dropped-batch hazard), and each populated partition has
    ///            ~13k rows → many chunks with the same key in every one
    ///            (the SEMI double-emit hazard, maximally).
    fn build_dense(schema: &SchemaRef, tag: &str) -> Vec<RecordBatch> {
        let mut b = Vec::new();
        for pass in 0..4 {
            b.extend(keyed_batches(
                schema,
                20_000,
                1024,
                |i| if i % 89 == 0 { None } else { Some(i * 3) },
                &format!("{tag}p{pass}_"),
            ));
        }
        b
    }
    fn build_sparse(schema: &SchemaRef, tag: &str) -> Vec<RecordBatch> {
        keyed_batches(
            schema,
            40_000,
            1024,
            |i| {
                if i % 89 == 0 {
                    None
                } else {
                    Some([6i64, 18, 4_002][(i % 3) as usize])
                }
            },
            tag,
        )
    }
    /// The "other" side: keys 0..20000 with a NULL every 97th row.
    fn other_side(schema: &SchemaRef, tag: &str) -> Vec<RecordBatch> {
        keyed_batches(
            schema,
            20_000,
            1024,
            |i| if i % 97 == 0 { None } else { Some(i) },
            tag,
        )
    }

    async fn assert_semi_anti_spill_matches(
        join_type: JoinType,
        build_right: bool,
        shape: &str,
        tag: &str,
    ) {
        let ls = keyed_schema("lk", "lp", "lv");
        let rs = keyed_schema("rk", "rp", "rv");
        // The build side is the right side when `build_right`, else the left.
        let (left, right) = match (build_right, shape) {
            (true, "dense") => (other_side(&ls, "L"), build_dense(&rs, "R")),
            (true, "sparse") => (other_side(&ls, "L"), build_sparse(&rs, "R")),
            (false, "dense") => (build_dense(&ls, "L"), other_side(&rs, "R")),
            (false, "sparse") => (build_dense(&ls, "L"), build_sparse(&rs, "R")),
            _ => unreachable!(),
        };
        let on = vec![(Expr::column("lk"), Expr::column("rk"))];
        let truth = naive_join_count(&left, &right, join_type);
        let base = run_spillable_join(
            (ls.clone(), left.clone()),
            (rs.clone(), right.clone()),
            on.clone(),
            join_type,
            build_right,
            SA_UNLIMITED,
            &format!("{tag}_base"),
        )
        .await;
        assert!(
            !base.spilled,
            "{tag}: baseline must be the in-memory delegate"
        );
        let spill = run_spillable_join(
            (ls, left),
            (rs, right),
            on,
            join_type,
            build_right,
            SA_LIMIT,
            &format!("{tag}_spill"),
        )
        .await;
        assert!(
            spill.spilled,
            "{tag}: the {SA_LIMIT}-byte budget must force the spill path"
        );
        assert!(
            spill.spilled_partitions > 0,
            "{tag}: no partition was evicted to disk"
        );
        // Chunked read-back precondition: a spilled partition whose
        // predicted table exceeds the budget is read back in >1 chunk
        // (`process_spilled_partition` closes a chunk BEFORE the predicted
        // cost would cross the threshold and each Parquet row group is its
        // own batch here), which is exactly where the straddling hazards
        // live.
        assert!(
            predicted_hash_table_bytes(spill.max_spilled_build_rows, 1) > spill.threshold,
            "{tag}: largest spilled partition ({} rows) would not be chunked at threshold {}",
            spill.max_spilled_build_rows,
            spill.threshold
        );
        assert!(
            truth > 0,
            "{tag}: degenerate fixture, ground truth is empty"
        );
        assert_eq!(
            spill.rows.len(),
            truth,
            "{tag}: spill-path row count differs from the naive ground truth"
        );
        if base.rows.len() == truth {
            assert_eq!(
                base.rows, spill.rows,
                "{tag}: spill-path rows differ from in-memory"
            );
        } else {
            // The in-memory delegate (HashJoinExec, not this task's code)
            // disagrees with the ground truth — pinned as a hard assertion
            // in `in_memory_hash_join_dictionary_build_side_semi_anti_is_exact`
            // (fixed by hash-join-dictionary-semi-anti-fix task 001).
            eprintln!(
                "FINDING {tag}: in-memory HashJoinExec returned {} rows, ground truth {truth} (spill path: {})",
                base.rows.len(),
                spill.rows.len()
            );
        }
    }

    /// Probe-side output (`build_right = true`, build = right, probe = left
    /// = the output side): SEMI and ANTI, dense and sparse builds.
    #[tokio::test]
    async fn semi_anti_spill_probe_side_output_is_cell_exact() {
        assert_semi_anti_spill_matches(JoinType::Semi, true, "dense", "semi_ps_dense").await;
        assert_semi_anti_spill_matches(JoinType::Anti, true, "dense", "anti_ps_dense").await;
        assert_semi_anti_spill_matches(JoinType::Semi, true, "sparse", "semi_ps_sparse").await;
        assert_semi_anti_spill_matches(JoinType::Anti, true, "sparse", "anti_ps_sparse").await;
    }

    /// Build-side output (`build_right = false`, build = left = the output
    /// side): SEMI and ANTI. The "sparse" probe here sends probe rows to at
    /// most three partitions, so almost every build partition — resident
    /// or spilled — receives ZERO probe rows and must still be emitted in
    /// full by ANTI (and not at all by SEMI).
    #[tokio::test]
    async fn semi_anti_spill_build_side_output_is_cell_exact() {
        assert_semi_anti_spill_matches(JoinType::Semi, false, "dense", "semi_bs_dense").await;
        assert_semi_anti_spill_matches(JoinType::Anti, false, "dense", "anti_bs_dense").await;
        assert_semi_anti_spill_matches(JoinType::Semi, false, "sparse", "semi_bs_sparse").await;
        assert_semi_anti_spill_matches(JoinType::Anti, false, "sparse", "anti_bs_sparse").await;
    }

    /// Dictionary(Int32, Utf8)-encoded join keys on BOTH sides (the
    /// encoding native tables give every low-cardinality string column),
    /// through the spill round trip, in both orientations, SEMI and ANTI —
    /// and INNER, which shares the same key extraction.
    #[tokio::test]
    async fn semi_anti_spill_dictionary_keys_are_cell_exact() {
        use arrow::array::DictionaryArray;
        use arrow::datatypes::{DataType, Field, Int32Type, Schema};
        let dict_ty = DataType::Dictionary(Box::new(DataType::Int32), Box::new(DataType::Utf8));
        let ls: SchemaRef = Arc::new(Schema::new(vec![
            Field::new("lk", dict_ty.clone(), true),
            Field::new("lp", DataType::Int64, false),
        ]));
        let rs: SchemaRef = Arc::new(Schema::new(vec![
            Field::new("rk", dict_ty, true),
            Field::new("rp", DataType::Int64, false),
        ]));
        // 40 distinct string keys; the wide side repeats them many times
        // (so the build side is far above the budget) and the narrow side
        // covers half of them plus NULLs.
        fn dict_batches(
            schema: &SchemaRef,
            n: i64,
            key_of: impl Fn(i64) -> Option<String>,
        ) -> Vec<RecordBatch> {
            let mut out = Vec::new();
            let mut start = 0i64;
            while start < n {
                let end = (start + 1024).min(n);
                let dict: DictionaryArray<Int32Type> = (start..end)
                    .map(|i| key_of(i))
                    .collect::<Vec<Option<String>>>()
                    .iter()
                    .map(|o| o.as_deref())
                    .collect();
                out.push(
                    RecordBatch::try_new(
                        schema.clone(),
                        vec![
                            Arc::new(dict),
                            Arc::new(Int64Array::from((start..end).collect::<Vec<i64>>())),
                        ],
                    )
                    .unwrap(),
                );
                start = end;
            }
            out
        }
        let wide = |s: &SchemaRef| {
            dict_batches(s, 60_000, |i| {
                if i % 89 == 0 {
                    None
                } else {
                    Some(format!("key{:02}", i % 40))
                }
            })
        };
        let narrow = |s: &SchemaRef, n: i64| {
            dict_batches(s, n, |i| {
                if i % 97 == 0 {
                    None
                } else {
                    Some(format!("key{:02}", i % 20))
                }
            })
        };
        for (jt, build_right, tag) in [
            (JoinType::Semi, true, "dict_semi_ps"),
            (JoinType::Anti, true, "dict_anti_ps"),
            (JoinType::Semi, false, "dict_semi_bs"),
            (JoinType::Anti, false, "dict_anti_bs"),
            (JoinType::Inner, true, "dict_inner"),
        ] {
            // INNER emits one pair per (narrow row x 1,500 duplicates), so
            // keep its narrow side small (200 rows -> ~300k pairs).
            let n_narrow = if matches!(jt, JoinType::Inner) {
                200
            } else {
                2_000
            };
            let (left, right) = if build_right {
                (narrow(&ls, n_narrow), wide(&rs))
            } else {
                (wide(&ls), narrow(&rs, n_narrow))
            };
            let on = vec![(Expr::column("lk"), Expr::column("rk"))];
            let truth = naive_join_count(&left, &right, jt);
            let base = run_spillable_join(
                (ls.clone(), left.clone()),
                (rs.clone(), right.clone()),
                on.clone(),
                jt,
                build_right,
                SA_UNLIMITED,
                &format!("{tag}_base"),
            )
            .await;
            let spill = run_spillable_join(
                (ls.clone(), left),
                (rs.clone(), right),
                on,
                jt,
                build_right,
                SA_LIMIT,
                &format!("{tag}_spill"),
            )
            .await;
            assert!(
                !base.spilled && spill.spilled,
                "{tag}: wrong decision split"
            );
            assert!(truth > 0, "{tag}: degenerate fixture");
            assert_eq!(
                spill.rows.len(),
                truth,
                "{tag}: spill-path row count differs from the naive ground truth"
            );
            if base.rows.len() == truth {
                assert_eq!(base.rows, spill.rows, "{tag}: rows differ");
            } else {
                eprintln!(
                    "FINDING {tag}: in-memory HashJoinExec returned {} rows, ground truth {truth} (spill path: {})",
                    base.rows.len(),
                    spill.rows.len()
                );
            }
        }
    }

    /// The ON-filter shapes the spill path is exercised with (spill-
    /// boundaries task 002), each paired with the naive closure that
    /// defines it over the rendered (left row, right row):
    ///   None     — key equality alone;
    ///   Compiled — `lv < rv`, one column per side → hash_join's
    ///              `CompiledFilter` fast path (no gather);
    ///   Gathered — `lv + 1 < rv`, an arithmetic left operand → the generic
    ///              gather-and-`evaluate_expr` path.
    #[derive(Clone, Copy, Debug)]
    enum FilterKind {
        None,
        Compiled,
        Gathered,
    }

    impl FilterKind {
        fn expr(self) -> Option<Expr> {
            match self {
                FilterKind::None => None,
                FilterKind::Compiled => Some(Expr::column("lv").lt(Expr::column("rv"))),
                FilterKind::Gathered => Some(
                    Expr::column("lv")
                        .add(Expr::literal(crate::planner::ScalarValue::Int64(1)))
                        .lt(Expr::column("rv")),
                ),
            }
        }
        fn naive(self) -> Option<Box<dyn Fn(&[String], &[String]) -> bool>> {
            let v = |row: &[String]| row[2].parse::<i64>().expect("value column");
            match self {
                FilterKind::None => None,
                FilterKind::Compiled => Some(Box::new(move |l, r| v(l) < v(r))),
                FilterKind::Gathered => Some(Box::new(move |l, r| v(l) + 1 < v(r))),
            }
        }
    }

    /// One fixture through the in-memory delegate AND the spill path
    /// (tiny budget, chunked read-back guaranteed, explicit K), both
    /// compared ROW-FOR-ROW against `naive_join_rows`.
    #[allow(clippy::too_many_arguments)]
    async fn assert_join_spill_matches(
        join_type: JoinType,
        build_right: bool,
        shape: &str,
        filter: FilterKind,
        retained: Option<Vec<bool>>,
        k: Option<usize>,
        tag: &str,
    ) {
        let ls = keyed_schema("lk", "lp", "lv");
        let rs = keyed_schema("rk", "rp", "rv");
        // The build side is the right side when `build_right`, else the left
        // (RIGHT joins always build from the right, whatever the flag).
        let build_is_right = build_right || matches!(join_type, JoinType::Right);
        let (left, right) = match (build_is_right, shape) {
            (true, "dense") => (other_side(&ls, "L"), build_dense(&rs, "R")),
            (true, "sparse") => (other_side(&ls, "L"), build_sparse(&rs, "R")),
            (false, "dense") => (build_dense(&ls, "L"), other_side(&rs, "R")),
            (false, "sparse") => (build_dense(&ls, "L"), build_sparse(&rs, "R")),
            _ => unreachable!(),
        };
        let on = vec![(Expr::column("lk"), Expr::column("rk"))];
        let naive_filter = filter.naive();
        let truth = naive_join_rows(
            &left,
            &right,
            join_type,
            naive_filter.as_deref(),
            retained.as_deref(),
        );
        assert!(
            !truth.is_empty(),
            "{tag}: degenerate fixture, ground truth is empty"
        );
        let base = run_spillable_join_opts(
            (ls.clone(), left.clone()),
            (rs.clone(), right.clone()),
            on.clone(),
            join_type,
            build_right,
            SA_UNLIMITED,
            &format!("{tag}_base"),
            None,
            filter.expr(),
            retained.clone(),
        )
        .await;
        assert!(
            !base.spilled,
            "{tag}: baseline must be the in-memory delegate"
        );
        let spill = run_spillable_join_opts(
            (ls, left),
            (rs, right),
            on,
            join_type,
            build_right,
            SA_LIMIT,
            &format!("{tag}_spill"),
            k,
            filter.expr(),
            retained,
        )
        .await;
        assert!(
            spill.spilled,
            "{tag}: the {SA_LIMIT}-byte budget must force the spill path"
        );
        assert!(
            spill.spilled_partitions > 0,
            "{tag}: no partition was evicted to disk"
        );
        assert!(
            predicted_hash_table_bytes(spill.max_spilled_build_rows, 1) > spill.threshold,
            "{tag}: largest spilled partition ({} rows) would not be chunked at threshold {}",
            spill.max_spilled_build_rows,
            spill.threshold
        );
        assert_eq!(
            spill.rows.len(),
            truth.len(),
            "{tag}: spill-path row count {} differs from the naive ground truth {}",
            spill.rows.len(),
            truth.len()
        );
        assert_eq!(
            spill.rows, truth,
            "{tag}: spill-path rows differ from the naive ground truth"
        );
        assert_eq!(
            base.rows.len(),
            truth.len(),
            "{tag}: in-memory delegate row count {} differs from the naive ground truth {}",
            base.rows.len(),
            truth.len()
        );
        assert_eq!(
            base.rows, truth,
            "{tag}: in-memory delegate rows differ from the naive ground truth"
        );
    }

    /// spill-boundaries task 002: INNER with an ON-clause filter through the
    /// spill path — both build orientations, dense (chunk-straddling
    /// duplicates) and sparse, the compiled and the gathered filter paths,
    /// NULL keys on both sides.
    #[tokio::test]
    async fn filtered_inner_spill_is_cell_exact() {
        for (build_right, shape, filter) in [
            (false, "dense", FilterKind::Compiled),
            (true, "dense", FilterKind::Compiled),
            (false, "sparse", FilterKind::Compiled),
            (true, "sparse", FilterKind::Compiled),
            (false, "dense", FilterKind::Gathered),
            (true, "dense", FilterKind::Gathered),
            (true, "sparse", FilterKind::Gathered),
        ] {
            let tag = format!("finner_{build_right}_{shape}_{filter:?}");
            assert_join_spill_matches(
                JoinType::Inner,
                build_right,
                shape,
                filter,
                None,
                None,
                &tag,
            )
            .await;
        }
    }

    /// spill-boundaries task 002: SEMI/ANTI with an ON-clause filter — a
    /// candidate counts only through a pair that PASSES the filter, in both
    /// orientations (probe-side bitmap OR-accumulated across chunks; build-
    /// side per-partition / per-chunk bitmaps), dense and sparse, compiled
    /// and gathered paths.
    #[tokio::test]
    async fn filtered_semi_anti_spill_is_cell_exact() {
        for (jt, build_right, shape, filter) in [
            (JoinType::Semi, true, "dense", FilterKind::Compiled),
            (JoinType::Anti, true, "dense", FilterKind::Compiled),
            (JoinType::Semi, false, "dense", FilterKind::Compiled),
            (JoinType::Anti, false, "dense", FilterKind::Compiled),
            (JoinType::Semi, true, "sparse", FilterKind::Compiled),
            (JoinType::Anti, true, "sparse", FilterKind::Compiled),
            (JoinType::Semi, false, "sparse", FilterKind::Compiled),
            (JoinType::Anti, false, "sparse", FilterKind::Compiled),
            (JoinType::Semi, true, "dense", FilterKind::Gathered),
            (JoinType::Anti, true, "dense", FilterKind::Gathered),
            (JoinType::Semi, false, "dense", FilterKind::Gathered),
            (JoinType::Anti, false, "dense", FilterKind::Gathered),
            (JoinType::Anti, true, "sparse", FilterKind::Gathered),
            (JoinType::Anti, false, "sparse", FilterKind::Gathered),
        ] {
            let tag = format!("fsa_{jt:?}_{build_right}_{shape}_{filter:?}");
            assert_join_spill_matches(jt, build_right, shape, filter, None, None, &tag).await;
        }
    }

    /// Pre-existing spill-path bug found by this task's sparse fixtures
    /// (not SEMI/ANTI-specific): with a build side whose FIRST batch
    /// already exceeds the threshold, `build_with_partitioning` evicted
    /// the "largest" partition while all were still empty, recording a
    /// `SpilledPartition` whose file is never written when no build row
    /// later routes there; sparse keys leave ~60 such partitions and the
    /// read-back failed with "Failed to open parquet file". INNER, sparse
    /// keys, tiny budget: must complete cell-exact vs the in-memory
    /// delegate.
    #[tokio::test]
    async fn inner_spill_with_sparse_build_keys_survives_empty_partition_eviction() {
        let ls = keyed_schema("lk", "lp", "lv");
        let rs = keyed_schema("rk", "rp", "rv");
        for build_right in [true, false] {
            let (left, right) = if build_right {
                (other_side(&ls, "L"), build_sparse(&rs, "R"))
            } else {
                (build_sparse(&ls, "L"), other_side(&rs, "R"))
            };
            let truth = naive_join_count(&left, &right, JoinType::Inner);
            let on = vec![(Expr::column("lk"), Expr::column("rk"))];
            let base = run_spillable_join(
                (ls.clone(), left.clone()),
                (rs.clone(), right.clone()),
                on.clone(),
                JoinType::Inner,
                build_right,
                SA_UNLIMITED,
                &format!("inner_sparse_base_{build_right}"),
            )
            .await;
            let spill = run_spillable_join(
                (ls.clone(), left),
                (rs.clone(), right),
                on,
                JoinType::Inner,
                build_right,
                SA_LIMIT,
                &format!("inner_sparse_spill_{build_right}"),
            )
            .await;
            assert!(!base.spilled && spill.spilled, "wrong decision split");
            assert!(truth > 0, "degenerate fixture");
            assert_eq!(
                spill.rows.len(),
                truth,
                "build_right={build_right}: spill path INNER pair count differs from ground truth"
            );
            assert_eq!(
                base.rows.len(),
                truth,
                "build_right={build_right}: in-memory INNER pair count differs from ground truth"
            );
            assert_eq!(base.rows, spill.rows, "rows differ");
        }
    }

    /// join-spill-streaming task 002: build one spilling operator and
    /// return it with its spill dir, the naive INNER ground truth and the
    /// output width (fixture shared by the repeat-execution tests below).
    fn spilling_inner_join_fixture(tag: &str) -> (SpillableHashJoinExec, PathBuf, usize) {
        let ls = keyed_schema("lk", "lp", "lv");
        let rs = keyed_schema("rk", "rp", "rv");
        let (left, right) = (build_dense(&ls, "L"), other_side(&rs, "R"));
        let truth = naive_join_count(&left, &right, JoinType::Inner);
        assert!(truth > 0, "degenerate fixture");
        let l: Arc<dyn PhysicalOperator> = Arc::new(
            crate::physical::operators::MemoryTableExec::new("l", ls, left, None),
        );
        let r: Arc<dyn PhysicalOperator> = Arc::new(
            crate::physical::operators::MemoryTableExec::new("r", rs, right, None),
        );
        let pool = crate::execution::create_memory_pool(SA_LIMIT);
        let spill_dir = std::env::temp_dir().join(format!("qe_jss_{}_{}", tag, std::process::id()));
        let _ = std::fs::remove_dir_all(&spill_dir);
        let config = ExecutionConfig::new()
            .with_memory_limit(SA_LIMIT)
            .with_spill_path(spill_dir.clone());
        let join = SpillableHashJoinExec::new(
            l,
            r,
            vec![(Expr::column("lk"), Expr::column("rk"))],
            JoinType::Inner,
            pool,
            config,
        );
        (join, spill_dir, truth)
    }

    async fn drain_join(join: &SpillableHashJoinExec) -> Vec<Vec<String>> {
        let mut rows = Vec::new();
        for part in 0..join.output_partitions() {
            let mut stream = join.execute(part).await.unwrap();
            while let Some(b) = stream.try_next().await.unwrap() {
                render_join_batch(&b, &mut rows);
            }
        }
        rows.sort();
        rows
    }

    fn memoized_spill_dir(join: &SpillableHashJoinExec) -> PathBuf {
        match join.build_decision.get() {
            Some(BuildDecision::Spill(state)) => state.spill_dir.clone(),
            _ => panic!("expected a memoized Spill decision"),
        }
    }

    fn probe_files_in(dir: &Path) -> Vec<String> {
        let mut out: Vec<String> = std::fs::read_dir(dir)
            .map(|rd| {
                rd.flatten()
                    .map(|e| e.file_name().to_string_lossy().into_owned())
                    .filter(|n| n.starts_with("probe_"))
                    .collect()
            })
            .unwrap_or_default();
        out.sort();
        out
    }

    /// The output is now a stream whose producer owns a handle to the
    /// memoized build decision (join-spill-streaming task 002). An
    /// operator above may execute this join MORE THAN ONCE (the fused
    /// streaming aggregate drains, aborts, and re-executes its input):
    /// the second execution must see the same memoized build side and
    /// produce the identical result, the memoized spill directory must
    /// survive between executions, each call's probe files must be gone
    /// once its stream is fully drained, and the directory must be
    /// removed exactly once — when the operator is dropped.
    #[tokio::test]
    async fn spill_path_repeat_execution_yields_identical_results() {
        let (join, spill_dir, truth) = spilling_inner_join_fixture("repeat");
        let first = drain_join(&join).await;
        assert_eq!(
            first.len(),
            truth,
            "first execution differs from ground truth"
        );
        let memo_dir = memoized_spill_dir(&join);
        assert!(
            memo_dir.exists(),
            "memoized spill dir must survive between executions"
        );
        assert!(
            probe_files_in(&memo_dir).is_empty(),
            "a fully drained call must have removed its own probe files: {:?}",
            probe_files_in(&memo_dir)
        );
        let second = drain_join(&join).await;
        assert_eq!(first, second, "repeat execution must be identical");
        assert!(
            memo_dir.exists(),
            "memoized spill dir must still exist after the second execution"
        );
        drop(join);
        assert!(
            !memo_dir.exists(),
            "spill dir must be removed when the operator is dropped"
        );
        let _ = std::fs::remove_dir_all(&spill_dir);
    }

    /// A consumer that drops the output stream early (LIMIT satisfied, a
    /// fused aggregate aborting its attempt, an error elsewhere) must not
    /// disturb a later, full execution of the same operator: probe files
    /// are per call, so the abandoned producer and the repeat call never
    /// share a writer, and the abandoned call's files are cleaned up by
    /// its own producer.
    #[tokio::test]
    async fn spill_path_abandoned_stream_does_not_disturb_a_repeat_execution() {
        let (join, spill_dir, truth) = spilling_inner_join_fixture("abandon");
        {
            let mut stream = join.execute(0).await.unwrap();
            let first = stream.try_next().await.unwrap();
            assert!(first.is_some(), "the spilling join must produce output");
            // Drop the stream after ONE batch, with the producer mid-flight.
        }
        let full = drain_join(&join).await;
        assert_eq!(
            full.len(),
            truth,
            "execution after an abandoned stream differs from ground truth"
        );
        let memo_dir = memoized_spill_dir(&join);
        // The abandoned producer notices the closed channel at its next
        // send / probe batch and removes its own probe files; bounded wait.
        let mut leftover = probe_files_in(&memo_dir);
        for _ in 0..200 {
            if leftover.is_empty() {
                break;
            }
            tokio::time::sleep(std::time::Duration::from_millis(50)).await;
            leftover = probe_files_in(&memo_dir);
        }
        assert!(
            leftover.is_empty(),
            "probe files of an abandoned or drained call must be removed: {leftover:?}"
        );
        drop(join);
        assert!(!memo_dir.exists(), "spill dir removed on drop");
        let _ = std::fs::remove_dir_all(&spill_dir);
    }

    /// join-spill-streaming task 003: spilled partitions processed K at a
    /// time (K forced to 3 and 8 — the derived K is 1 for these fixtures,
    /// whose every spilled partition out-sizes the whole budget), chunk
    /// budget = threshold / K (so every partition is read back in MANY
    /// chunks, with the probe file re-streamed per chunk and the probe
    /// work rayon-parallel within each chunk). Every orientation and join
    /// type against the naive ground truth: INNER pair multiset, probe-side
    /// SEMI/ANTI (cross-chunk OR bitmap, final emission pass), build-side
    /// SEMI/ANTI (per-chunk atomic bitmap), dense and sparse shapes (the
    /// sparse one leaves most partitions with no probe file at all).
    #[tokio::test]
    async fn spilled_partitions_processed_in_parallel_are_cell_exact() {
        let ls = keyed_schema("lk", "lp", "lv");
        let rs = keyed_schema("rk", "rp", "rv");
        for k in [3usize, 8] {
            for (jt, build_right, shape) in [
                (JoinType::Inner, true, "dense"),
                (JoinType::Inner, false, "dense"),
                (JoinType::Inner, false, "sparse"),
                (JoinType::Semi, true, "dense"),
                (JoinType::Anti, true, "dense"),
                (JoinType::Semi, true, "sparse"),
                (JoinType::Anti, true, "sparse"),
                (JoinType::Semi, false, "dense"),
                (JoinType::Anti, false, "dense"),
                (JoinType::Semi, false, "sparse"),
                (JoinType::Anti, false, "sparse"),
            ] {
                let tag = format!("par{k}_{jt:?}_{build_right}_{shape}");
                let (left, right) = match (build_right, shape) {
                    (true, "dense") => (other_side(&ls, "L"), build_dense(&rs, "R")),
                    (true, "sparse") => (other_side(&ls, "L"), build_sparse(&rs, "R")),
                    (false, "dense") => (build_dense(&ls, "L"), other_side(&rs, "R")),
                    (false, "sparse") => (build_dense(&ls, "L"), build_sparse(&rs, "R")),
                    _ => unreachable!(),
                };
                let on = vec![(Expr::column("lk"), Expr::column("rk"))];
                let truth = naive_join_count(&left, &right, jt);
                assert!(truth > 0, "{tag}: degenerate fixture");
                let base = run_spillable_join(
                    (ls.clone(), left.clone()),
                    (rs.clone(), right.clone()),
                    on.clone(),
                    jt,
                    build_right,
                    SA_UNLIMITED,
                    &format!("{tag}_base"),
                )
                .await;
                let spill = run_spillable_join_k(
                    (ls.clone(), left),
                    (rs.clone(), right),
                    on,
                    jt,
                    build_right,
                    SA_LIMIT,
                    &format!("{tag}_spill"),
                    Some(k),
                )
                .await;
                assert!(
                    !base.spilled && spill.spilled,
                    "{tag}: wrong decision split"
                );
                // Dense shapes spill dozens of partitions (K fully
                // exercised); the sparse build has only 3 keys → ≤ 4
                // spilled partitions, so K is clamped to them (still > 1).
                let want_parallel = if shape == "dense" { k } else { 2 };
                assert!(
                    spill.spilled_partitions >= want_parallel,
                    "{tag}: only {} spilled partitions, K={k} not exercised",
                    spill.spilled_partitions
                );
                assert_eq!(
                    spill.rows.len(),
                    truth,
                    "{tag}: K={k} spill-path row count differs from the naive ground truth"
                );
                assert_eq!(
                    base.rows.len(),
                    truth,
                    "{tag}: in-memory delegate differs from the naive ground truth"
                );
                assert_eq!(base.rows, spill.rows, "{tag}: K={k} rows differ");
            }
        }
    }

    /// Regression pin (hash-join-dictionary-semi-anti-fix task 001) for a
    /// defect the spill-join-correctness-3 task-004 fixtures surfaced in the
    /// IN-MEMORY `HashJoinExec` delegate (hash_join.rs), exercised here
    /// through the wrapper's in-memory path exactly as production reaches
    /// it: SEMI/ANTI with build = LEFT (output) side, duplicate build keys
    /// encoded as Dictionary(Int32, Utf8) (60k build rows over 40 values,
    /// 2k probe rows over 20 of them). Before the fix the delegate marked
    /// exactly ONE build row per distinct matched key — SEMI emitted 20
    /// rows instead of 30,000; ANTI 59,980 (= 60,000 - 20) instead of
    /// 30,000 — because Dictionary keys could not build a
    /// `VectorizedHashTable` and the generic `probe_semi_anti_parallel`
    /// loop `break`-ed after the first marked build entry. The same
    /// fixture with plain Utf8 keys is the control (asserted too, so a
    /// failure says whether a regression is Dictionary-specific).
    /// Probe-side output (build = right) with the same Dictionary keys is
    /// covered in `semi_anti_spill_dictionary_keys_are_cell_exact`.
    /// Every count is a HARD assertion against `naive_join_count`.
    ///
    /// (An earlier draft of this test also reported an INNER
    /// duplicate-key discrepancy; that was an artifact of the test helper
    /// draining only output partition 0 of a multi-partition INNER
    /// result, fixed in `run_spillable_join` — retracted, not a bug.)
    #[tokio::test]
    async fn in_memory_hash_join_dictionary_build_side_semi_anti_is_exact() {
        use arrow::array::DictionaryArray;
        use arrow::datatypes::{DataType, Field, Int32Type, Schema};
        let mut failures: Vec<String> = Vec::new();
        let mk = |schema: &SchemaRef, n: i64, modulo: i64, dict: bool| -> Vec<RecordBatch> {
            let mut out = Vec::new();
            let mut start = 0i64;
            while start < n {
                let end = (start + 1024).min(n);
                let strings: Vec<String> = (start..end)
                    .map(|i| format!("key{:02}", i % modulo))
                    .collect();
                let key_col: ArrayRef = if dict {
                    let d: DictionaryArray<Int32Type> =
                        strings.iter().map(|s| Some(s.as_str())).collect();
                    Arc::new(d)
                } else {
                    Arc::new(StringArray::from(strings))
                };
                out.push(
                    RecordBatch::try_new(
                        schema.clone(),
                        vec![
                            key_col,
                            Arc::new(Int64Array::from((start..end).collect::<Vec<i64>>())),
                        ],
                    )
                    .unwrap(),
                );
                start = end;
            }
            out
        };
        for (dict, label) in [(true, "Dictionary(Int32,Utf8)"), (false, "Utf8")] {
            let key_ty = if dict {
                DataType::Dictionary(Box::new(DataType::Int32), Box::new(DataType::Utf8))
            } else {
                DataType::Utf8
            };
            let dls: SchemaRef = Arc::new(Schema::new(vec![
                Field::new("lk", key_ty.clone(), true),
                Field::new("lp", DataType::Int64, false),
            ]));
            let drs: SchemaRef = Arc::new(Schema::new(vec![
                Field::new("rk", key_ty, true),
                Field::new("rp", DataType::Int64, false),
            ]));
            for jt in [JoinType::Semi, JoinType::Anti] {
                let left = mk(&dls, 60_000, 40, dict);
                let right = mk(&drs, 2_000, 20, dict);
                let truth = naive_join_count(&left, &right, jt);
                let base = run_spillable_join(
                    (dls.clone(), left),
                    (drs.clone(), right),
                    vec![(Expr::column("lk"), Expr::column("rk"))],
                    jt,
                    false,
                    SA_UNLIMITED,
                    &format!("finding_{label}_{jt:?}"),
                )
                .await;
                eprintln!(
                    "FINDING-KEYS {label} {jt:?} build-side output: in-memory={} truth={truth}",
                    base.rows.len()
                );
                if base.rows.len() != truth {
                    failures.push(format!(
                        "{jt:?} {label} build-side: in-memory {} vs truth {truth}",
                        base.rows.len()
                    ));
                }
            }
        }
        assert!(
            failures.is_empty(),
            "in-memory HashJoinExec build-side SEMI/ANTI wrong counts: {failures:#?}"
        );
    }

    /// spill-boundaries task 003: LEFT/RIGHT/FULL now spill (see the
    /// `outer_join_spill_*` tests); what remains refused, by name, is
    /// CROSS/SINGLE/MARK — and the message says exactly what IS supported.
    #[tokio::test]
    async fn cross_single_mark_spill_refused_by_name() {
        let ls = keyed_schema("lk", "lp", "lv");
        let rs = keyed_schema("rk", "rp", "rv");
        for jt in [JoinType::Cross, JoinType::Single] {
            let l: Arc<dyn PhysicalOperator> =
                Arc::new(crate::physical::operators::MemoryTableExec::new(
                    "l",
                    ls.clone(),
                    build_dense(&ls, "L"),
                    None,
                ));
            let r: Arc<dyn PhysicalOperator> =
                Arc::new(crate::physical::operators::MemoryTableExec::new(
                    "r",
                    rs.clone(),
                    build_dense(&rs, "R"),
                    None,
                ));
            let pool = crate::execution::create_memory_pool(SA_LIMIT);
            let spill_dir =
                std::env::temp_dir().join(format!("qe_sa_refusal_{:?}_{}", jt, std::process::id()));
            let config = ExecutionConfig::new()
                .with_memory_limit(SA_LIMIT)
                .with_spill_path(spill_dir.clone());
            let join = SpillableHashJoinExec::new(
                l,
                r,
                vec![(Expr::column("lk"), Expr::column("rk"))],
                jt,
                pool,
                config,
            );
            let err = match join.execute(0).await {
                Err(e) => e.to_string(),
                Ok(mut s) => {
                    let mut msg = None;
                    while let Some(r) = s.next().await {
                        if let Err(e) = r {
                            msg = Some(e.to_string());
                            break;
                        }
                    }
                    msg.unwrap_or_else(|| {
                        panic!("{jt:?} join over budget must refuse, not succeed")
                    })
                }
            };
            assert!(
                err.contains("supports INNER, LEFT, RIGHT, FULL, SEMI and ANTI joins only"),
                "{jt:?}: unexpected refusal message: {err}"
            );
            drop(join);
            let _ = std::fs::remove_dir_all(&spill_dir);
        }
    }

    /// spill-boundaries task 003: LEFT/RIGHT/FULL through the spill path,
    /// row-for-row against the naive oracle — both build orientations
    /// (preserved side = probe: LEFT with build = right, RIGHT; preserved
    /// side = build: LEFT with build = left; FULL = both), dense (a key's
    /// build rows straddle read-back chunks, so a probe row unmatched in
    /// chunk 1 may match in chunk 2 and must NOT be NULL-extended early)
    /// and sparse (most partitions hold no build rows at all — every probe
    /// row there is NULL-extended; most build partitions receive no probe
    /// rows — every build row there is NULL-extended), NULL keys on both
    /// sides (never matched, always preserved).
    #[tokio::test]
    async fn outer_join_spill_is_cell_exact() {
        for (jt, build_right, shape) in [
            (JoinType::Left, false, "dense"),
            (JoinType::Left, true, "dense"),
            (JoinType::Left, false, "sparse"),
            (JoinType::Left, true, "sparse"),
            (JoinType::Right, false, "dense"),
            (JoinType::Right, false, "sparse"),
            (JoinType::Full, false, "dense"),
            (JoinType::Full, true, "dense"),
            (JoinType::Full, false, "sparse"),
            (JoinType::Full, true, "sparse"),
        ] {
            let tag = format!("outer_{jt:?}_{build_right}_{shape}");
            assert_join_spill_matches(jt, build_right, shape, FilterKind::None, None, None, &tag)
                .await;
        }
    }

    /// Task 003 + 002 together: an outer join whose ON clause carries a
    /// filter — a pair that fails the filter is NOT a match, so its
    /// preserved row is NULL-extended instead (the exact semantics a
    /// post-filter would destroy). Compiled and gathered filter paths.
    #[tokio::test]
    async fn outer_join_spill_with_on_filter_is_cell_exact() {
        for (jt, build_right, shape, filter) in [
            (JoinType::Left, false, "dense", FilterKind::Compiled),
            (JoinType::Left, true, "dense", FilterKind::Compiled),
            (JoinType::Left, false, "sparse", FilterKind::Gathered),
            (JoinType::Left, true, "sparse", FilterKind::Gathered),
            (JoinType::Right, false, "dense", FilterKind::Compiled),
            (JoinType::Right, false, "dense", FilterKind::Gathered),
            (JoinType::Full, false, "dense", FilterKind::Compiled),
            (JoinType::Full, true, "dense", FilterKind::Gathered),
            (JoinType::Full, false, "sparse", FilterKind::Compiled),
        ] {
            let tag = format!("fouter_{jt:?}_{build_right}_{shape}_{filter:?}");
            assert_join_spill_matches(jt, build_right, shape, filter, None, None, &tag).await;
        }
    }

    /// Outer joins DO carry a `retained` mask (`set_retained`'s gate): the
    /// NULL-extended rows must be pruned exactly like the matched pairs.
    /// Masks over (lk, lp, lv, rk, rp, rv): the planner's usual case drops
    /// both ON-only keys; the second mask drops the payloads too, keeping
    /// only the value columns. A column the ON filter references is always
    /// kept — `analyze_join_output_usage` force-keeps it, and the in-memory
    /// delegate prunes its build batches by the mask BEFORE evaluating the
    /// filter, so a mask dropping a filter column is unreachable by
    /// construction (and rejected: `ColumnNotFound`).
    #[tokio::test]
    async fn outer_join_spill_with_retained_mask_is_cell_exact() {
        let keys_dropped = vec![false, true, true, false, true, true];
        let keys_and_payloads_dropped = vec![false, false, true, false, false, true];
        for (jt, build_right, filter, mask) in [
            (JoinType::Left, false, FilterKind::None, &keys_dropped),
            (JoinType::Left, true, FilterKind::None, &keys_dropped),
            (JoinType::Right, false, FilterKind::None, &keys_dropped),
            (JoinType::Full, false, FilterKind::None, &keys_dropped),
            (
                JoinType::Left,
                false,
                FilterKind::Compiled,
                &keys_and_payloads_dropped,
            ),
            (JoinType::Left, true, FilterKind::Compiled, &keys_dropped),
            (
                JoinType::Full,
                true,
                FilterKind::Gathered,
                &keys_and_payloads_dropped,
            ),
        ] {
            let tag = format!("router_{jt:?}_{build_right}_{filter:?}_{}", mask.len());
            assert_join_spill_matches(
                jt,
                build_right,
                "dense",
                filter,
                Some(mask.clone()),
                None,
                &tag,
            )
            .await;
        }
    }

    /// K-way phase B (join-spill-streaming task 003) with the outer joins:
    /// every preserved-side bitmap lives with its own partition's job.
    #[tokio::test]
    async fn outer_join_spill_processed_in_parallel_is_cell_exact() {
        for (jt, build_right, shape) in [
            (JoinType::Left, false, "dense"),
            (JoinType::Left, true, "dense"),
            (JoinType::Right, false, "dense"),
            (JoinType::Full, false, "dense"),
            (JoinType::Full, true, "sparse"),
        ] {
            let tag = format!("pouter_{jt:?}_{build_right}_{shape}");
            assert_join_spill_matches(
                jt,
                build_right,
                shape,
                FilterKind::Compiled,
                None,
                Some(3),
                &tag,
            )
            .await;
        }
    }

    // ------------------------------------------------------------------
    // oom-safety-hardening task 002: streaming two-phase reservation +
    // accounted finalize for SpillableHashAggregateExec.
    // ------------------------------------------------------------------

    /// Run one SpillableHashAggregateExec over `batches` with the given
    /// memory limit; returns (sorted rows, spilled bytes recorded by the
    /// pool). Rows are (group rendered as String, per-agg i64 values).
    async fn run_agg_collect(
        batches: Vec<RecordBatch>,
        schema: SchemaRef,
        group_by: Vec<Expr>,
        aggregates: Vec<AggregateExpr>,
        out_schema: SchemaRef,
        memory_limit: usize,
        spill_tag: &str,
    ) -> (Vec<Vec<String>>, usize) {
        use futures::TryStreamExt;
        let input: Arc<dyn PhysicalOperator> = Arc::new(
            crate::physical::operators::MemoryTableExec::new("t", schema, batches, None),
        );
        let spill_path = std::env::temp_dir().join(format!(
            "qe_spillable_agg_test_{}_{}",
            spill_tag,
            std::process::id()
        ));
        let _ = std::fs::remove_dir_all(&spill_path);
        let pool = crate::execution::create_memory_pool(memory_limit);
        let config = ExecutionConfig::new()
            .with_memory_limit(memory_limit)
            .with_spill_path(spill_path.clone());
        let agg = SpillableHashAggregateExec::new(
            input,
            group_by,
            aggregates,
            out_schema,
            pool.clone(),
            config,
        );
        let mut stream = agg.execute(0).await.unwrap();
        let mut rows: Vec<Vec<String>> = Vec::new();
        while let Some(b) = stream.try_next().await.unwrap() {
            for r in 0..b.num_rows() {
                let mut row = Vec::with_capacity(b.num_columns());
                for c in b.columns() {
                    row.push(render_cell(c, r));
                }
                rows.push(row);
            }
        }
        rows.sort();
        let spilled = pool.spilled();
        let _ = std::fs::remove_dir_all(&spill_path);
        (rows, spilled)
    }

    fn render_cell(col: &ArrayRef, row: usize) -> String {
        use arrow::array::Array;
        if col.is_null(row) {
            return "NULL".to_string();
        }
        if let Some(a) = col.as_any().downcast_ref::<Int64Array>() {
            return a.value(row).to_string();
        }
        if let Some(a) = col.as_any().downcast_ref::<StringArray>() {
            return a.value(row).to_string();
        }
        if let Some(a) = col.as_any().downcast_ref::<Float64Array>() {
            return format!("{:.6}", a.value(row));
        }
        panic!("render_cell: unhandled type {:?}", col.data_type());
    }

    /// Cell-exact: a Dictionary(Int32, Utf8)-keyed GROUP BY with a DISTINCT
    /// aggregate (fused-streaming-INELIGIBLE by construction, so execution
    /// takes the streaming two-phase reservation path) must return results
    /// byte-identical to an unlimited-memory run when forced through the
    /// spill path — including the chunked (sub-partitioned) finalize, which
    /// the tiny limit's predicted-state gate necessarily trips. Covers the
    /// Dictionary spill round trip (Parquet preserves the Dictionary type
    /// via the embedded Arrow schema) and the dictionary-decoded group-hash
    /// routing staying stable across write/read-back.
    #[tokio::test]
    async fn agg_spill_dictionary_group_by_cell_exact_vs_in_memory() {
        use arrow::array::{DictionaryArray, Int32Array};
        use arrow::datatypes::{DataType, Field, Int32Type, Schema};

        let dict_type = DataType::Dictionary(Box::new(DataType::Int32), Box::new(DataType::Utf8));
        let schema = Arc::new(Schema::new(vec![
            Field::new("g", dict_type, false),
            Field::new("id", DataType::Int64, false),
            Field::new("v", DataType::Int64, false),
        ]));
        let values = StringArray::from(
            (0..40)
                .map(|i| format!("group_{:02}", i))
                .collect::<Vec<_>>(),
        );
        let mut batches = Vec::new();
        let n_batches = 24usize;
        let rows_per_batch = 8_192usize;
        for b in 0..n_batches {
            let start = (b * rows_per_batch) as i64;
            let keys = Int32Array::from(
                (0..rows_per_batch)
                    .map(|i| (i % 40) as i32)
                    .collect::<Vec<_>>(),
            );
            let dict: DictionaryArray<Int32Type> =
                DictionaryArray::try_new(keys, Arc::new(values.clone())).unwrap();
            let ids: Vec<i64> = (start..start + rows_per_batch as i64).collect();
            let vals: Vec<i64> = ids.iter().map(|i| i % 91).collect();
            batches.push(
                RecordBatch::try_new(
                    schema.clone(),
                    vec![
                        Arc::new(dict),
                        Arc::new(Int64Array::from(ids)),
                        Arc::new(Int64Array::from(vals)),
                    ],
                )
                .unwrap(),
            );
        }

        let group_by = vec![Expr::column("g")];
        let aggregates = vec![
            AggregateExpr {
                func: crate::planner::AggregateFunction::CountDistinct,
                input: Expr::column("id"),
                distinct: true,
                second_arg: None,
            },
            AggregateExpr {
                func: crate::planner::AggregateFunction::Sum,
                input: Expr::column("v"),
                distinct: false,
                second_arg: None,
            },
        ];
        let out_schema = Arc::new(Schema::new(vec![
            Field::new("g", DataType::Utf8, false),
            Field::new("cnt", DataType::Int64, true),
            Field::new("sum_v", DataType::Int64, true),
        ]));

        let (baseline, base_spilled) = run_agg_collect(
            batches.clone(),
            schema.clone(),
            group_by.clone(),
            aggregates.clone(),
            out_schema.clone(),
            8 * 1024 * 1024 * 1024,
            "dict_base",
        )
        .await;
        let (spilled_rows, spilled_bytes) = run_agg_collect(
            batches,
            schema,
            group_by,
            aggregates,
            out_schema,
            256 * 1024,
            "dict_spill",
        )
        .await;

        assert_eq!(base_spilled, 0, "unlimited run must not spill");
        assert!(
            spilled_bytes > 0,
            "256KB limit over ~4MB of input must force a spill"
        );
        assert_eq!(baseline.len(), 40, "expected exactly 40 groups");
        assert_eq!(
            baseline, spilled_rows,
            "spilled Dictionary-keyed aggregate must be byte-identical to the in-memory run"
        );
    }

    /// Cell-exact through the chunked (sub-partitioned) finalize with a
    /// plain Int64 group key: high group cardinality + COUNT(DISTINCT)
    /// makes the per-partition predicted state cross the tiny threshold,
    /// so every partition takes `aggregate_partition_chunked`; groups whose
    /// rows straddle the resident/spilled boundary AND multiple read-back
    /// batches must still aggregate exactly once each (the aggregate
    /// analogue of the join's chunk-straddling duplicate-key test).
    #[tokio::test]
    async fn agg_spill_chunked_finalize_high_cardinality_cell_exact() {
        use arrow::datatypes::{DataType, Field, Schema};

        let schema = Arc::new(Schema::new(vec![
            Field::new("g", DataType::Int64, false),
            Field::new("id", DataType::Int64, false),
            Field::new("v", DataType::Int64, false),
        ]));
        let mut batches = Vec::new();
        let n_batches = 25usize;
        let rows_per_batch = 8_192usize;
        for b in 0..n_batches {
            let start = (b * rows_per_batch) as i64;
            let ids: Vec<i64> = (start..start + rows_per_batch as i64).collect();
            let groups: Vec<i64> = ids.iter().map(|i| i % 997).collect();
            let vals: Vec<i64> = ids.iter().map(|i| i % 13).collect();
            batches.push(
                RecordBatch::try_new(
                    schema.clone(),
                    vec![
                        Arc::new(Int64Array::from(groups)),
                        Arc::new(Int64Array::from(ids)),
                        Arc::new(Int64Array::from(vals)),
                    ],
                )
                .unwrap(),
            );
        }
        let total_rows = (n_batches * rows_per_batch) as i64;

        let group_by = vec![Expr::column("g")];
        let aggregates = vec![
            AggregateExpr {
                func: crate::planner::AggregateFunction::CountDistinct,
                input: Expr::column("id"),
                distinct: true,
                second_arg: None,
            },
            AggregateExpr {
                func: crate::planner::AggregateFunction::Sum,
                input: Expr::column("v"),
                distinct: false,
                second_arg: None,
            },
        ];
        let out_schema = Arc::new(Schema::new(vec![
            Field::new("g", DataType::Int64, false),
            Field::new("cnt", DataType::Int64, true),
            Field::new("sum_v", DataType::Int64, true),
        ]));

        let (baseline, _) = run_agg_collect(
            batches.clone(),
            schema.clone(),
            group_by.clone(),
            aggregates.clone(),
            out_schema.clone(),
            8 * 1024 * 1024 * 1024,
            "chunk_base",
        )
        .await;
        let (spilled_rows, spilled_bytes) = run_agg_collect(
            batches,
            schema,
            group_by,
            aggregates,
            out_schema,
            256 * 1024,
            "chunk_spill",
        )
        .await;

        assert!(spilled_bytes > 0, "tiny limit must force a spill");
        assert_eq!(baseline.len(), 997, "expected exactly 997 groups");
        // Self-consistency: all ids are unique, so the distinct counts must
        // sum to the total row count — a duplication or loss across the
        // sub-partition boundary breaks this even if both runs drifted.
        let count_sum: i64 = baseline.iter().map(|r| r[1].parse::<i64>().unwrap()).sum();
        assert_eq!(count_sum, total_rows);
        assert_eq!(
            baseline, spilled_rows,
            "chunked-finalize aggregate must be byte-identical to the in-memory run"
        );
    }

    /// Q13 SF=100 "temp-file rename" lifecycle pin (spill-join-correctness-3
    /// task 003). Until oom-safety-hardening task 002 rewrote it, the agg
    /// spill path appended by read-rewrite-rename: `merge_parquet_files`
    /// staged `temp_{idx}_{n}.parquet` / `merged_{idx}.parquet`
    /// intermediates in the spill dir and `fs::rename`d the merged file over
    /// the partition's existing spill file on EVERY repeat eviction (the
    /// only `fs::rename` this file ever had — the join's own rename-per-
    /// append died earlier, in spill-join-correctness task 002). Between
    /// create and rename those intermediates were deletable by any other
    /// process sharing the spill root — and the default spill path was
    /// PID-less until spill-join-correctness-2 task 001, so concurrent
    /// engine processes really did share it. A colliding process's
    /// `remove_dir_all` cleanup landing inside that window produced
    /// `Failed to rename merged file: No such file or directory` — the Q13
    /// SF=100 failure the native-table-pruning epic recorded on 2026-08-27
    /// (its binaries predate BOTH fixes). The open-writer rewrite
    /// (`evict_agg_partition_to_disk` + `append_batch_streaming`) keeps one
    /// ArrowWriter per partition open for the whole ingestion phase: no
    /// merged_*/temp_* intermediate ever exists and there is no rename at
    /// all. This test pins that shape: a forced-spill aggregate runs while
    /// an adversary thread continuously deletes any `merged_*`/`temp_*`
    /// file appearing anywhere under the spill root (simulating the
    /// colliding process's cleanup); the spill must engage, the adversary
    /// must observe ZERO rename-window intermediates, and the result must
    /// be byte-identical to an unlimited-memory run.
    #[tokio::test]
    async fn agg_spill_has_no_rename_window_under_adversarial_intermediate_deletion() {
        use arrow::datatypes::{DataType, Field, Schema};
        use futures::TryStreamExt;
        use std::sync::atomic::AtomicBool;
        use std::sync::Mutex;

        let schema = Arc::new(Schema::new(vec![
            Field::new("g", DataType::Int64, false),
            Field::new("id", DataType::Int64, false),
            Field::new("v", DataType::Int64, false),
        ]));
        let mut batches = Vec::new();
        for b in 0..25usize {
            let start = (b * 8_192) as i64;
            let ids: Vec<i64> = (start..start + 8_192).collect();
            let groups: Vec<i64> = ids.iter().map(|i| i % 331).collect();
            let vals: Vec<i64> = ids.iter().map(|i| i % 17).collect();
            batches.push(
                RecordBatch::try_new(
                    schema.clone(),
                    vec![
                        Arc::new(Int64Array::from(groups)),
                        Arc::new(Int64Array::from(ids)),
                        Arc::new(Int64Array::from(vals)),
                    ],
                )
                .unwrap(),
            );
        }
        // COUNT(DISTINCT) keeps this fused-streaming-INELIGIBLE, so
        // execution must take the spillable two-phase path (the same
        // construction the dictionary/chunked-finalize tests above use).
        let group_by = vec![Expr::column("g")];
        let aggregates = vec![
            AggregateExpr {
                func: crate::planner::AggregateFunction::CountDistinct,
                input: Expr::column("id"),
                distinct: true,
                second_arg: None,
            },
            AggregateExpr {
                func: crate::planner::AggregateFunction::Sum,
                input: Expr::column("v"),
                distinct: false,
                second_arg: None,
            },
        ];
        let out_schema = Arc::new(Schema::new(vec![
            Field::new("g", DataType::Int64, false),
            Field::new("cnt", DataType::Int64, true),
            Field::new("sum_v", DataType::Int64, true),
        ]));

        let (baseline, base_spilled) = run_agg_collect(
            batches.clone(),
            schema.clone(),
            group_by.clone(),
            aggregates.clone(),
            out_schema.clone(),
            8 * 1024 * 1024 * 1024,
            "rename_window_base",
        )
        .await;
        assert_eq!(base_spilled, 0, "unlimited run must not spill");
        assert_eq!(baseline.len(), 331, "expected exactly 331 groups");

        // Forced-spill run with the adversary watching the spill root.
        let spill_path =
            std::env::temp_dir().join(format!("qe_agg_rename_window_test_{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&spill_path);
        std::fs::create_dir_all(&spill_path).unwrap();

        let stop = Arc::new(AtomicBool::new(false));
        let observed: Arc<Mutex<Vec<String>>> = Arc::new(Mutex::new(Vec::new()));
        let adversary = {
            let root = spill_path.clone();
            let stop = stop.clone();
            let observed = observed.clone();
            std::thread::spawn(move || {
                while !stop.load(Ordering::Relaxed) {
                    let mut dirs = vec![root.clone()];
                    while let Some(dir) = dirs.pop() {
                        let Ok(entries) = std::fs::read_dir(&dir) else {
                            continue;
                        };
                        for entry in entries.flatten() {
                            let path = entry.path();
                            if path.is_dir() {
                                dirs.push(path);
                                continue;
                            }
                            let name = entry.file_name();
                            let name = name.to_string_lossy();
                            if name.starts_with("merged_") || name.starts_with("temp_") {
                                observed.lock().unwrap().push(name.into_owned());
                                // The colliding process's cleanup: delete the
                                // rename-window intermediate out from under
                                // the (old) read-rewrite-rename append.
                                let _ = std::fs::remove_file(&path);
                            }
                        }
                    }
                    std::thread::sleep(std::time::Duration::from_micros(200));
                }
            })
        };

        let limit = 256 * 1024;
        let input: Arc<dyn PhysicalOperator> = Arc::new(
            crate::physical::operators::MemoryTableExec::new("t", schema, batches, None),
        );
        let pool = crate::execution::create_memory_pool(limit);
        let config = ExecutionConfig::new()
            .with_memory_limit(limit)
            .with_spill_path(spill_path.clone());
        let agg = SpillableHashAggregateExec::new(
            input,
            group_by,
            aggregates,
            out_schema,
            pool.clone(),
            config,
        );
        let mut stream = agg.execute(0).await.unwrap();
        let mut rows: Vec<Vec<String>> = Vec::new();
        while let Some(b) = stream.try_next().await.unwrap() {
            for r in 0..b.num_rows() {
                let mut row = Vec::with_capacity(b.num_columns());
                for c in b.columns() {
                    row.push(render_cell(c, r));
                }
                rows.push(row);
            }
        }
        rows.sort();
        stop.store(true, Ordering::Relaxed);
        adversary.join().unwrap();
        let spilled = pool.spilled();
        let _ = std::fs::remove_dir_all(&spill_path);

        assert!(
            spilled > 0,
            "256KB limit over ~5MB of input must force a spill"
        );
        let seen = observed.lock().unwrap();
        assert!(
            seen.is_empty(),
            "agg spill path produced rename-window intermediates (merged_*/temp_*): {:?} — \
             the read-rewrite-rename append pattern may have returned",
            &*seen
        );
        assert_eq!(
            baseline, rows,
            "adversarial deletion of merged_*/temp_* names must not affect a spilling aggregate"
        );
    }

    /// The chunked finalize's group-disjointness rests on this invariant:
    /// routing the same rows at modulus NUM_PARTITIONS (ingestion) and
    /// NUM_PARTITIONS * fan (sub-partitioning) must agree mod
    /// NUM_PARTITIONS for every row — same fixed-seed hash, coarser vs
    /// finer modulus.
    #[test]
    fn group_hash_routing_consistent_across_fanout() {
        use arrow::datatypes::{DataType, Field, Schema};
        let schema = Arc::new(Schema::new(vec![Field::new("k", DataType::Int64, false)]));
        let keys: Vec<i64> = (0..10_000).map(|i| i * 2654435761i64 % 5_000).collect();
        let batch = RecordBatch::try_new(schema, vec![Arc::new(Int64Array::from(keys))]).unwrap();
        let exprs = vec![Expr::column("k")];

        let coarse = partition_batch_by_group_hash(&batch, &exprs, NUM_PARTITIONS).unwrap();
        let mut key_to_coarse: HashMap<i64, usize> = HashMap::new();
        for (idx, piece) in coarse.iter().enumerate() {
            let Some(piece) = piece else { continue };
            let col = piece
                .column(0)
                .as_any()
                .downcast_ref::<Int64Array>()
                .unwrap();
            for r in 0..piece.num_rows() {
                key_to_coarse.insert(col.value(r), idx);
            }
        }

        let fan = 7usize;
        let fine = partition_batch_by_group_hash(&batch, &exprs, NUM_PARTITIONS * fan).unwrap();
        let mut nonempty_fine = 0usize;
        for (i, piece) in fine.iter().enumerate() {
            let Some(piece) = piece else { continue };
            nonempty_fine += 1;
            let col = piece
                .column(0)
                .as_any()
                .downcast_ref::<Int64Array>()
                .unwrap();
            for r in 0..piece.num_rows() {
                assert_eq!(
                    key_to_coarse[&col.value(r)],
                    i % NUM_PARTITIONS,
                    "fine residue must agree with coarse routing mod NUM_PARTITIONS"
                );
            }
        }
        assert!(nonempty_fine > NUM_PARTITIONS, "fanout must actually split");
    }

    /// A Dictionary-encoded group key must route by its decoded VALUE (and
    /// therefore spread across partitions), identically to the same data as
    /// plain Utf8 — not fall through `extract_join_key`'s downcast chain to
    /// a constant Null key that lands every row in one partition.
    #[test]
    fn group_hash_routing_splits_dictionary_group_keys() {
        use arrow::array::{DictionaryArray, Int32Array};
        use arrow::datatypes::{DataType, Field, Int32Type, Schema};

        let dict_type = DataType::Dictionary(Box::new(DataType::Int32), Box::new(DataType::Utf8));
        let schema = Arc::new(Schema::new(vec![Field::new("g", dict_type, false)]));
        let values = StringArray::from(
            (0..40)
                .map(|i| format!("group_{:02}", i))
                .collect::<Vec<_>>(),
        );
        let keys = Int32Array::from((0..4_000).map(|i| (i % 40) as i32).collect::<Vec<_>>());
        let dict: DictionaryArray<Int32Type> =
            DictionaryArray::try_new(keys, Arc::new(values)).unwrap();
        let batch = RecordBatch::try_new(schema, vec![Arc::new(dict)]).unwrap();
        let exprs = vec![Expr::column("g")];

        let routed = partition_batch_by_group_hash(&batch, &exprs, NUM_PARTITIONS).unwrap();
        let nonempty = routed.iter().flatten().count();
        assert!(
            nonempty > 1,
            "40 distinct dictionary values must spread across partitions, got {}",
            nonempty
        );

        // And identically to the decoded plain-Utf8 rendering of the same data.
        let plain_schema = Arc::new(Schema::new(vec![Field::new("g", DataType::Utf8, false)]));
        let plain = StringArray::from(
            (0..4_000)
                .map(|i| format!("group_{:02}", i % 40))
                .collect::<Vec<_>>(),
        );
        let plain_batch = RecordBatch::try_new(plain_schema, vec![Arc::new(plain)]).unwrap();
        let routed_plain =
            partition_batch_by_group_hash(&plain_batch, &exprs, NUM_PARTITIONS).unwrap();
        let counts: Vec<usize> = routed
            .iter()
            .map(|p| p.as_ref().map(|b| b.num_rows()).unwrap_or(0))
            .collect();
        let counts_plain: Vec<usize> = routed_plain
            .iter()
            .map(|p| p.as_ref().map(|b| b.num_rows()).unwrap_or(0))
            .collect();
        assert_eq!(
            counts, counts_plain,
            "dictionary and plain encodings of the same values must route identically"
        );
    }

    /// The aggregate-state prediction must stay conservative (per-row cost
    /// at least covers the map-entry shape) and monotonic in every input,
    /// with DISTINCT charging strictly more — mirroring
    /// `predicted_hash_table_bytes_is_conservative_for_duplicate_keys`'s
    /// role for the join prediction.
    #[test]
    fn predicted_agg_state_bytes_is_conservative_and_monotonic() {
        let base = predicted_agg_state_bytes(1_000, 1, 1, 0);
        // At minimum the map-entry bucket + one accumulator per row.
        assert!(base >= 1_000 * (HASH_TABLE_BUCKET_BYTES_AMORTIZED + AGG_ACCUMULATOR_STATE_BYTES));
        assert!(predicted_agg_state_bytes(2_000, 1, 1, 0) > base);
        assert!(predicted_agg_state_bytes(1_000, 2, 1, 0) > base);
        assert!(predicted_agg_state_bytes(1_000, 1, 2, 0) > base);
        assert!(
            predicted_agg_state_bytes(1_000, 1, 1, 1) >= base + 1_000 * AGG_DISTINCT_ENTRY_BYTES
        );
        // Zero-arg floors: a global aggregate (0 group cols) still prices
        // its single group's state per row (worst case).
        assert!(predicted_agg_state_bytes(1_000, 0, 0, 0) > 0);
    }
}
#[cfg(test)]
mod input_queue_memory_tests {
    use super::*;
    use std::sync::atomic::AtomicUsize;
    use tokio::sync::Notify;

    #[tokio::test(flavor = "current_thread")]
    async fn closed_channel_waits_for_task_completion_without_busy_waking() {
        struct WakeCount(AtomicUsize);
        impl futures::task::ArcWake for WakeCount {
            fn wake_by_ref(arc_self: &Arc<Self>) {
                arc_self.0.fetch_add(1, Ordering::SeqCst);
            }
        }
        let (tx, receiver) = tokio::sync::mpsc::channel::<QueuedInputBatch>(1);
        let (started_tx, started_rx) = tokio::sync::oneshot::channel();
        let (finish_tx, finish_rx) = tokio::sync::oneshot::channel();
        let mut producers = tokio::task::JoinSet::new();
        producers.spawn(async move {
            drop(tx);
            started_tx.send(()).unwrap();
            finish_rx.await.unwrap();
            Ok(())
        });
        started_rx.await.unwrap();
        let mut queue = InputQueueStream {
            receiver,
            producers,
            label: "completion test queue",
            finished: false,
            pending_error: None,
            envelope: None,
            _queue_metadata: None,
        };
        let wakes = Arc::new(WakeCount(AtomicUsize::new(0)));
        let waker = futures::task::waker(wakes.clone());
        let mut cx = std::task::Context::from_waker(&waker);
        assert!(futures::Stream::poll_next(std::pin::Pin::new(&mut queue), &mut cx).is_pending());
        assert_eq!(wakes.0.load(Ordering::SeqCst), 0);
        finish_tx.send(()).unwrap();
        assert!(queue.try_next().await.unwrap().is_none());
    }

    #[test]
    fn fixed_width_scan_target_fits_actual_nullable_decimal_copy_layout() {
        use arrow::array::Decimal128Array;
        use arrow::datatypes::{DataType, Field, Schema};
        let schema = Arc::new(Schema::new(vec![
            Field::new("key", DataType::Int64, true),
            Field::new("amount", DataType::Decimal128(20, 2), true),
        ]));
        let rows = input_queue_fixed_width_row_limit(&schema, 8192, 4096).unwrap();
        assert!(rows > 1 && rows < 8192);
        let keys: ArrayRef = Arc::new(Int64Array::from_iter((0..rows).map(|i| {
            if i % 2 == 0 {
                Some(i as i64)
            } else {
                None
            }
        })));
        let values: ArrayRef = Arc::new(
            Decimal128Array::from_iter((0..rows).map(|i| {
                if i % 3 == 0 {
                    None
                } else {
                    Some(-(i as i128))
                }
            }))
            .with_precision_and_scale(20, 2)
            .unwrap(),
        );
        let batch = RecordBatch::try_new(schema.clone(), vec![keys, values]).unwrap();
        assert!(owned_input_batch_charge(&batch).unwrap() <= 4096);
        assert_eq!(own_input_batch(batch.clone()).unwrap(), batch);
        assert_eq!(
            input_queue_fixed_width_row_limit(&schema, 17, 1 << 20),
            Some(17)
        );
        assert_eq!(
            input_queue_fixed_width_row_limit(&schema, usize::MAX, 4096),
            Some(rows)
        );
        assert_eq!(input_queue_fixed_width_row_limit(&schema, 8192, 1), None);
    }

    #[test]
    fn scan_row_target_does_not_invent_variable_width_bounds() {
        use arrow::datatypes::{DataType, Field, Schema};
        let schema = Arc::new(Schema::new(vec![Field::new("text", DataType::Utf8, true)]));
        assert_eq!(input_queue_fixed_width_row_limit(&schema, 8192, 8192), None);
        let schema = batch(1).schema();
        let rows = input_queue_fixed_width_row_limit(&schema, 8192, 8192).unwrap();
        assert!(rows < 1171);
        let actual =
            RecordBatch::try_new(schema, vec![Arc::new(Int64Array::from(vec![1; rows]))]).unwrap();
        assert!(owned_input_batch_charge(&actual).unwrap() <= 8192);
    }

    #[derive(Debug, Default)]
    struct Progress {
        started: AtomicUsize,
        dropped: AtomicUsize,
        produced: AtomicUsize,
        parked: AtomicUsize,
        changed: Notify,
    }
    struct DropMark(Arc<Progress>);
    impl Drop for DropMark {
        fn drop(&mut self) {
            self.0.dropped.fetch_add(1, Ordering::SeqCst);
            self.0.changed.notify_one();
        }
    }
    #[derive(Clone, Debug)]
    enum Tail {
        End,
        Error,
        Panic,
        Park,
    }
    #[derive(Debug)]
    struct MockInput {
        partitions: Vec<(Vec<RecordBatch>, Tail)>,
        progress: Arc<Progress>,
        executed: Arc<AtomicUsize>,
    }
    #[async_trait]
    impl PhysicalOperator for MockInput {
        fn schema(&self) -> SchemaRef {
            batch(0).schema()
        }
        fn children(&self) -> Vec<Arc<dyn PhysicalOperator>> {
            vec![]
        }
        fn output_partitions(&self) -> usize {
            self.partitions.len()
        }
        fn name(&self) -> &str {
            "queue mock"
        }
        async fn execute(&self, partition: usize) -> Result<RecordBatchStream> {
            self.executed.fetch_add(1, Ordering::SeqCst);
            crate::physical::check_partition(self, partition)?;
            let (batches, tail) = self.partitions[partition].clone();
            let progress = self.progress.clone();
            let mark = DropMark(progress.clone());
            progress.started.fetch_add(1, Ordering::SeqCst);
            progress.changed.notify_one();
            Ok(Box::pin(stream::try_unfold(
                (batches.into_iter(), tail, mark),
                move |(mut batches, tail, mark)| {
                    let progress = progress.clone();
                    async move {
                        if let Some(batch) = batches.next() {
                            progress.produced.fetch_add(1, Ordering::SeqCst);
                            progress.changed.notify_one();
                            return Ok(Some((batch, (batches, tail, mark))));
                        }
                        match tail {
                            Tail::End => Ok(None),
                            Tail::Error => Err(QueryError::Execution("mock upstream error".into())),
                            Tail::Panic => panic!("mock producer panic"),
                            Tail::Park => {
                                progress.parked.fetch_add(1, Ordering::SeqCst);
                                progress.changed.notify_one();
                                std::future::pending().await
                            }
                        }
                    }
                },
            )))
        }
    }
    fn batch(v: i64) -> RecordBatch {
        RecordBatch::try_from_iter(vec![("v", Arc::new(Int64Array::from(vec![v])) as ArrayRef)])
            .unwrap()
    }
    fn input(
        partitions: Vec<(Vec<RecordBatch>, Tail)>,
    ) -> (Arc<dyn PhysicalOperator>, Arc<Progress>, Arc<AtomicUsize>) {
        let progress = Arc::new(Progress::default());
        let executed = Arc::new(AtomicUsize::new(0));
        (
            Arc::new(MockInput {
                partitions,
                progress: progress.clone(),
                executed: executed.clone(),
            }),
            progress,
            executed,
        )
    }
    async fn wait_count(progress: &Progress, counter: &AtomicUsize, count: usize) {
        // Timeout is only a deadlock guard, not a latency assertion. The
        // acknowledgement proves that Tokio actually destroyed the producer.
        tokio::time::timeout(std::time::Duration::from_secs(10), async {
            loop {
                let notified = progress.changed.notified();
                if counter.load(Ordering::SeqCst) >= count {
                    return;
                }
                notified.await;
            }
        })
        .await
        .expect("producer progress/cancellation acknowledgement timed out");
    }
    fn assert_pool_refusal(
        error: &QueryError,
        name: &str,
        requested: usize,
        used: usize,
        limit: usize,
    ) {
        let QueryError::MemoryLimit {
            pool,
            requested: actual_requested,
            used: actual_used,
            limit: actual_limit,
        } = error.root()
        else {
            panic!("unexpected refusal: {error}");
        };
        assert_eq!(pool, name);
        assert_eq!(
            (*actual_requested, *actual_used, *actual_limit),
            (requested, used, limit)
        );
        assert_eq!(error.to_string(), format!("Execution error: Memory limit exceeded in '{name}': requested {requested} additional bytes, used {used}, limit {limit}"));
    }
    fn pool(bytes: usize) -> SharedMemoryPool {
        Arc::new(crate::execution::MemoryPool::new_named("test query", bytes))
    }

    #[derive(Debug)]
    struct BoundedInput {
        input: Arc<dyn PhysicalOperator>,
        bound: crate::physical::queue_layout::QueueCopyBound,
        release: Option<Arc<tokio::sync::Semaphore>>,
        progress: Arc<Progress>,
    }
    #[async_trait]
    impl PhysicalOperator for BoundedInput {
        fn schema(&self) -> SchemaRef {
            self.input.schema()
        }
        fn children(&self) -> Vec<Arc<dyn PhysicalOperator>> {
            vec![]
        }
        fn name(&self) -> &str {
            "bounded queue fixture"
        }
        fn output_partitions(&self) -> usize {
            self.input.output_partitions()
        }
        fn resident_queue_copy_bound(
            &self,
        ) -> Option<crate::physical::queue_layout::QueueCopyBound> {
            Some(self.bound.clone())
        }
        async fn execute(&self, partition: usize) -> Result<RecordBatchStream> {
            crate::physical::check_partition(self, partition)?;
            let stream = self.input.execute(partition).await?;
            let release = self.release.clone();
            let progress = self.progress.clone();
            Ok(Box::pin(stream.and_then(move |batch| {
                let release = release.clone();
                let progress = progress.clone();
                async move {
                    if let Some(release) = release {
                        progress.parked.fetch_add(1, Ordering::SeqCst);
                        progress.changed.notify_one();
                        release.acquire().await.unwrap().forget();
                    }
                    Ok(batch)
                }
            })))
        }
    }
    fn bounded_input(
        partitions: Vec<(Vec<RecordBatch>, Tail)>,
        release: Option<Arc<tokio::sync::Semaphore>>,
    ) -> (Arc<dyn PhysicalOperator>, Arc<Progress>, usize) {
        let expected = batch(7);
        let bound = crate::physical::queue_layout::QueueCopyBound::from_batches(
            &expected.schema(),
            &[expected],
        )
        .unwrap();
        let bytes = bound.max_bytes().unwrap();
        let (input, progress, _) = input(partitions);
        (
            Arc::new(BoundedInput {
                input,
                bound,
                release,
                progress: progress.clone(),
            }),
            progress,
            bytes,
        )
    }
    fn bounded_queue(
        input: &Arc<dyn PhysicalOperator>,
        pool: &SharedMemoryPool,
    ) -> RecordBatchStream {
        // Use an explicit two-worker scheduling context so a caller's global
        // RAYON_NUM_THREADS=1 does not disable this concurrency contract test.
        let runtime = tokio::runtime::Handle::current();
        rayon::ThreadPoolBuilder::new()
            .num_threads(2)
            .build()
            .unwrap()
            .install(|| {
                let _entered = runtime.enter();
                futures::executor::block_on(stream_merge_input_partitions(
                    input,
                    pool,
                    "bounded queue",
                ))
                .unwrap()
            })
    }

    #[tokio::test(flavor = "current_thread")]
    async fn raw_fixed_width_queue_uses_general_bound_and_two_reserved_slots() {
        use crate::physical::operators::StreamingParquetScanExec;
        use arrow::array::Int64Array;
        let directory = tempfile::tempdir().unwrap();
        let path = directory.path().join("raw-input.parquet");
        let schema = Arc::new(arrow::datatypes::Schema::new(vec![
            arrow::datatypes::Field::new("id", arrow::datatypes::DataType::Int64, false),
        ]));
        let source = RecordBatch::try_new(
            schema.clone(),
            vec![Arc::new(Int64Array::from_iter_values(0..95))],
        )
        .unwrap();
        let properties = parquet::file::properties::WriterProperties::builder()
            .set_max_row_group_row_count(Some(23))
            .build();
        let mut writer = ArrowWriter::try_new(
            File::create(&path).unwrap(),
            schema.clone(),
            Some(properties),
        )
        .unwrap();
        writer.write(&source).unwrap();
        writer.close().unwrap();
        let input: Arc<dyn PhysicalOperator> = Arc::new(
            rayon::ThreadPoolBuilder::new()
                .num_threads(3)
                .build()
                .unwrap()
                .install(|| {
                    StreamingParquetScanExec::try_new_with_batch_size(
                        "raw",
                        &[path],
                        schema.clone(),
                        None,
                        None,
                        &schema,
                        17,
                        true,
                    )
                    .unwrap()
                }),
        );
        assert_eq!(input.output_partitions(), 3);
        assert!(input.resident_queue_copy_bound().is_none());
        assert!(input.resident_gather_copy_bound().is_none());
        let bytes = input
            .pool_independent_queue_copy_bound()
            .unwrap()
            .max_bytes()
            .unwrap();
        assert!(input.pool_independent_gather_copy_bound().is_some());
        let pool = pool(bytes.checked_mul(2).unwrap());
        let mut queue = bounded_queue(&input, &pool);
        // This current-thread runtime has not yielded to producers. The exact
        // two-slot envelope must already be reserved BEFORE any upstream pull.
        // Using only the resident getter produces zero here and fails directly.
        assert_eq!(pool.used(), bytes * 2);
        assert_eq!(pool.reserved_peak(), bytes * 2);
        let mut ids = Vec::new();
        while let Some(batch) = queue.try_next().await.unwrap() {
            assert!(batch.num_rows() <= 17);
            let array = batch
                .column(0)
                .as_any()
                .downcast_ref::<Int64Array>()
                .unwrap();
            ids.extend(
                array
                    .iter()
                    .map(|value| value.expect("source id is non-NULL")),
            );
        }
        ids.sort_unstable();
        assert_eq!(ids, (0..95).collect::<Vec<i64>>());
        drop(queue);
        tokio::time::timeout(std::time::Duration::from_secs(10), async {
            while pool.used() != 0 {
                tokio::task::yield_now().await;
            }
        })
        .await
        .expect("raw queue producer reservation cleanup stalled");
        assert_eq!(pool.used(), 0);
        assert_eq!(pool.reserved_peak(), bytes * 2);
    }

    #[tokio::test(flavor = "current_thread")]
    async fn admitted_parallel_slots_overlap_upstream_polls_and_bound_queued_copies() {
        let release = Arc::new(tokio::sync::Semaphore::new(0));
        let (input, progress, bytes) = bounded_input(
            vec![
                (vec![batch(7), batch(8)], Tail::End),
                (vec![batch(9), batch(10)], Tail::End),
            ],
            Some(release.clone()),
        );
        let pool = pool(bytes * 2);
        INPUT_QUEUE_COPY_ATTEMPTS.with(|count| count.set(0));
        let mut queue = bounded_queue(&input, &pool);
        // Both upstream polls must enter before either is released. Serial
        // demand fails this barrier deterministically, not on a speed threshold.
        wait_count(&progress, &progress.parked, 2).await;
        assert_eq!(pool.used(), bytes * 2);
        assert_eq!(progress.produced.load(Ordering::SeqCst), 2);
        release.add_permits(4);
        tokio::time::timeout(std::time::Duration::from_secs(10), async {
            while INPUT_QUEUE_COPY_ATTEMPTS.with(|count| count.get()) < 2 {
                tokio::task::yield_now().await;
            }
        })
        .await
        .expect("both admitted copies must become queued");
        // Each fixture has one buffer. Both copies now exist without a
        // consumer handoff, and neither producer may pull its second batch.
        assert_eq!(progress.produced.load(Ordering::SeqCst), 2);
        assert_eq!(pool.used(), bytes * 2);
        let mut values = vec![];
        while let Some(batch) = queue.try_next().await.unwrap() {
            values.push(
                batch
                    .column(0)
                    .as_any()
                    .downcast_ref::<Int64Array>()
                    .unwrap()
                    .value(0),
            );
        }
        values.sort_unstable();
        assert_eq!(values, [7, 8, 9, 10]);
        assert_eq!(pool.reserved_peak(), bytes * 2);
        assert_eq!(pool.used(), 0);
    }

    #[tokio::test(flavor = "current_thread")]
    async fn bounded_envelope_denial_falls_back_without_prefetch_or_budget_wait() {
        let (input, progress, bytes) = bounded_input(
            vec![
                (vec![batch(7), batch(8)], Tail::End),
                (vec![batch(9)], Tail::End),
            ],
            None,
        );
        let pool = pool(bytes * 3 - 1);
        let sibling = pool.allocate(bytes).unwrap();
        let mut queue = bounded_queue(&input, &pool);
        wait_count(&progress, &progress.produced, 1).await;
        assert_eq!(progress.produced.load(Ordering::SeqCst), 1);
        let mut count = 0;
        while let Some(batch) = queue.try_next().await.unwrap() {
            count += batch.num_rows();
        }
        assert_eq!(count, 3);
        assert_eq!(pool.used(), bytes);
        drop(sibling);
        assert_eq!(pool.used(), 0);
        assert!(pool.reserved_peak() <= pool.max());
    }

    #[tokio::test(flavor = "current_thread")]
    async fn parallel_envelope_survives_until_parked_producers_are_cancelled() {
        let release = Arc::new(tokio::sync::Semaphore::new(0));
        let (input, progress, bytes) = bounded_input(
            vec![(vec![batch(7)], Tail::End), (vec![batch(8)], Tail::End)],
            Some(release),
        );
        let pool = pool(bytes * 2);
        let queue = bounded_queue(&input, &pool);
        wait_count(&progress, &progress.parked, 2).await;
        drop(queue);
        // This current-thread runtime cannot service abort until we yield.
        assert_eq!(pool.used(), bytes * 2);
        wait_count(&progress, &progress.dropped, 2).await;
        assert_eq!(pool.used(), 0);
    }

    #[tokio::test(flavor = "current_thread")]
    async fn lying_resident_bound_fails_before_copy_and_releases_envelope() {
        let large = RecordBatch::try_from_iter(vec![(
            "v",
            Arc::new(Int64Array::from(vec![7; 4096])) as ArrayRef,
        )])
        .unwrap();
        let (input, progress, bytes) =
            bounded_input(vec![(vec![large], Tail::End), (vec![], Tail::Park)], None);
        let pool = pool(bytes * 2);
        INPUT_QUEUE_COPY_ATTEMPTS.with(|count| count.set(0));
        let mut queue = bounded_queue(&input, &pool);
        let error = queue.try_next().await.unwrap_err();
        assert!(
            error.to_string().contains("copy-bound contract violated"),
            "{error}"
        );
        INPUT_QUEUE_COPY_ATTEMPTS.with(|count| assert_eq!(count.get(), 0));
        drop(queue);
        // Both execute futures start before polling tasks in the current test
        // setup, but cancellation can prevent an unstarted producer entirely.
        tokio::task::yield_now().await;
        assert_eq!(pool.used(), 0);
        assert!(progress.dropped.load(Ordering::SeqCst) >= 1);
    }

    #[derive(Debug)]
    struct PreparedBounded {
        input: Arc<dyn PhysicalOperator>,
        preparations: Arc<AtomicUsize>,
    }
    #[async_trait]
    impl PhysicalOperator for PreparedBounded {
        fn name(&self) -> &str {
            "prepared bounded only"
        }
        fn schema(&self) -> SchemaRef {
            self.input.schema()
        }
        fn children(&self) -> Vec<Arc<dyn PhysicalOperator>> {
            vec![]
        }
        fn output_partitions(&self) -> usize {
            self.input.output_partitions()
        }
        async fn execute(&self, _: usize) -> Result<RecordBatchStream> {
            panic!("prepared wrapper reexecuted source")
        }
        async fn prepare_queue_input(&self) -> Result<Option<crate::physical::PreparedQueueInput>> {
            self.preparations.fetch_add(1, Ordering::SeqCst);
            let bound = self.input.resident_queue_copy_bound().unwrap();
            let mut streams = Vec::new();
            for partition in 0..self.input.output_partitions() {
                streams.push(self.input.execute(partition).await?);
            }
            Ok(Some(crate::physical::PreparedQueueInput {
                streams,
                output: crate::physical::PreparedOutputBound::Layouts(
                    crate::physical::queue_layout::PreparedOutputLayouts::from_bound(bound)
                        .unwrap(),
                ),
            }))
        }
    }
    fn prepared_wrapped_input(
        predicate_error: bool,
        release: Arc<tokio::sync::Semaphore>,
    ) -> (
        Arc<dyn PhysicalOperator>,
        Arc<Progress>,
        Arc<AtomicUsize>,
        usize,
    ) {
        let (input, progress, _) = bounded_input(
            vec![
                (vec![batch(7), batch(8)], Tail::End),
                (vec![batch(9), batch(10)], Tail::End),
            ],
            Some(release),
        );
        let name = input.schema().field(0).name().clone();
        let schema = Arc::new(Schema::new(vec![arrow::datatypes::Field::new(
            "alias",
            arrow::datatypes::DataType::Int64,
            true,
        )]));
        let bound = input
            .resident_queue_copy_bound()
            .unwrap()
            .filtered()
            .unwrap()
            .projected(&[Expr::column(name.clone()).alias("alias")], &schema)
            .unwrap()
            .max_bytes()
            .unwrap();
        let preparations = Arc::new(AtomicUsize::new(0));
        let source = Arc::new(PreparedBounded {
            input,
            preparations: preparations.clone(),
        });
        let predicate = if predicate_error {
            Expr::column("missing_runtime_column")
        } else {
            Expr::literal(crate::planner::ScalarValue::Boolean(true))
        };
        let filter = Arc::new(crate::physical::FilterExec::new(source, predicate));
        let project = Arc::new(crate::physical::ProjectExec::new(
            filter,
            vec![Expr::column(name).alias("alias")],
            schema,
        ));
        (project, progress, preparations, bound)
    }
    #[tokio::test(flavor = "current_thread")]
    async fn prepared_wrappers_overlap_pulls_and_hold_two_copies_without_consumer() {
        let release = Arc::new(tokio::sync::Semaphore::new(0));
        let (input, progress, preparations, bytes) = prepared_wrapped_input(false, release.clone());
        let pool = pool(2 * bytes);
        INPUT_QUEUE_COPY_ATTEMPTS.with(|c| c.set(0));
        let mut queue = bounded_queue(&input, &pool);
        assert_eq!(progress.produced.load(Ordering::SeqCst), 0);
        wait_count(&progress, &progress.parked, 2).await;
        assert_eq!(preparations.load(Ordering::SeqCst), 1);
        assert_eq!(pool.used(), 2 * bytes);
        release.add_permits(4);
        tokio::time::timeout(std::time::Duration::from_secs(10), async {
            while INPUT_QUEUE_COPY_ATTEMPTS.with(|c| c.get()) < 2 {
                tokio::task::yield_now().await;
            }
        })
        .await
        .expect("two wrapped copies not queued");
        assert_eq!(progress.produced.load(Ordering::SeqCst), 2);
        let mut values = Vec::new();
        while let Some(batch) = queue.try_next().await.unwrap() {
            values.push(
                batch
                    .column(0)
                    .as_any()
                    .downcast_ref::<Int64Array>()
                    .unwrap()
                    .value(0),
            );
        }
        values.sort_unstable();
        assert_eq!(values, [7, 8, 9, 10]);
        assert_eq!(pool.used(), 0);
        assert_eq!(pool.reserved_peak(), 2 * bytes);
        assert_eq!(preparations.load(Ordering::SeqCst), 1);
    }
    #[tokio::test(flavor = "current_thread")]
    async fn prepared_wrapper_runtime_predicate_error_cancels_parked_sibling() {
        let release = Arc::new(tokio::sync::Semaphore::new(0));
        let (input, progress, preparations, bytes) = prepared_wrapped_input(true, release.clone());
        let pool = pool(2 * bytes);
        let mut queue = bounded_queue(&input, &pool);
        wait_count(&progress, &progress.parked, 2).await;
        release.add_permits(1);
        let error = queue.try_next().await.unwrap_err();
        assert!(
            error.to_string().contains("missing_runtime_column"),
            "{error}"
        );
        wait_count(&progress, &progress.dropped, 2).await;
        assert_eq!(pool.used(), 0);
        assert_eq!(preparations.load(Ordering::SeqCst), 1);
        assert_eq!(progress.produced.load(Ordering::SeqCst), 2);
        assert!(queue.try_next().await.unwrap().is_none());
    }
    #[tokio::test(flavor = "current_thread")]
    async fn prepared_wrapper_consumer_drop_cancels_both_parked_streams() {
        let release = Arc::new(tokio::sync::Semaphore::new(0));
        let (input, progress, preparations, bytes) = prepared_wrapped_input(false, release);
        let pool = pool(2 * bytes);
        let queue = bounded_queue(&input, &pool);
        wait_count(&progress, &progress.parked, 2).await;
        drop(queue);
        wait_count(&progress, &progress.dropped, 2).await;
        assert_eq!(pool.used(), 0);
        assert_eq!(preparations.load(Ordering::SeqCst), 1);
        assert_eq!(progress.produced.load(Ordering::SeqCst), 2);
    }

    #[derive(Debug)]
    struct PreparedFixture {
        pool: SharedMemoryPool,
        layout: bool,
        bound: crate::physical::queue_layout::QueueCopyBound,
        declared: usize,
        supplied: usize,
        ordinary_calls: Arc<AtomicUsize>,
        pulls: Arc<AtomicUsize>,
        preparations: Arc<AtomicUsize>,
    }
    #[async_trait]
    impl PhysicalOperator for PreparedFixture {
        fn schema(&self) -> SchemaRef {
            batch(7).schema()
        }
        fn children(&self) -> Vec<Arc<dyn PhysicalOperator>> {
            vec![]
        }
        fn output_partitions(&self) -> usize {
            self.declared
        }
        fn name(&self) -> &str {
            "prepared fixture"
        }
        async fn execute(&self, _: usize) -> Result<RecordBatchStream> {
            self.ordinary_calls.fetch_add(1, Ordering::SeqCst);
            Err(QueryError::Execution(
                "prepared stream executed twice".into(),
            ))
        }
        async fn prepare_queue_input(
            &self,
        ) -> Result<Option<crate::physical::plan::PreparedQueueInput>> {
            self.preparations.fetch_add(1, Ordering::SeqCst);
            // Initialization requires the complete available pool. Reserving an
            // outer output envelope before this phase would make it fail.
            let initialization = self.pool.allocate(self.pool.max())?;
            let streams = (0..self.supplied)
                .map(|partition| {
                    let pulls = self.pulls.clone();
                    Box::pin(stream::once(async move {
                        pulls.fetch_add(1, Ordering::SeqCst);
                        Ok(batch(partition as i64))
                    })) as RecordBatchStream
                })
                .collect();
            assert_eq!(self.pulls.load(Ordering::SeqCst), 0);
            drop(initialization);
            Ok(Some(crate::physical::plan::PreparedQueueInput {
                streams,
                output: if self.layout {
                    crate::physical::PreparedOutputBound::Layouts(
                        crate::physical::queue_layout::PreparedOutputLayouts::from_bound(
                            self.bound.clone(),
                        )
                        .unwrap(),
                    )
                } else {
                    crate::physical::PreparedOutputBound::Bytes(self.bound.max_bytes().unwrap())
                },
            }))
        }
    }
    fn prepared_fixture(limit_multiplier: usize, supplied: usize) -> Arc<PreparedFixture> {
        let expected = batch(7);
        let bound = crate::physical::queue_layout::QueueCopyBound::from_batches(
            &expected.schema(),
            &[expected],
        )
        .unwrap();
        Arc::new(PreparedFixture {
            pool: pool(bound.max_bytes().unwrap() * limit_multiplier),
            layout: false,
            bound,
            declared: 2,
            supplied,
            ordinary_calls: Arc::new(AtomicUsize::new(0)),
            pulls: Arc::new(AtomicUsize::new(0)),
            preparations: Arc::new(AtomicUsize::new(0)),
        })
    }
    #[tokio::test(flavor = "current_thread")]
    async fn prepared_streams_initialize_before_admission_and_fallback_executes_once() {
        for slots in [1, 2] {
            let fixture = prepared_fixture(slots, 2);
            let input: Arc<dyn PhysicalOperator> = fixture.clone();
            let mut queue = bounded_queue(&input, &fixture.pool);
            assert_eq!(fixture.pulls.load(Ordering::SeqCst), 0);
            assert_eq!(fixture.preparations.load(Ordering::SeqCst), 1);
            let mut values = vec![];
            while let Some(batch) = queue.try_next().await.unwrap() {
                values.push(
                    batch
                        .column(0)
                        .as_any()
                        .downcast_ref::<Int64Array>()
                        .unwrap()
                        .value(0),
                );
            }
            values.sort_unstable();
            assert_eq!(values, [0, 1]);
            assert_eq!(fixture.ordinary_calls.load(Ordering::SeqCst), 0);
            assert_eq!(fixture.pulls.load(Ordering::SeqCst), 2);
            assert_eq!(fixture.pool.used(), 0);
            assert!(fixture.pool.reserved_peak() <= fixture.pool.max());
        }
    }
    #[tokio::test(flavor = "current_thread")]
    async fn prepared_filter_layout_retains_parallel_envelope() {
        let mut fixture = prepared_fixture(4, 2);
        Arc::get_mut(&mut fixture).unwrap().layout = true;
        let transformed = fixture.bound.filtered().unwrap().max_bytes().unwrap();
        let input: Arc<dyn PhysicalOperator> = Arc::new(crate::physical::FilterExec::new(
            fixture.clone(),
            Expr::literal(crate::planner::ScalarValue::Boolean(true)),
        ));
        let mut queue = bounded_queue(&input, &fixture.pool);
        assert_eq!(fixture.pool.used(), 2 * transformed);
        assert_eq!(fixture.pulls.load(Ordering::SeqCst), 0);
        let mut values = Vec::new();
        while let Some(batch) = queue.try_next().await.unwrap() {
            values.push(
                batch
                    .column(0)
                    .as_any()
                    .downcast_ref::<Int64Array>()
                    .unwrap()
                    .value(0),
            );
        }
        values.sort_unstable();
        assert_eq!(values, [0, 1]);
        assert_eq!(fixture.ordinary_calls.load(Ordering::SeqCst), 0);
        assert_eq!(fixture.pool.used(), 0);
    }

    #[tokio::test(flavor = "current_thread")]
    async fn prepared_filter_unknown_keeps_streams_in_serial_queue() {
        let fixture = prepared_fixture(2, 2);
        // Byte-only certificates cannot prove Filter's new bitmap layout.
        let input: Arc<dyn PhysicalOperator> = Arc::new(crate::physical::FilterExec::new(
            fixture.clone(),
            Expr::literal(crate::planner::ScalarValue::Boolean(true)),
        ));
        let mut queue = bounded_queue(&input, &fixture.pool);
        assert_eq!(fixture.preparations.load(Ordering::SeqCst), 1);
        assert_eq!(fixture.pulls.load(Ordering::SeqCst), 0);
        assert_eq!(
            fixture.pool.used(),
            0,
            "unknown transformed layout must not reserve an envelope"
        );
        let mut values = Vec::new();
        while let Some(batch) = queue.try_next().await.unwrap() {
            values.push(
                batch
                    .column(0)
                    .as_any()
                    .downcast_ref::<Int64Array>()
                    .unwrap()
                    .value(0),
            );
        }
        values.sort_unstable();
        assert_eq!(values, [0, 1]);
        assert_eq!(fixture.ordinary_calls.load(Ordering::SeqCst), 0);
        assert_eq!(fixture.pulls.load(Ordering::SeqCst), 2);
        assert_eq!(fixture.pool.used(), 0);
    }

    #[tokio::test(flavor = "current_thread")]
    async fn prepared_project_unknown_keeps_streams_and_computed_preflight_declines() {
        let fixture = prepared_fixture(3, 2);
        let name = fixture.schema().field(0).name().clone();
        let input: Arc<dyn PhysicalOperator> = Arc::new(crate::physical::ProjectExec::new(
            fixture.clone(),
            vec![Expr::column(name).alias("renamed")],
            Arc::new(Schema::new(vec![arrow::datatypes::Field::new(
                "renamed",
                arrow::datatypes::DataType::Int64,
                true,
            )])),
        ));
        let mut queue = bounded_queue(&input, &fixture.pool);
        assert_eq!(fixture.preparations.load(Ordering::SeqCst), 1);
        assert_eq!(fixture.pool.used(), 0);
        let mut values = Vec::new();
        while let Some(batch) = queue.try_next().await.unwrap() {
            values.push(
                batch
                    .column(0)
                    .as_any()
                    .downcast_ref::<Int64Array>()
                    .unwrap()
                    .value(0),
            );
        }
        values.sort_unstable();
        assert_eq!(values, [0, 1]);
        assert_eq!(fixture.ordinary_calls.load(Ordering::SeqCst), 0);
        let other = prepared_fixture(2, 2);
        let computed = crate::physical::ProjectExec::new(
            other.clone(),
            vec![Expr::literal(crate::planner::ScalarValue::Int64(1))],
            other.schema(),
        );
        assert!(computed.prepare_queue_input().await.unwrap().is_none());
        assert_eq!(other.preparations.load(Ordering::SeqCst), 0);
    }

    #[tokio::test(flavor = "current_thread")]
    async fn prepared_filter_subquery_declines_before_any_child_initialization() {
        let fixture = prepared_fixture(2, 2);
        let predicate = Expr::Exists {
            subquery: Arc::new(crate::planner::LogicalPlan::EmptyRelation(
                crate::planner::EmptyRelationNode {
                    produce_one_row: true,
                    schema: crate::planner::PlanSchema::empty(),
                },
            )),
            negated: false,
        };
        let filter = crate::physical::FilterExec::new(fixture.clone(), predicate);
        assert!(filter.prepare_queue_input().await.unwrap().is_none());
        assert_eq!(fixture.preparations.load(Ordering::SeqCst), 0);
        assert_eq!(fixture.ordinary_calls.load(Ordering::SeqCst), 0);
        assert_eq!(fixture.pulls.load(Ordering::SeqCst), 0);
        assert_eq!(fixture.pool.used(), 0);
    }

    #[tokio::test(flavor = "current_thread")]
    async fn prepared_partition_mismatch_fails_before_output_pulls() {
        for supplied in [1, 3] {
            let fixture = prepared_fixture(2, supplied);
            let input: Arc<dyn PhysicalOperator> = fixture.clone();
            let result =
                stream_merge_input_partitions(&input, &fixture.pool, "prepared test").await;
            let error = match result {
                Err(error) => error,
                Ok(_) => panic!("invalid prepared partitions accepted"),
            };
            assert!(error
                .to_string()
                .contains("prepared partition contract violated"));
            assert_eq!(fixture.pulls.load(Ordering::SeqCst), 0);
            assert_eq!(fixture.ordinary_calls.load(Ordering::SeqCst), 0);
            assert_eq!(fixture.pool.used(), 0);
        }
    }
    #[tokio::test(flavor = "current_thread")]
    async fn zero_partitions_skip_preparation_entirely() {
        let mut fixture = prepared_fixture(2, 0);
        Arc::get_mut(&mut fixture).unwrap().declared = 0;
        let input: Arc<dyn PhysicalOperator> = fixture.clone();
        let mut queue = stream_merge_input_partitions(&input, &fixture.pool, "zero prepared")
            .await
            .unwrap();
        assert!(queue.try_next().await.unwrap().is_none());
        assert_eq!(fixture.preparations.load(Ordering::SeqCst), 0);
        assert_eq!(fixture.ordinary_calls.load(Ordering::SeqCst), 0);
    }

    #[derive(Debug)]
    struct ExternalOwner(Vec<u128>);

    fn external_buffer(
        buffer: &arrow::buffer::Buffer,
        owners: &mut Vec<std::sync::Weak<ExternalOwner>>,
    ) -> arrow::buffer::Buffer {
        let mut words = vec![0u128; 4096.max((buffer.len() + 15) / 16)];
        for (word, chunk) in words.iter_mut().zip(buffer.as_slice().chunks(16)) {
            let mut bytes = [0; 16];
            bytes[..chunk.len()].copy_from_slice(chunk);
            *word = u128::from_ne_bytes(bytes);
        }
        let owner = Arc::new(ExternalOwner(words));
        owners.push(Arc::downgrade(&owner));
        let ptr = std::ptr::NonNull::new(owner.0.as_ptr() as *mut u8).unwrap();
        // SAFETY: the aligned, immutable Vec is retained by this exact owner.
        // Its allocation exceeds the exposed extent; no mutation occurs.
        unsafe { arrow::buffer::Buffer::from_custom_allocation(ptr, buffer.len(), owner) }
    }

    fn external_data(
        data: arrow::array::ArrayData,
        owners: &mut Vec<std::sync::Weak<ExternalOwner>>,
    ) -> arrow::array::ArrayData {
        let buffers = data
            .buffers()
            .iter()
            .map(|b| external_buffer(b, owners))
            .collect();
        let children = data
            .child_data()
            .iter()
            .map(|d| external_data(d.clone(), owners))
            .collect();
        let nulls = data.nulls().map(|n| {
            arrow::buffer::NullBuffer::new(arrow::buffer::BooleanBuffer::new(
                external_buffer(n.buffer(), owners),
                n.inner().offset(),
                n.len(),
            ))
        });
        data.into_builder()
            .buffers(buffers)
            .child_data(children)
            .nulls(nulls)
            .build()
            .unwrap()
    }

    #[tokio::test(flavor = "current_thread")]
    async fn external_owners_are_detached_with_exact_decimal_dictionary_and_null_values() {
        use arrow::array::{Array, Decimal128Array, Decimal256Array, DictionaryArray, Int32Array};
        use arrow::datatypes::{i256, Int32Type};
        let d128: ArrayRef = Arc::new(
            Decimal128Array::from(vec![Some(999), None, Some(-123)])
                .with_precision_and_scale(20, 2)
                .unwrap(),
        );
        let d256: ArrayRef = Arc::new(
            Decimal256Array::from(vec![
                Some(i256::from_i128(999)),
                Some(i256::from_i128(-456)),
                None,
            ])
            .with_precision_and_scale(50, 4)
            .unwrap(),
        );
        let dictionary: ArrayRef = Arc::new(
            DictionaryArray::<Int32Type>::try_new(
                Int32Array::from(vec![Some(0), Some(1), Some(2)]),
                Arc::new(StringArray::from(vec![
                    Some("discard"),
                    None,
                    Some("retained"),
                ])),
            )
            .unwrap(),
        );
        let expected =
            RecordBatch::try_from_iter(vec![("d128", d128), ("d256", d256), ("dict", dictionary)])
                .unwrap()
                .slice(1, 2);
        let mut owners = vec![];
        let columns = expected
            .columns()
            .iter()
            .map(|a| arrow::array::make_array(external_data(a.to_data(), &mut owners)))
            .collect();
        let external = RecordBatch::try_new(expected.schema(), columns).unwrap();
        assert!(owners.iter().all(|w| w.upgrade().is_some()));
        let bytes = owned_input_batch_charge(&external).unwrap();
        let pool = pool(bytes * 2);
        let (input, progress, _) = input(vec![(vec![external], Tail::End), (vec![], Tail::End)]);
        let mut queue = stream_merge_input_partitions(&input, &pool, "external queue")
            .await
            .unwrap();
        wait_count(&progress, &progress.started, 2).await;
        wait_count(&progress, &progress.produced, 1).await;
        drop(input);
        // Queued data itself must no longer pin ANY large external owner.
        assert!(owners.iter().all(|w| w.upgrade().is_none()));
        assert_eq!(pool.used(), bytes);
        let actual = queue.try_next().await.unwrap().unwrap();
        assert_eq!(actual, expected);
        assert_eq!(
            actual
                .column(0)
                .as_any()
                .downcast_ref::<Decimal128Array>()
                .unwrap()
                .iter()
                .collect::<Vec<_>>(),
            vec![None, Some(-123)]
        );
        assert_eq!(
            actual
                .column(1)
                .as_any()
                .downcast_ref::<Decimal256Array>()
                .unwrap()
                .iter()
                .collect::<Vec<_>>(),
            vec![Some(i256::from_i128(-456)), None]
        );
        let decoded =
            arrow::compute::cast(actual.column(2), &arrow::datatypes::DataType::Utf8).unwrap();
        assert_eq!(
            decoded
                .as_any()
                .downcast_ref::<StringArray>()
                .unwrap()
                .iter()
                .collect::<Vec<_>>(),
            vec![None, Some("retained")]
        );
        assert!(queue.try_next().await.unwrap().is_none());
        assert_eq!(pool.used(), 0);
    }

    #[tokio::test(flavor = "current_thread")]
    async fn external_copy_is_not_attempted_before_budget_admission() {
        let mut owners = vec![];
        let expected = batch(7);
        let external = RecordBatch::try_from_iter(vec![(
            "v",
            arrow::array::make_array(external_data(expected.column(0).to_data(), &mut owners)),
        )])
        .unwrap();
        let bytes = owned_input_batch_charge(&external).unwrap();
        let pool = pool(bytes - 1);
        let before = INPUT_QUEUE_COPY_ATTEMPTS.with(|count| count.get());
        let (input, progress, _) = input(vec![(vec![external], Tail::End), (vec![], Tail::End)]);
        let mut queue = stream_merge_input_partitions(&input, &pool, "copy budget queue")
            .await
            .unwrap();
        wait_count(&progress, &progress.started, 2).await;
        assert_pool_refusal(
            &queue.try_next().await.unwrap_err(),
            "copy budget queue",
            bytes,
            0,
            bytes - 1,
        );
        assert_eq!(INPUT_QUEUE_COPY_ATTEMPTS.with(|count| count.get()), before);
        drop(queue);
        wait_count(&progress, &progress.dropped, 2).await;
        drop(input);
        assert!(owners.iter().all(|w| w.upgrade().is_none()));
        assert_eq!(pool.used(), 0);
    }
    #[derive(Debug)]
    struct ImpossiblePartitions(usize);
    #[async_trait]
    impl PhysicalOperator for ImpossiblePartitions {
        fn schema(&self) -> SchemaRef {
            batch(0).schema()
        }
        fn children(&self) -> Vec<Arc<dyn PhysicalOperator>> {
            vec![]
        }
        fn output_partitions(&self) -> usize {
            self.0
        }
        fn name(&self) -> &str {
            "impossible partitions"
        }
        async fn execute(&self, _: usize) -> Result<RecordBatchStream> {
            panic!("capacity refusal must happen before any execute");
        }
    }
    #[tokio::test(flavor = "current_thread")]
    async fn capacity_overflow_and_runtime_limit_refuse_before_execution() {
        for (count, expected) in [
            (usize::MAX, "capacity overflow"),
            (
                tokio::sync::Semaphore::MAX_PERMITS / 4 + 1,
                "capacity exceeds runtime limit",
            ),
        ] {
            let input: Arc<dyn PhysicalOperator> = Arc::new(ImpossiblePartitions(count));
            let result = stream_merge_input_partitions(&input, &pool(1024), "capacity queue").await;
            let error = match result {
                Err(error) => error,
                Ok(_) => panic!("invalid queue capacity accepted"),
            };
            assert!(error.to_string().contains(expected), "{error}");
        }
    }

    #[tokio::test(flavor = "current_thread")]
    async fn sliced_copy_layout_is_refused_before_enqueue() {
        let large = RecordBatch::try_from_iter(vec![(
            "v",
            Arc::new(Int64Array::from(vec![7; 8192])) as ArrayRef,
        )])
        .unwrap();
        let sliced = large.slice(0, 1);
        let bytes = owned_input_batch_charge(&sliced).unwrap();
        assert!(
            bytes < 8192 * 8,
            "copy detaches the large original allocation"
        );
        let pool = pool(bytes - 1);
        let (input, progress, _) = input(vec![(vec![sliced], Tail::End), (vec![], Tail::End)]);
        let mut stream = stream_merge_input_partitions(&input, &pool, "slice test queue")
            .await
            .unwrap();
        wait_count(&progress, &progress.started, 2).await;
        let error = stream.try_next().await.unwrap_err();
        assert_pool_refusal(&error, "slice test queue", bytes, 0, bytes - 1);
        assert!(stream.try_next().await.unwrap().is_none());
        drop(stream);
        wait_count(&progress, &progress.dropped, 2).await;
        assert_eq!(pool.used(), 0);
    }

    #[tokio::test(flavor = "current_thread")]
    async fn sibling_queues_and_held_owner_share_admission() {
        let bytes = owned_input_batch_charge(&batch(7)).unwrap();
        let pool = pool(bytes * 2 - 1);
        let (first, progress, _) = input(vec![(vec![batch(7)], Tail::End), (vec![], Tail::End)]);
        let first_queue = stream_merge_input_partitions(&first, &pool, "first queue")
            .await
            .unwrap();
        wait_count(&progress, &progress.started, 2).await;
        wait_count(&progress, &progress.produced, 1).await;
        assert_eq!(pool.used(), bytes);
        let (second, _, _) = input(vec![(vec![batch(8)], Tail::End), (vec![], Tail::End)]);
        let mut second_queue = stream_merge_input_partitions(&second, &pool, "second queue")
            .await
            .unwrap();
        assert_pool_refusal(
            &second_queue.try_next().await.unwrap_err(),
            "test query",
            bytes,
            bytes,
            bytes * 2 - 1,
        );
        drop(second_queue);
        drop(first_queue);
        assert_eq!(pool.used(), 0);
        // This is a held owned guard, not a claim of DenseAccumulators execution.
        let owner = pool.allocate(bytes).unwrap();
        let mut denied = stream_merge_input_partitions(&second, &pool, "held owner queue")
            .await
            .unwrap();
        assert_pool_refusal(
            &denied.try_next().await.unwrap_err(),
            "test query",
            bytes,
            bytes,
            bytes * 2 - 1,
        );
        drop(denied);
        drop(owner);
        let mut accepted = stream_merge_input_partitions(&second, &pool, "released owner queue")
            .await
            .unwrap();
        assert_eq!(accepted.try_next().await.unwrap().unwrap().num_rows(), 1);
        assert!(accepted.try_next().await.unwrap().is_none());
        assert_eq!(pool.used(), 0);
        assert!(pool.reserved_peak() <= pool.max());
    }

    #[tokio::test(flavor = "current_thread")]
    async fn drop_cancels_pre_poll_backpressure_and_parked_upstream() {
        let bytes = owned_input_batch_charge(&batch(1)).unwrap();
        let pool = pool(bytes * 32);
        let (input, progress, _) = input(vec![
            (vec![batch(1); 10], Tail::Park),
            (vec![batch(1); 10], Tail::Park),
        ]);
        let queue = stream_merge_input_partitions(&input, &pool, "drop queue")
            .await
            .unwrap();
        // One batch owns demand. Other producers must await demand BEFORE
        // polling another upstream batch, even though channel capacity is eight.
        wait_count(&progress, &progress.started, 2).await;
        wait_count(&progress, &progress.produced, 1).await;
        assert_eq!(progress.produced.load(Ordering::SeqCst), 1);
        assert_eq!(pool.used(), bytes);
        drop(queue);
        wait_count(&progress, &progress.dropped, 2).await;
        assert_eq!(pool.used(), 0);
        assert_eq!(progress.produced.load(Ordering::SeqCst), 1);
    }

    #[tokio::test(flavor = "current_thread")]
    async fn low_budget_delivers_all_partitions_without_prefetch_refusal() {
        let bytes = owned_input_batch_charge(&batch(7)).unwrap();
        let pool = pool(bytes * 2 - 1);
        let (input, progress, executed) = input(vec![
            (vec![batch(7), batch(7)], Tail::End),
            (vec![], Tail::End),
            (vec![batch(8), batch(9)], Tail::End),
        ]);
        let mut queue = stream_merge_input_partitions(&input, &pool, "one batch queue")
            .await
            .unwrap();
        wait_count(&progress, &progress.started, 3).await;
        wait_count(&progress, &progress.produced, 1).await;
        assert_eq!(progress.produced.load(Ordering::SeqCst), 1);
        assert_eq!(pool.used(), bytes);
        let mut values = Vec::new();
        while let Some(batch) = queue.try_next().await.unwrap() {
            values.extend(
                batch
                    .column(0)
                    .as_any()
                    .downcast_ref::<Int64Array>()
                    .unwrap()
                    .values()
                    .iter()
                    .copied(),
            );
        }
        values.sort_unstable();
        assert_eq!(values, [7, 7, 8, 9]);
        assert_eq!(executed.load(Ordering::SeqCst), 3);
        assert_eq!(pool.reserved_peak(), bytes);
        assert_eq!(pool.used(), 0);
    }

    #[tokio::test(flavor = "current_thread")]
    async fn dropping_queue_cancels_upstream_holding_demand_forever() {
        let pool = pool(4096);
        let (input, progress, _) = input(vec![(vec![], Tail::Park), (vec![], Tail::Park)]);
        let queue = stream_merge_input_partitions(&input, &pool, "parked queue")
            .await
            .unwrap();
        wait_count(&progress, &progress.started, 2).await;
        wait_count(&progress, &progress.parked, 1).await;
        assert_eq!(progress.produced.load(Ordering::SeqCst), 0);
        drop(queue);
        wait_count(&progress, &progress.dropped, 2).await;
        assert_eq!(pool.used(), 0);
    }

    #[tokio::test(flavor = "current_thread")]
    async fn all_partitions_duplicates_empty_and_direct_bypass() {
        let pool = pool(1 << 20);
        let (input, _, executed) = input(vec![
            (vec![batch(1), batch(1)], Tail::End),
            (vec![], Tail::End),
            (vec![batch(2)], Tail::End),
        ]);
        let batches: Vec<_> = stream_merge_input_partitions(&input, &pool, "all queue")
            .await
            .unwrap()
            .try_collect()
            .await
            .unwrap();
        let mut ids: Vec<_> = batches
            .iter()
            .map(|b| {
                b.column(0)
                    .as_any()
                    .downcast_ref::<Int64Array>()
                    .unwrap()
                    .value(0)
            })
            .collect();
        ids.sort_unstable();
        assert_eq!(ids, [1, 1, 2]);
        assert_eq!(executed.load(Ordering::SeqCst), 3);
        assert_eq!(pool.used(), 0);
        let (empty, _, executed) = self::input(vec![]);
        assert!(stream_merge_input_partitions(&empty, &pool, "zero queue")
            .await
            .unwrap()
            .try_next()
            .await
            .unwrap()
            .is_none());
        assert_eq!(executed.load(Ordering::SeqCst), 0);
        let (single, _, _) = self::input(vec![(vec![batch(3)], Tail::End)]);
        let no_budget = self::pool(0);
        assert!(
            stream_merge_input_partitions(&single, &no_budget, "direct queue")
                .await
                .unwrap()
                .try_next()
                .await
                .unwrap()
                .is_some()
        );
        assert_eq!(no_budget.reserved_peak(), 0);
    }

    #[tokio::test(flavor = "current_thread")]
    async fn upstream_error_and_task_panic_are_terminal_not_partial_success() {
        for tail in [Tail::Error, Tail::Panic] {
            let is_panic = matches!(tail, Tail::Panic);
            let pool = pool(1 << 20);
            let (input, progress, _) = input(vec![(vec![batch(1)], tail), (vec![], Tail::Park)]);
            let mut queue = stream_merge_input_partitions(&input, &pool, "failure queue")
                .await
                .unwrap();
            wait_count(&progress, &progress.started, 2).await;
            let error = loop {
                match queue.try_next().await {
                    Ok(Some(_)) => continue,
                    Ok(None) => panic!("producer failure became successful end-of-stream"),
                    Err(error) => break error.to_string(),
                }
            };
            assert!(
                error.contains(if is_panic {
                    "producer task failed"
                } else {
                    "mock upstream error"
                }),
                "{error}"
            );
            assert!(queue.try_next().await.unwrap().is_none());
            drop(queue);
            wait_count(&progress, &progress.dropped, 2).await;
            assert_eq!(pool.used(), 0);
        }
    }
}

#[cfg(test)]
mod join_spill_init_ownership_tests {
    use super::*;
    use crate::physical::operators::MemoryTableExec;
    use std::time::Duration;
    use tokio::sync::oneshot;

    fn fixture(root: &std::path::Path) -> (Arc<SpillableHashJoinExec>, Vec<RecordBatch>) {
        let batch = RecordBatch::try_from_iter(vec![(
            "k",
            Arc::new(arrow::array::Int64Array::from(vec![1; 1024])) as ArrayRef,
        )])
        .unwrap();
        let input = Arc::new(MemoryTableExec::new("init", batch.schema(), vec![], None));
        let op = Arc::new(SpillableHashJoinExec::new(
            input.clone(),
            input,
            vec![(Expr::column("k"), Expr::column("k"))],
            JoinType::Inner,
            crate::execution::create_memory_pool(1024),
            ExecutionConfig::new()
                .with_memory_limit(1024)
                .with_spill_path(root.to_path_buf()),
        ));
        (op, vec![batch.clone(), batch])
    }
    fn only_directory(root: &std::path::Path) -> PathBuf {
        let entries = std::fs::read_dir(root)
            .unwrap()
            .map(|e| e.unwrap().path())
            .collect::<Vec<_>>();
        assert_eq!(entries.len(), 1);
        assert!(entries[0].is_dir());
        entries[0].clone()
    }
    #[tokio::test]
    async fn build_stream_error_removes_incomplete_directory_and_files() {
        let root = tempfile::tempdir().unwrap();
        let (op, prefix) = fixture(root.path());
        let root_path = root.path().to_path_buf();
        let rest = Box::pin(stream::once(async move {
            let directory = only_directory(&root_path);
            assert!(
                std::fs::read_dir(directory).unwrap().next().is_some(),
                "real spill writer must exist before failure"
            );
            Err(QueryError::Execution("injected build stream error".into()))
        }));
        let result = op
            .finish_via_spill(prefix, rest, &[Expr::column("k")], false)
            .await;
        assert!(
            matches!(result, Err(QueryError::Execution(message)) if message == "injected build stream error")
        );
        assert_eq!(std::fs::read_dir(root.path()).unwrap().count(), 0);
    }
    #[tokio::test]
    async fn cancellation_drops_writer_before_initialization_directory() {
        let root = tempfile::tempdir().unwrap();
        let (op, prefix) = fixture(root.path());
        let root_path = root.path().to_path_buf();
        let (started, ready) = oneshot::channel();
        let rest = Box::pin(stream::once(async move {
            let directory = only_directory(&root_path);
            assert!(std::fs::read_dir(directory).unwrap().next().is_some());
            started.send(()).unwrap();
            futures::future::pending::<Result<RecordBatch>>().await
        }));
        let task = tokio::spawn(async move {
            op.finish_via_spill(prefix, rest, &[Expr::column("k")], false)
                .await
        });
        tokio::time::timeout(Duration::from_secs(10), ready)
            .await
            .unwrap()
            .unwrap();
        task.abort();
        match task.await {
            Err(error) => assert!(error.is_cancelled()),
            Ok(_) => panic!("initializer completed before cancellation"),
        }
        assert_eq!(std::fs::read_dir(root.path()).unwrap().count(), 0);
    }
    #[tokio::test]
    async fn successful_initialization_transfers_cleanup_to_last_spill_state_owner() {
        let root = tempfile::tempdir().unwrap();
        let (op, prefix) = fixture(root.path());
        let decision = op
            .finish_via_spill(
                prefix,
                Box::pin(stream::empty()),
                &[Expr::column("k")],
                false,
            )
            .await
            .unwrap();
        let state = match decision {
            BuildDecision::Spill(state) => state,
            _ => panic!("expected spill"),
        };
        let directory = state.spill_dir.clone();
        assert!(state.spilled.iter().any(Option::is_some));
        assert!(directory.exists());
        let retained = state.clone();
        drop(state);
        drop(op);
        assert!(directory.exists());
        drop(retained);
        assert!(!directory.exists());
    }
    #[test]
    fn initialization_never_adopts_an_existing_directory() {
        let root = tempfile::tempdir().unwrap();
        let directory = root.path().join("already_owned");
        std::fs::create_dir(&directory).unwrap();
        let sentinel = directory.join("sentinel");
        std::fs::write(&sentinel, b"owned elsewhere").unwrap();
        assert!(SpillDirectoryOwner::create(directory).is_err());
        assert_eq!(std::fs::read(sentinel).unwrap(), b"owned elsewhere");
    }
}

#[cfg(test)]
mod agg_sort_directory_ownership_tests {
    use super::*;
    use crate::planner::SortExpr;
    use std::time::Duration;
    use tokio::sync::Semaphore;
    #[derive(Clone, Copy, Debug)]
    enum Tail {
        Error,
        Pending,
        End,
    }
    #[derive(Debug)]
    struct Source {
        batch: RecordBatch,
        root: PathBuf,
        tail: Tail,
        reached: Arc<Semaphore>,
    }
    #[async_trait::async_trait]
    impl PhysicalOperator for Source {
        fn schema(&self) -> SchemaRef {
            self.batch.schema()
        }
        fn children(&self) -> Vec<Arc<dyn PhysicalOperator>> {
            vec![]
        }
        fn name(&self) -> &str {
            "SpillDirectoryFailureSource"
        }
        async fn execute(&self, partition: usize) -> Result<RecordBatchStream> {
            crate::physical::check_partition(self, partition)?;
            let root = self.root.clone();
            let tail = self.tail;
            let reached = self.reached.clone();
            let suffix = stream::once(async move {
                let paths = std::fs::read_dir(root)
                    .unwrap()
                    .map(|entry| entry.unwrap().path())
                    .collect::<Vec<_>>();
                assert_eq!(
                    paths.len(),
                    1,
                    "operator must have entered spill initialization"
                );
                assert!(
                    std::fs::read_dir(&paths[0]).unwrap().next().is_some(),
                    "real spill files must precede injected outcome"
                );
                reached.add_permits(1);
                match tail {
                    Tail::Error => Some(Err(QueryError::Execution(
                        "injected ingestion failure".into(),
                    ))),
                    Tail::Pending => {
                        futures::future::pending::<Option<Result<RecordBatch>>>().await
                    }
                    Tail::End => None,
                }
            })
            .filter_map(futures::future::ready);
            Ok(Box::pin(
                stream::iter(vec![Ok(self.batch.clone()), Ok(self.batch.clone())]).chain(suffix),
            ))
        }
    }
    fn operator(
        root: &std::path::Path,
        sort: bool,
        tail: Tail,
    ) -> (Arc<dyn PhysicalOperator>, Arc<Semaphore>, SharedMemoryPool) {
        let batch = RecordBatch::try_from_iter(vec![(
            "id",
            Arc::new(arrow::array::Int64Array::from_iter_values((0..1024).rev())) as ArrayRef,
        )])
        .unwrap();
        let reached = Arc::new(Semaphore::new(0));
        let input = Arc::new(Source {
            batch,
            root: root.to_path_buf(),
            tail,
            reached: reached.clone(),
        });
        let pool = crate::execution::create_memory_pool(4096);
        let config = ExecutionConfig::new()
            .with_memory_limit(4096)
            .with_spill_path(root.to_path_buf());
        let op: Arc<dyn PhysicalOperator> = if sort {
            Arc::new(ExternalSortExec::new(
                input,
                vec![SortExpr::new(Expr::column("id")).asc()],
                pool.clone(),
                config,
            ))
        } else {
            Arc::new(SpillableHashAggregateExec::new(
                input,
                vec![],
                vec![AggregateExpr {
                    func: crate::planner::AggregateFunction::Count,
                    input: Expr::column("id"),
                    distinct: false,
                    second_arg: None,
                }],
                Arc::new(arrow::datatypes::Schema::new(vec![
                    arrow::datatypes::Field::new("count", arrow::datatypes::DataType::Int64, true),
                ])),
                pool.clone(),
                config,
            ))
        };
        (op, reached, pool)
    }
    #[tokio::test]
    async fn aggregate_and_sort_error_remove_real_ingestion_files() {
        for sort in [false, true] {
            let root = tempfile::tempdir().unwrap();
            let (op, reached, _) = operator(root.path(), sort, Tail::Error);
            let result = op.execute(0).await;
            assert!(
                matches!(result,Err(QueryError::Execution(message)) if message=="injected ingestion failure")
            );
            assert_eq!(reached.available_permits(), 1);
            assert_eq!(std::fs::read_dir(root.path()).unwrap().count(), 0);
        }
    }
    #[tokio::test]
    async fn aggregate_and_sort_cancel_remove_real_ingestion_files() {
        for sort in [false, true] {
            let root = tempfile::tempdir().unwrap();
            let (op, reached, _) = operator(root.path(), sort, Tail::Pending);
            let task = tokio::spawn(async move { op.execute(0).await });
            tokio::time::timeout(Duration::from_secs(10), reached.acquire())
                .await
                .unwrap()
                .unwrap()
                .forget();
            task.abort();
            match task.await {
                Err(error) => assert!(error.is_cancelled()),
                Ok(_) => panic!("parked initialization completed"),
            }
            assert_eq!(std::fs::read_dir(root.path()).unwrap().count(), 0);
        }
    }
    #[tokio::test]
    async fn top_k_spill_remains_successful_and_releases_merge_files() {
        let root = tempfile::tempdir().unwrap();
        let (full, _, pool) = operator(root.path(), true, Tail::End);
        let input = full.children()[0].clone();
        drop(full);
        let sort = ExternalSortExec::with_fetch(
            input,
            vec![SortExpr::new(Expr::column("id")).asc()],
            pool.clone(),
            ExecutionConfig::new()
                .with_memory_limit(4096)
                .with_spill_path(root.path().to_path_buf()),
            3,
        );
        let mut output = sort.execute(0).await.unwrap();
        let mut values = Vec::new();
        while let Some(batch) = output.try_next().await.unwrap() {
            values.extend(
                batch
                    .column(0)
                    .as_any()
                    .downcast_ref::<Int64Array>()
                    .unwrap()
                    .iter()
                    .map(|v| v.unwrap()),
            );
        }
        assert_eq!(values, vec![0, 0, 1]);
        assert!(pool.spilled() > 0);
        drop(output);
        drop(sort);
        tokio::time::timeout(Duration::from_secs(10), async {
            while std::fs::read_dir(root.path()).unwrap().count() != 0 {
                tokio::task::yield_now().await;
            }
        })
        .await
        .expect("top-K merge cleanup stalled");
    }

    #[tokio::test]
    async fn successful_spill_outputs_survive_cleanup_transfer() {
        for sort in [false, true] {
            let root = tempfile::tempdir().unwrap();
            let (op, _, pool) = operator(root.path(), sort, Tail::End);
            let mut output = op.execute(0).await.unwrap();
            drop(op); // Sort blocking merge must retain its own directory owner.
            let mut values = Vec::new();
            while let Some(batch) = output.try_next().await.unwrap() {
                let array = batch
                    .column(0)
                    .as_any()
                    .downcast_ref::<arrow::array::Int64Array>()
                    .unwrap();
                values.extend(array.iter().map(|v| v.unwrap()));
            }
            if sort {
                assert_eq!(values, (0..1024).flat_map(|i| [i, i]).collect::<Vec<i64>>());
            } else {
                assert_eq!(values, vec![2048]);
            }
            assert!(pool.spilled() > 0);
            drop(output);
            tokio::time::timeout(Duration::from_secs(10), async {
                while std::fs::read_dir(root.path()).unwrap().count() != 0 {
                    tokio::task::yield_now().await;
                }
            })
            .await
            .expect("spill worker directory cleanup stalled");
        }
    }
}

#[cfg(test)]
mod sort_merge_task_ownership_tests {
    use super::*;
    use std::time::Duration;
    fn batch() -> RecordBatch {
        RecordBatch::try_from_iter(vec![(
            "id",
            Arc::new(Int64Array::from(vec![1])) as ArrayRef,
        )])
        .unwrap()
    }
    #[tokio::test]
    async fn panic_after_valid_prefix_is_error_and_cleans_worker_owned_files() {
        let root = tempfile::tempdir().unwrap();
        let path = root.path().join("sort_test");
        let owner = SpillDirectoryOwner::create(path.clone()).unwrap();
        std::fs::write(path.join("run.parquet"), b"lifetime sentinel").unwrap();
        let (tx, rx) = tokio::sync::mpsc::channel(1);
        let (release, parked) = std::sync::mpsc::channel();
        let worker = tokio::task::spawn_blocking(move || {
            let _owner = owner;
            tx.blocking_send(Ok(batch())).unwrap();
            parked.recv().unwrap();
            panic!("injected blocking sort panic after output");
        });
        let mut output = OwnedTaskOutputStream {
            label: "sort merge",
            receiver: rx,
            worker: Some(worker),
            finished: false,
        };
        assert_eq!(output.try_next().await.unwrap().unwrap().num_rows(), 1);
        assert!(path.exists());
        release.send(()).unwrap();
        let error = tokio::time::timeout(Duration::from_secs(10), output.try_next())
            .await
            .unwrap()
            .unwrap_err();
        assert!(error.to_string().contains("sort merge task failed"));
        assert!(!path.exists());
        assert!(output.try_next().await.unwrap().is_none());
    }
    #[tokio::test]
    async fn channel_close_waits_for_worker_success_instead_of_early_eof() {
        let (tx, rx) = tokio::sync::mpsc::channel(1);
        let (closed, ready) = tokio::sync::oneshot::channel();
        let (release, parked) = std::sync::mpsc::channel();
        let worker = tokio::task::spawn_blocking(move || {
            drop(tx);
            closed.send(()).unwrap();
            parked.recv().unwrap();
        });
        let mut output = OwnedTaskOutputStream {
            label: "sort merge",
            receiver: rx,
            worker: Some(worker),
            finished: false,
        };
        ready.await.unwrap();
        assert!(matches!(
            futures::poll!(output.next()),
            std::task::Poll::Pending
        ));
        release.send(()).unwrap();
        assert!(
            tokio::time::timeout(Duration::from_secs(10), output.try_next())
                .await
                .unwrap()
                .unwrap()
                .is_none()
        );
    }
    #[tokio::test]
    async fn consumer_drop_keeps_started_blocking_worker_directory_until_exit() {
        let root = tempfile::tempdir().unwrap();
        let path = root.path().join("sort_test");
        let owner = SpillDirectoryOwner::create(path.clone()).unwrap();
        let (tx, rx) = tokio::sync::mpsc::channel(1);
        let (started, ready) = tokio::sync::oneshot::channel();
        let (finished, done) = tokio::sync::oneshot::channel();
        let (release, parked) = std::sync::mpsc::channel();
        let worker = tokio::task::spawn_blocking(move || {
            let owner = owner;
            started.send(()).unwrap();
            parked.recv().unwrap();
            assert!(tx.blocking_send(Ok(batch())).is_err());
            drop(owner);
            finished.send(()).unwrap();
        });
        let output = OwnedTaskOutputStream {
            label: "sort merge",
            receiver: rx,
            worker: Some(worker),
            finished: false,
        };
        ready.await.unwrap();
        drop(output);
        assert!(
            path.exists(),
            "started blocking worker still owns its files"
        );
        release.send(()).unwrap();
        tokio::time::timeout(Duration::from_secs(10), done)
            .await
            .unwrap()
            .unwrap();
        assert!(!path.exists());
    }
    #[tokio::test]
    async fn ordinary_merge_error_preserves_diagnostic_and_is_terminal() {
        let (tx, rx) = tokio::sync::mpsc::channel(1);
        let worker = tokio::task::spawn_blocking(move || {
            let _ = tx.blocking_send(Err(QueryError::Execution(
                "injected merge read error".into(),
            )));
        });
        let mut output = OwnedTaskOutputStream {
            label: "sort merge",
            receiver: rx,
            worker: Some(worker),
            finished: false,
        };
        assert!(
            matches!(output.try_next().await,Err(QueryError::Execution(message)) if message=="injected merge read error")
        );
        assert!(output.try_next().await.unwrap().is_none());
    }
}

#[cfg(test)]
mod sort_fetch_boundary_tests {
    use super::*;
    #[tokio::test]
    async fn exact_fetch_boundary_never_requests_later_error() {
        let (tx, rx) = tokio::sync::mpsc::channel(1);
        let (release, parked) = std::sync::mpsc::channel();
        let (finished, done) = tokio::sync::oneshot::channel();
        let worker = tokio::task::spawn_blocking(move || {
            let batch = RecordBatch::try_from_iter(vec![(
                "id",
                Arc::new(Int64Array::from(vec![1])) as ArrayRef,
            )])
            .unwrap();
            tx.blocking_send(Ok(batch)).unwrap();
            parked.recv().unwrap();
            // A fulfilled fetch must already have closed its input stream.
            assert!(tx
                .blocking_send(Err(QueryError::Execution(
                    "must not be pulled past fetch".into()
                )))
                .is_err());
            finished.send(()).unwrap();
        });
        let input = OwnedTaskOutputStream {
            label: "sort merge",
            receiver: rx,
            worker: Some(worker),
            finished: false,
        };
        let mut output = SortFetchStream {
            input: Some(input),
            remaining: 1,
        };
        assert_eq!(output.try_next().await.unwrap().unwrap().num_rows(), 1);
        // This is immediate even though the worker has not finished. Full-drain
        // OwnedTaskOutputStream must instead wait for the task and observe panic.
        assert!(matches!(
            futures::poll!(output.next()),
            std::task::Poll::Ready(None)
        ));
        release.send(()).unwrap();
        tokio::time::timeout(std::time::Duration::from_secs(10), done)
            .await
            .unwrap()
            .unwrap();
    }
}

#[cfg(test)]
mod spilled_join_output_ownership_tests {
    use super::*;
    use std::time::Duration;
    use tokio::sync::Semaphore;
    #[derive(Clone, Copy, Debug)]
    enum Outcome {
        Panic,
        Error,
        Park,
        Complete,
    }
    #[derive(Debug)]
    struct Probe {
        schema: SchemaRef,
        root: PathBuf,
        outcome: Outcome,
        started: Arc<Semaphore>,
        released: Arc<Semaphore>,
    }
    struct Ack(Arc<Semaphore>);
    impl Drop for Ack {
        fn drop(&mut self) {
            self.0.add_permits(1);
        }
    }
    #[async_trait::async_trait]
    impl PhysicalOperator for Probe {
        fn schema(&self) -> SchemaRef {
            self.schema.clone()
        }
        fn children(&self) -> Vec<Arc<dyn PhysicalOperator>> {
            vec![]
        }
        fn name(&self) -> &str {
            "SpilledJoinOutputProbe"
        }
        async fn execute(&self, partition: usize) -> Result<RecordBatchStream> {
            crate::physical::check_partition(self, partition)?;
            let root = self.root.clone();
            let schema = self.schema.clone();
            let outcome = self.outcome;
            let started = self.started.clone();
            let ack = Ack(self.released.clone());
            // A complete phase-A group with unmatched keys creates probe files
            // without filling the output channel before the deterministic tail.
            let prefix = if matches!(outcome, Outcome::Complete) {
                Vec::new()
            } else {
                (0..PHASE_A_GROUP_BATCHES)
                    .map(|_| {
                        Ok(RecordBatch::try_new(
                            schema.clone(),
                            vec![Arc::new(Int64Array::from_iter_values(9000..9064))],
                        )
                        .unwrap())
                    })
                    .collect::<Vec<Result<RecordBatch>>>()
            };
            Ok(Box::pin(stream::iter(prefix).chain(stream::once(
                async move {
                    let _ack = ack;
                    let directories = std::fs::read_dir(&root)
                        .unwrap()
                        .map(|e| e.unwrap().path())
                        .collect::<Vec<_>>();
                    assert_eq!(directories.len(), 1);
                    assert!(
                        std::fs::read_dir(&directories[0]).unwrap().next().is_some(),
                        "actual build files must exist before probe outcome"
                    );
                    if !matches!(outcome, Outcome::Complete) {
                        assert!(
                            std::fs::read_dir(&directories[0]).unwrap().any(|e| e
                                .unwrap()
                                .file_name()
                                .to_string_lossy()
                                .starts_with("probe_")),
                            "actual per-call probe files must exist before failure/cancellation"
                        );
                    }
                    started.add_permits(1);
                    match outcome {
                        Outcome::Panic => panic!("injected spilled-join producer probe panic"),
                        Outcome::Error => Err(QueryError::Execution(
                            "injected spilled-join probe error".into(),
                        )),
                        Outcome::Park => futures::future::pending::<Result<RecordBatch>>().await,
                        Outcome::Complete => Ok(RecordBatch::try_new(
                            schema,
                            vec![Arc::new(Int64Array::from(vec![0, 4095, 9000]))],
                        )
                        .unwrap()),
                    }
                },
            ))))
        }
    }
    fn fixture(
        root: &Path,
        outcome: Outcome,
    ) -> (Arc<SpillableHashJoinExec>, Arc<Probe>, SharedMemoryPool) {
        let batch = RecordBatch::try_from_iter(vec![(
            "bk",
            Arc::new(Int64Array::from_iter_values(0..4096)) as ArrayRef,
        )])
        .unwrap();
        let build = Arc::new(crate::physical::MemoryTableExec::new(
            "build",
            batch.schema(),
            vec![batch],
            None,
        ));
        let probe = Arc::new(Probe {
            schema: Arc::new(Schema::new(vec![arrow::datatypes::Field::new(
                "pk",
                arrow::datatypes::DataType::Int64,
                false,
            )])),
            root: root.to_path_buf(),
            outcome,
            started: Arc::new(Semaphore::new(0)),
            released: Arc::new(Semaphore::new(0)),
        });
        let pool = crate::execution::create_memory_pool(4096);
        let op = Arc::new(SpillableHashJoinExec::new(
            build,
            probe.clone(),
            vec![(Expr::column("bk"), Expr::column("pk"))],
            JoinType::Inner,
            pool.clone(),
            ExecutionConfig::new()
                .with_memory_limit(4096)
                .with_spill_path(root.to_path_buf()),
        ));
        (op, probe, pool)
    }
    async fn wait(sem: &Semaphore) {
        tokio::time::timeout(Duration::from_secs(10), sem.acquire())
            .await
            .unwrap()
            .unwrap()
            .forget();
    }
    async fn cleaned(root: &Path) {
        tokio::time::timeout(Duration::from_secs(10), async {
            while std::fs::read_dir(root).unwrap().count() != 0 {
                tokio::task::yield_now().await;
            }
        })
        .await
        .expect("spill state cleanup stalled");
    }
    #[tokio::test]
    async fn public_spilled_join_producer_panic_is_error_not_empty_success() {
        let root = tempfile::tempdir().unwrap();
        let (op, probe, pool) = fixture(root.path(), Outcome::Panic);
        let mut output = op.execute(0).await.unwrap();
        let result = tokio::time::timeout(Duration::from_secs(10), output.try_next())
            .await
            .unwrap();
        assert!(
            matches!(result,Err(QueryError::Execution(message)) if message.contains("spill join output task failed"))
        );
        wait(&probe.released).await;
        assert!(pool.spilled() > 0);
        assert!(output.try_next().await.unwrap().is_none());
        drop(output);
        drop(op);
        cleaned(root.path()).await;
    }
    #[tokio::test]
    async fn public_spilled_join_source_error_preserves_diagnostic() {
        let root = tempfile::tempdir().unwrap();
        let (op, probe, _) = fixture(root.path(), Outcome::Error);
        let mut output = op.execute(0).await.unwrap();
        assert!(
            matches!(output.try_next().await,Err(QueryError::Execution(message)) if message=="injected spilled-join probe error")
        );
        wait(&probe.released).await;
        drop(output);
        drop(op);
        cleaned(root.path()).await;
    }
    #[tokio::test]
    async fn public_spilled_join_drop_cancels_parked_probe_and_keeps_memoized_build_files() {
        let root = tempfile::tempdir().unwrap();
        let (op, probe, _) = fixture(root.path(), Outcome::Park);
        let output = op.execute(0).await.unwrap();
        wait(&probe.started).await;
        drop(output);
        wait(&probe.released).await; // actual async task destruction, no sleep
        assert_eq!(
            std::fs::read_dir(root.path()).unwrap().count(),
            1,
            "operator retains memoized SpillState"
        );
        tokio::time::timeout(Duration::from_secs(10), async {
            loop {
                let memo = std::fs::read_dir(root.path())
                    .unwrap()
                    .next()
                    .unwrap()
                    .unwrap()
                    .path();
                if !std::fs::read_dir(memo).unwrap().any(|e| {
                    e.unwrap()
                        .file_name()
                        .to_string_lossy()
                        .starts_with("probe_")
                }) {
                    break;
                }
                tokio::task::yield_now().await;
            }
        })
        .await
        .expect("per-call files retained after source cancellation with live operator");
        drop(op);
        cleaned(root.path()).await;
    }
    #[tokio::test]
    async fn public_spilled_join_full_drain_keeps_files_after_operator_drop() {
        let root = tempfile::tempdir().unwrap();
        let (op, _, pool) = fixture(root.path(), Outcome::Complete);
        let mut output = op.execute(0).await.unwrap();
        drop(op);
        let mut rows = Vec::new();
        while let Some(batch) = output.try_next().await.unwrap() {
            let left = batch
                .column(0)
                .as_any()
                .downcast_ref::<Int64Array>()
                .unwrap();
            let right = batch
                .column(1)
                .as_any()
                .downcast_ref::<Int64Array>()
                .unwrap();
            rows.extend((0..batch.num_rows()).map(|i| (left.value(i), right.value(i))));
        }
        rows.sort_unstable();
        assert_eq!(rows, vec![(0, 0), (4095, 4095)]);
        assert!(pool.spilled() > 0);
        drop(output);
        cleaned(root.path()).await;
    }
}
