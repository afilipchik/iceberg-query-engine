//! Subquery execution support

use crate::error::{QueryError, Result};
use crate::physical::operators::filter::scalar_to_array;
use crate::physical::operators::TableProvider;
use crate::physical::PhysicalPlanner;
use crate::planner::{Expr, LogicalPlan, ScalarValue};
use arrow::array::{Array, ArrayRef, BooleanArray};
use arrow::record_batch::RecordBatch;
use futures::TryStreamExt;
use std::collections::HashMap;
use std::sync::Arc;

// Diagnostic only: no query/result identity or cache policy changes.
#[derive(Clone, Copy)]
struct ScalarTrace(u64);
impl ScalarTrace {
    fn enabled() -> Option<Self> {
        static NEXT: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(1);
        (std::env::var("QE_SCALAR_SUBQUERY_TRACE").as_deref() == Ok("1"))
            .then(|| Self(NEXT.fetch_add(1, std::sync::atomic::Ordering::Relaxed)))
    }
    fn emit(self, event: &str, detail: serde_json::Value) {
        use std::io::Write;
        // Broken stderr must not turn successful SQL into an error.
        let _ = writeln!(
            std::io::stderr().lock(),
            "[scalar-subquery] {}",
            serde_json::json!({"call":self.0,"event":event,"detail":detail})
        );
    }
    fn tree(self, physical: &dyn crate::physical::PhysicalOperator) {
        fn walk(
            t: ScalarTrace,
            op: &dyn crate::physical::PhysicalOperator,
            path: String,
            left: &mut usize,
        ) {
            if *left == 0 {
                return;
            }
            *left -= 1;
            t.emit("operator", serde_json::json!({"path":path,"name":op.name(),"partitions":op.output_partitions()}));
            for (i, child) in op.children().iter().enumerate() {
                if *left == 0 {
                    break;
                }
                walk(t, child.as_ref(), format!("{path}/{i}"), left);
            }
        }
        let mut left = 512;
        walk(self, physical, "root".into(), &mut left);
        self.emit(
            "tree_end",
            serde_json::json!({"node_limit":512,"limit_reached":left==0}),
        );
    }
}
struct ScalarPhase {
    trace: Option<ScalarTrace>,
    phase: &'static str,
    start: Option<std::time::Instant>,
    completed: bool,
}
impl ScalarPhase {
    fn new(trace: Option<ScalarTrace>, phase: &'static str) -> Self {
        Self {
            trace,
            phase,
            start: trace.map(|_| std::time::Instant::now()),
            completed: false,
        }
    }
    fn finish(mut self) {
        self.completed = true;
    }
}
impl Drop for ScalarPhase {
    fn drop(&mut self) {
        if let (Some(trace), Some(start)) = (self.trace, self.start) {
            trace.emit("phase", serde_json::json!({"phase":self.phase,"ms":start.elapsed().as_secs_f64()*1000.0,"completed":self.completed,"unwinding":std::thread::panicking()}));
        }
    }
}

/// Shared runtime for subquery execution. Created once, reused across all subquery
/// evaluations. This eliminates the overhead of creating a new runtime per subquery.
///
/// This runtime exists to avoid nested-runtime panics (`block_on` inside an async
/// context). It must be as wide as the main runtime: CTE materialization and
/// uncorrelated subquery pipelines run *entire* scan/join/aggregate plans here, and
/// those operators fan out with `tokio::spawn` per partition. A narrow pool
/// serializes them.
fn subquery_runtime() -> &'static tokio::runtime::Runtime {
    use std::sync::OnceLock;
    static RUNTIME: OnceLock<tokio::runtime::Runtime> = OnceLock::new();
    RUNTIME.get_or_init(|| {
        tokio::runtime::Builder::new_multi_thread()
            .worker_threads(num_cpus::get().max(2))
            .enable_all()
            .build()
            .expect("Failed to create subquery runtime")
    })
}

/// Execute an async physical plan, reusing a shared runtime instead of creating
/// a new one per subquery evaluation.
fn run_subquery_blocking(
    physical: Arc<dyn crate::physical::PhysicalOperator>,
) -> Result<Vec<RecordBatch>> {
    run_subquery_blocking_traced(physical, None)
}
fn run_subquery_blocking_traced(
    physical: Arc<dyn crate::physical::PhysicalOperator>,
    trace: Option<ScalarTrace>,
) -> Result<Vec<RecordBatch>> {
    let bridge = ScalarPhase::new(trace, "bridge_total");
    let runtime = ScalarPhase::new(trace, "runtime_acquire");
    let rt = subquery_runtime();
    runtime.finish();
    let dispatch_start = trace.map(|_| std::time::Instant::now());
    let result = std::thread::spawn(move || {
        if let Some(t) = trace {
            t.emit("bridge_enter", serde_json::json!({"dispatch_ms":dispatch_start.unwrap().elapsed().as_secs_f64()*1000.0,"rayon_threads":rayon::current_num_threads(),"tokio_workers":rt.metrics().num_workers(),"visible_cpus":num_cpus::get()}));
        }
        rt.block_on(async {
            let mut batches = Vec::new();
            for partition in 0..physical.output_partitions().max(1) {
                if let Some(t) = trace { t.emit("partition", serde_json::json!({"partition":partition})); }
                let execute = ScalarPhase::new(trace, "partition_execute");
                let stream = physical.execute(partition).await?;
                execute.finish();
                let collect = ScalarPhase::new(trace, "partition_collect");
                batches.extend(stream.try_collect::<Vec<_>>().await?);
                collect.finish();
            }
            Ok(batches)
        })
    })
    .join()
    .unwrap_or_else(|_| {
        Err(QueryError::Execution(
            "Subquery execution thread panicked".into(),
        ))
    });
    if result.is_ok() {
        bridge.finish();
    }
    result
}

/// Execute a physical plan synchronously, collecting all output batches.
/// Used for materializing CTEs and similar operations.
pub fn run_subquery_plan(
    physical: Arc<dyn crate::physical::PhysicalOperator>,
) -> Result<Vec<RecordBatch>> {
    run_subquery_blocking(physical)
}

/// Subquery executor - handles execution of subqueries during filter evaluation
#[derive(Clone)]
pub struct SubqueryExecutor {
    /// Inner executor state (wrapped in Arc for sharing)
    inner: Arc<SubqueryExecutorInner>,
}

/// Inner state of the subquery executor
struct SubqueryExecutorInner {
    /// Table providers for accessing table data
    tables: parking_lot::Mutex<HashMap<String, Arc<dyn TableProvider>>>,
    /// Cached results for uncorrelated subqueries (keyed by a hash of the plan)
    cache: parking_lot::Mutex<HashMap<usize, SubqueryResult>>,
    /// Cached results for correlated subqueries (keyed by plan hash + correlation key values)
    correlated_cache: parking_lot::Mutex<HashMap<CorrelatedCacheKey, SubqueryResult>>,
    /// Shared CTE materialization cache from the main planner
    cte_cache: parking_lot::Mutex<Option<crate::physical::planner::SharedCteCache>>,
    /// Memory pool for spillable operators in subquery plans
    memory_pool: Option<crate::execution::SharedMemoryPool>,
    /// Execution config for spillable operators in subquery plans
    config: Option<crate::execution::ExecutionConfig>,
}

/// Cache key for correlated subqueries: plan hash + correlation values
#[derive(Clone, Hash, PartialEq, Eq)]
struct CorrelatedCacheKey {
    plan_hash: usize,
    correlation_values: Vec<ScalarValue>,
}

/// Result of a subquery execution
#[derive(Clone)]
enum SubqueryResult {
    /// Scalar value (single row, single column)
    Scalar(ScalarValue),
    /// Array of values (IN subquery)
    Array(ArrayRef),
    /// Boolean result (EXISTS subquery)
    Boolean(bool),
}

impl SubqueryExecutor {
    /// Create a new subquery executor with the given tables
    pub fn from_tables(tables: HashMap<String, Arc<dyn TableProvider>>) -> Self {
        Self {
            inner: Arc::new(SubqueryExecutorInner {
                tables: parking_lot::Mutex::new(tables),
                cache: parking_lot::Mutex::new(HashMap::new()),
                correlated_cache: parking_lot::Mutex::new(HashMap::new()),
                cte_cache: parking_lot::Mutex::new(None),
                memory_pool: None,
                config: None,
            }),
        }
    }

    /// Create a new subquery executor with memory management support
    pub fn from_tables_with_config(
        tables: HashMap<String, Arc<dyn TableProvider>>,
        memory_pool: crate::execution::SharedMemoryPool,
        config: crate::execution::ExecutionConfig,
    ) -> Self {
        Self {
            inner: Arc::new(SubqueryExecutorInner {
                tables: parking_lot::Mutex::new(tables),
                cache: parking_lot::Mutex::new(HashMap::new()),
                correlated_cache: parking_lot::Mutex::new(HashMap::new()),
                cte_cache: parking_lot::Mutex::new(None),
                memory_pool: Some(memory_pool),
                config: Some(config),
            }),
        }
    }

    /// Extract correlation values from a batch row for cache key
    fn extract_correlation_values(
        &self,
        batch: &RecordBatch,
        row: usize,
    ) -> Result<Vec<ScalarValue>> {
        batch
            .columns()
            .iter()
            .map(|column| array_ref_to_scalar(column, row))
            .collect()
    }

    /// Try to get cached result for correlated subquery
    fn get_correlated_cache(
        &self,
        plan_hash: usize,
        correlation_values: &[ScalarValue],
    ) -> Option<SubqueryResult> {
        let cache = self.inner.correlated_cache.lock();
        let key = CorrelatedCacheKey {
            plan_hash,
            correlation_values: correlation_values.to_vec(),
        };
        cache.get(&key).cloned()
    }

    /// Maximum number of entries in the correlated cache to prevent unbounded memory growth
    const MAX_CORRELATED_CACHE_SIZE: usize = 100_000;

    /// Cache result for correlated subquery
    fn set_correlated_cache(
        &self,
        plan_hash: usize,
        correlation_values: Vec<ScalarValue>,
        result: SubqueryResult,
    ) {
        let mut cache = self.inner.correlated_cache.lock();

        // If cache is too large, clear it to prevent unbounded memory growth
        // This is a simple strategy - a more sophisticated approach would use LRU eviction
        if cache.len() >= Self::MAX_CORRELATED_CACHE_SIZE {
            cache.clear();
        }

        let key = CorrelatedCacheKey {
            plan_hash,
            correlation_values,
        };
        cache.insert(key, result);
    }

    /// Register a table provider
    pub fn register_table(&self, name: String, provider: Arc<dyn TableProvider>) {
        self.inner.tables.lock().insert(name, provider);
    }

    /// Set the shared CTE cache from the main planner so subquery planners can
    /// access materialized CTEs.
    pub fn set_cte_cache(&self, cache: crate::physical::planner::SharedCteCache) {
        *self.inner.cte_cache.lock() = Some(cache);
    }

    /// Create a physical planner for subquery execution
    fn create_planner(&self) -> PhysicalPlanner {
        let mut planner = match (&self.inner.memory_pool, &self.inner.config) {
            (Some(pool), Some(config)) => {
                PhysicalPlanner::with_config(pool.clone(), config.clone())
            }
            _ => PhysicalPlanner::new(),
        };
        for (name, provider) in self.inner.tables.lock().iter() {
            planner.register_table(name.clone(), provider.clone());
        }
        // Pass this executor to the planner for nested subquery support
        planner.set_subquery_executor(Some(self.clone()));
        // Share the CTE cache so subquery planners can access materialized CTEs
        if let Some(ref cache) = *self.inner.cte_cache.lock() {
            planner.set_cte_cache(Arc::clone(cache));
        }
        planner
    }

    fn plan_subquery(
        &self,
        plan: &LogicalPlan,
    ) -> Result<Arc<dyn crate::physical::PhysicalOperator>> {
        use crate::optimizer::OptimizerRule;
        // Expression subqueries have their own scope and are not traversed by
        // the outer plan's projection rule. Apply the same column dependency
        // analysis at this execution boundary before providers materialize
        // their scans. Keep the original plan as the per-query cache identity.
        let pruned = crate::optimizer::rules::ProjectionPushdown.optimize(plan)?;
        self.create_planner().create_physical_plan(&pruned)
    }

    /// Execute a scalar subquery and return the scalar value
    pub fn execute_scalar(&self, plan: &LogicalPlan) -> Result<ScalarValue> {
        let trace = ScalarTrace::enabled();
        let total = ScalarPhase::new(trace, "scalar_total");
        if let Some(t) = trace {
            t.emit("entry", serde_json::json!({"rayon_threads":rayon::current_num_threads(),"visible_cpus":num_cpus::get()}));
        }
        if plan.schema().fields().len() != 1 {
            return Err(QueryError::Execution(
                "Scalar subquery must return one column".into(),
            ));
        }
        if std::env::var("CTE_DEBUG").is_ok() {
            eprintln!("[cte] execute_scalar enter");
        }
        let key = self.plan_hash(plan);

        {
            let cache = self.inner.cache.lock();
            if let Some(SubqueryResult::Scalar(value)) = cache.get(&key) {
                if let Some(t) = trace {
                    t.emit("cache_hit", serde_json::json!({}));
                }
                total.finish();
                return Ok(value.clone());
            }
        }

        if let Some(t) = trace {
            t.emit("cache_miss", serde_json::json!({}));
        }
        let planning = ScalarPhase::new(trace, "rhs_physical_plan");
        let physical = self.plan_subquery(plan)?;
        planning.finish();
        if let Some(t) = trace {
            t.tree(physical.as_ref());
        }
        let batches = run_subquery_blocking_traced(physical, trace)?;
        let normalize = ScalarPhase::new(trace, "normalize_and_cache");

        let rows = batches.iter().map(|b| b.num_rows()).sum::<usize>();
        if rows == 0 {
            let result = ScalarValue::Null;
            self.inner
                .cache
                .lock()
                .insert(key, SubqueryResult::Scalar(result.clone()));
            normalize.finish();
            total.finish();
            return Ok(result);
        }

        if rows != 1 {
            return Err(QueryError::Execution(format!(
                "Scalar subquery returned {} rows, expected 1",
                rows
            )));
        }
        let batch = batches.iter().find(|b| b.num_rows() > 0).unwrap();
        if batch.num_columns() != 1 {
            return Err(QueryError::Execution(
                "Scalar subquery must return one column".into(),
            ));
        }
        let column = batch.column(0);
        let scalar = array_ref_to_scalar(column, 0)?;

        self.inner
            .cache
            .lock()
            .insert(key, SubqueryResult::Scalar(scalar.clone()));
        normalize.finish();
        total.finish();
        Ok(scalar)
    }

    /// Execute an IN subquery and return the array of values
    pub fn execute_in_subquery(&self, plan: &LogicalPlan) -> Result<ArrayRef> {
        if plan.schema().fields().len() != 1 {
            return Err(QueryError::Execution(
                "IN subquery must return one column".into(),
            ));
        }
        let key = self.plan_hash(plan);

        {
            let cache = self.inner.cache.lock();
            if let Some(SubqueryResult::Array(array)) = cache.get(&key) {
                return Ok(array.clone());
            }
        }

        let physical = self.plan_subquery(plan)?;

        // Run the async code reusing the existing runtime when possible
        let batches = run_subquery_blocking(physical)?;

        if batches.is_empty() {
            let result = new_empty_array(
                plan.schema()
                    .fields()
                    .first()
                    .ok_or_else(|| QueryError::Execution("IN subquery has no columns".into()))?
                    .data_type
                    .clone(),
            );
            self.inner
                .cache
                .lock()
                .insert(key, SubqueryResult::Array(result.clone()));
            return Ok(result);
        }

        // Concatenate all batches into a single array
        let result = if batches.len() == 1 {
            batches[0].column(0).clone()
        } else {
            use arrow::compute::concat;
            let arrays: Vec<&dyn Array> = batches.iter().map(|b| b.column(0).as_ref()).collect();
            concat(&arrays)?
        };

        self.inner
            .cache
            .lock()
            .insert(key, SubqueryResult::Array(result.clone()));
        Ok(result)
    }

    /// Execute an EXISTS subquery and return the boolean result
    pub fn execute_exists(&self, plan: &LogicalPlan) -> Result<bool> {
        let key = self.plan_hash(plan);

        {
            let cache = self.inner.cache.lock();
            if let Some(SubqueryResult::Boolean(value)) = cache.get(&key) {
                return Ok(*value);
            }
        }

        let physical = self.plan_subquery(plan)?;

        // Run the async code reusing the existing runtime when possible
        let batches = run_subquery_blocking(physical)?;

        let has_rows = batches.iter().any(|b| b.num_rows() > 0);

        self.inner
            .cache
            .lock()
            .insert(key, SubqueryResult::Boolean(has_rows));
        Ok(has_rows)
    }

    /// Simple hash of a plan for caching
    fn plan_hash(&self, plan: &LogicalPlan) -> usize {
        use std::hash::{Hash, Hasher};
        let mut hasher = std::collections::hash_map::DefaultHasher::new();
        format!("{:?}", plan).hash(&mut hasher);
        hasher.finish() as usize
    }
}

/// Convert an ArrayRef element to ScalarValue
fn array_ref_to_scalar(array: &ArrayRef, index: usize) -> Result<ScalarValue> {
    use arrow::array::*;

    if let arrow::datatypes::DataType::Dictionary(_, value_type) = array.data_type() {
        return array_ref_to_scalar(
            &crate::planner::numeric::cast_strict(array, value_type)?,
            index,
        );
    }
    if array.is_null(index) {
        return Ok(ScalarValue::Null);
    }

    Ok(match array.data_type() {
        arrow::datatypes::DataType::Boolean => {
            let arr = array
                .as_any()
                .downcast_ref::<BooleanArray>()
                .ok_or_else(|| QueryError::Type("Expected BooleanArray".into()))?;
            ScalarValue::Boolean(arr.value(index))
        }
        arrow::datatypes::DataType::Int8 => {
            let arr = array
                .as_any()
                .downcast_ref::<Int8Array>()
                .ok_or_else(|| QueryError::Type("Expected Int8Array".into()))?;
            ScalarValue::Int8(arr.value(index))
        }
        arrow::datatypes::DataType::Int16 => {
            let arr = array
                .as_any()
                .downcast_ref::<Int16Array>()
                .ok_or_else(|| QueryError::Type("Expected Int16Array".into()))?;
            ScalarValue::Int16(arr.value(index))
        }
        arrow::datatypes::DataType::Int32 => {
            let arr = array
                .as_any()
                .downcast_ref::<Int32Array>()
                .ok_or_else(|| QueryError::Type("Expected Int32Array".into()))?;
            ScalarValue::Int32(arr.value(index))
        }
        arrow::datatypes::DataType::Int64 => {
            let arr = array
                .as_any()
                .downcast_ref::<Int64Array>()
                .ok_or_else(|| QueryError::Type("Expected Int64Array".into()))?;
            ScalarValue::Int64(arr.value(index))
        }
        arrow::datatypes::DataType::Float32 => {
            let arr = array
                .as_any()
                .downcast_ref::<Float32Array>()
                .ok_or_else(|| QueryError::Type("Expected Float32Array".into()))?;
            ScalarValue::Float32(ordered_float::OrderedFloat(arr.value(index)))
        }
        arrow::datatypes::DataType::Float64 => {
            let arr = array
                .as_any()
                .downcast_ref::<Float64Array>()
                .ok_or_else(|| QueryError::Type("Expected Float64Array".into()))?;
            ScalarValue::Float64(ordered_float::OrderedFloat(arr.value(index)))
        }
        arrow::datatypes::DataType::Utf8 => {
            let arr = array
                .as_any()
                .downcast_ref::<StringArray>()
                .ok_or_else(|| QueryError::Type("Expected StringArray".into()))?;
            ScalarValue::Utf8(arr.value(index).to_string())
        }
        arrow::datatypes::DataType::Date32 => {
            let arr = array
                .as_any()
                .downcast_ref::<Date32Array>()
                .ok_or_else(|| QueryError::Type("Expected Date32Array".into()))?;
            ScalarValue::Date32(arr.value(index))
        }
        arrow::datatypes::DataType::UInt8 => ScalarValue::UInt8(
            array
                .as_any()
                .downcast_ref::<UInt8Array>()
                .unwrap()
                .value(index),
        ),
        arrow::datatypes::DataType::UInt16 => ScalarValue::UInt16(
            array
                .as_any()
                .downcast_ref::<UInt16Array>()
                .unwrap()
                .value(index),
        ),
        arrow::datatypes::DataType::UInt32 => ScalarValue::UInt32(
            array
                .as_any()
                .downcast_ref::<UInt32Array>()
                .unwrap()
                .value(index),
        ),
        arrow::datatypes::DataType::UInt64 => ScalarValue::UInt64(
            array
                .as_any()
                .downcast_ref::<UInt64Array>()
                .unwrap()
                .value(index),
        ),
        arrow::datatypes::DataType::Date64 => ScalarValue::Date64(
            array
                .as_any()
                .downcast_ref::<Date64Array>()
                .unwrap()
                .value(index),
        ),
        arrow::datatypes::DataType::Decimal128(_, scale) => {
            let array = array.as_any().downcast_ref::<Decimal128Array>().unwrap();
            ScalarValue::Decimal128(crate::planner::DecimalValue::new(
                array.value(index),
                *scale,
            ))
        }
        arrow::datatypes::DataType::Timestamp(_, _) => ScalarValue::Timestamp(
            crate::planner::TimestampValue::from_array(array.as_ref(), index)
                .ok_or_else(|| QueryError::Type("invalid timestamp scalar array".into()))?,
        ),
        dt => {
            return Err(QueryError::NotImplemented(format!(
                "Unsupported type for scalar subquery: {:?}",
                dt
            )))
        }
    })
}

/// Create an empty array of the given type
fn new_empty_array(data_type: arrow::datatypes::DataType) -> ArrayRef {
    arrow::array::new_empty_array(&data_type)
}

/// Collect all table names/aliases defined in a logical plan's FROM clause
fn collect_table_aliases(plan: &LogicalPlan) -> std::collections::HashSet<String> {
    let mut aliases = std::collections::HashSet::new();
    collect_table_aliases_recursive(plan, &mut aliases);
    aliases
}

fn collect_table_aliases_recursive(
    plan: &LogicalPlan,
    aliases: &mut std::collections::HashSet<String>,
) {
    use crate::planner::*;
    match plan {
        LogicalPlan::Scan(node) => {
            aliases.insert(node.table_name.clone());
        }
        LogicalPlan::SubqueryAlias(node) => {
            aliases.insert(node.alias.clone());
            // Don't recurse into the aliased input - the alias shadows it
        }
        LogicalPlan::Join(node) => {
            collect_table_aliases_recursive(&node.left, aliases);
            collect_table_aliases_recursive(&node.right, aliases);
        }
        LogicalPlan::Filter(node) => {
            collect_table_aliases_recursive(&node.input, aliases);
        }
        LogicalPlan::Project(node) => {
            collect_table_aliases_recursive(&node.input, aliases);
        }
        LogicalPlan::Aggregate(node) => {
            collect_table_aliases_recursive(&node.input, aliases);
        }
        LogicalPlan::Sort(node) => {
            collect_table_aliases_recursive(&node.input, aliases);
        }
        LogicalPlan::Limit(node) => {
            collect_table_aliases_recursive(&node.input, aliases);
        }
        LogicalPlan::Distinct(node) => {
            collect_table_aliases_recursive(&node.input, aliases);
        }
        _ => {}
    }
}

/// Check if an expression contains any column references to tables not in the given set
fn has_outer_references(expr: &Expr, local_tables: &std::collections::HashSet<String>) -> bool {
    use crate::planner::*;
    match expr {
        Expr::Column(col) => {
            if let Some(rel) = &col.relation {
                // This column references a specific table - check if it's local
                !local_tables.contains(rel)
            } else {
                // Unqualified column - assume local
                false
            }
        }
        Expr::BinaryExpr { left, right, .. } => {
            has_outer_references(left, local_tables) || has_outer_references(right, local_tables)
        }
        Expr::UnaryExpr { expr, .. } => has_outer_references(expr, local_tables),
        Expr::ScalarFunc { args, .. } | Expr::Aggregate { args, .. } => {
            args.iter().any(|a| has_outer_references(a, local_tables))
        }
        Expr::Cast { expr, .. } | Expr::Alias { expr, .. } => {
            has_outer_references(expr, local_tables)
        }
        Expr::Case {
            operand,
            when_then,
            else_expr,
        } => {
            operand
                .as_ref()
                .is_some_and(|o| has_outer_references(o, local_tables))
                || when_then.iter().any(|(w, t)| {
                    has_outer_references(w, local_tables) || has_outer_references(t, local_tables)
                })
                || else_expr
                    .as_ref()
                    .is_some_and(|e| has_outer_references(e, local_tables))
        }
        Expr::InList { expr, list, .. } => {
            has_outer_references(expr, local_tables)
                || list.iter().any(|e| has_outer_references(e, local_tables))
        }
        Expr::Between {
            expr, low, high, ..
        } => {
            has_outer_references(expr, local_tables)
                || has_outer_references(low, local_tables)
                || has_outer_references(high, local_tables)
        }
        Expr::InSubquery { expr, subquery, .. } => {
            let mut nested_scope = local_tables.clone();
            nested_scope.extend(collect_table_aliases(subquery));
            has_outer_references(expr, local_tables)
                || plan_has_outer_references(subquery, &nested_scope)
        }
        Expr::Exists { subquery, .. } | Expr::ScalarSubquery(subquery) => {
            let mut nested_scope = local_tables.clone();
            nested_scope.extend(collect_table_aliases(subquery));
            plan_has_outer_references(subquery, &nested_scope)
        }
        _ => false,
    }
}

/// Check if a plan contains any outer (correlated) column references
fn plan_has_outer_references(
    plan: &LogicalPlan,
    local_tables: &std::collections::HashSet<String>,
) -> bool {
    use crate::planner::*;
    match plan {
        LogicalPlan::Filter(node) => {
            has_outer_references(&node.predicate, local_tables)
                || plan_has_outer_references(&node.input, local_tables)
        }
        LogicalPlan::Project(node) => {
            node.exprs
                .iter()
                .any(|e| has_outer_references(e, local_tables))
                || plan_has_outer_references(&node.input, local_tables)
        }
        LogicalPlan::Join(node) => {
            node.on.iter().any(|(l, r)| {
                has_outer_references(l, local_tables) || has_outer_references(r, local_tables)
            }) || node
                .filter
                .as_ref()
                .is_some_and(|f| has_outer_references(f, local_tables))
                || plan_has_outer_references(&node.left, local_tables)
                || plan_has_outer_references(&node.right, local_tables)
        }
        LogicalPlan::Aggregate(node) => {
            node.group_by
                .iter()
                .any(|e| has_outer_references(e, local_tables))
                || node
                    .aggregates
                    .iter()
                    .any(|e| has_outer_references(e, local_tables))
                || plan_has_outer_references(&node.input, local_tables)
        }
        LogicalPlan::Sort(node) => {
            node.order_by
                .iter()
                .any(|s| has_outer_references(&s.expr, local_tables))
                || plan_has_outer_references(&node.input, local_tables)
        }
        LogicalPlan::Limit(node) => plan_has_outer_references(&node.input, local_tables),
        LogicalPlan::Distinct(node) => plan_has_outer_references(&node.input, local_tables),
        LogicalPlan::SubqueryAlias(node) => plan_has_outer_references(&node.input, local_tables),
        LogicalPlan::Scan(node) => node
            .filter
            .as_ref()
            .is_some_and(|f| has_outer_references(f, local_tables)),
        _ => false,
    }
}

/// Check if a subquery is correlated (references columns from outer scope)
/// Check if a subquery plan references outer columns (is correlated).
pub fn is_correlated_subquery_plan(subquery: &LogicalPlan) -> bool {
    is_correlated_subquery(subquery)
}

fn is_correlated_subquery(subquery: &LogicalPlan) -> bool {
    let local_tables = collect_table_aliases(subquery);
    plan_has_outer_references(subquery, &local_tables)
}

/// Evaluate a subquery expression during filter execution
pub fn evaluate_subquery_expr(
    batch: &RecordBatch,
    expr: &Expr,
    executor: &SubqueryExecutor,
) -> Result<ArrayRef> {
    match expr {
        Expr::ScalarSubquery(plan) => {
            // Check if this is a correlated subquery by analyzing the plan structure
            if is_correlated_subquery(plan) {
                // Correlated subquery - execute for each row
                return execute_correlated_scalar_subquery(batch, plan, executor);
            }

            // Uncorrelated - execute once
            match executor.execute_scalar(plan) {
                Ok(scalar) => {
                    // Use the same value for all rows
                    let num_rows = batch.num_rows();
                    Ok(crate::planner::numeric::cast_strict(
                        &scalar_to_array(&scalar, num_rows)?,
                        &plan.schema().fields()[0].data_type,
                    )?)
                }
                Err(e) if matches!(e.root(), QueryError::ColumnNotFound(_)) => {
                    // Fallback: Correlated subquery (shouldn't happen with plan analysis)
                    execute_correlated_scalar_subquery(batch, plan, executor)
                }
                Err(e) => Err(e),
            }
        }
        Expr::InSubquery {
            expr,
            subquery,
            negated,
        } => {
            let left_array =
                super::filter::evaluate_expr_with_subquery(batch, expr, Some(executor))?;
            if is_correlated_subquery(subquery) {
                let mut results = Vec::with_capacity(batch.num_rows());
                for row in 0..batch.num_rows() {
                    let substituted = substitute_correlated_columns(subquery, batch, row)?;
                    let right = executor.execute_in_subquery(&substituted)?;
                    let membership =
                        evaluate_in_subquery(&left_array.slice(row, 1), &right, *negated)?;
                    let membership = membership.as_any().downcast_ref::<BooleanArray>().unwrap();
                    results.push((!membership.is_null(0)).then(|| membership.value(0)));
                }
                return Ok(Arc::new(BooleanArray::from(results)));
            }
            let in_values = executor.execute_in_subquery(subquery)?;
            evaluate_in_subquery(&left_array, &in_values, *negated)
        }
        Expr::Exists { subquery, negated } => {
            // Check if this is a correlated subquery by analyzing the plan structure
            if is_correlated_subquery(subquery) {
                // Correlated EXISTS subquery - execute row-by-row
                return execute_correlated_exists_subquery(batch, subquery, *negated, executor);
            }

            // Uncorrelated - execute once
            match executor.execute_exists(subquery) {
                Ok(exists) => {
                    // Use the same result for all rows
                    let result = if *negated { !exists } else { exists };
                    let arr = BooleanArray::from(vec![result; batch.num_rows()]);
                    Ok(Arc::new(arr))
                }
                Err(e) if matches!(e.root(), QueryError::ColumnNotFound(_)) => {
                    // Fallback: Correlated EXISTS subquery (shouldn't happen with plan analysis)
                    execute_correlated_exists_subquery(batch, subquery, *negated, executor)
                }
                Err(e) => Err(e),
            }
        }
        _ => Err(QueryError::NotImplemented(format!(
            "Not a subquery expression: {:?}",
            expr
        ))),
    }
}

/// Execute a correlated scalar subquery for each row in the batch
fn execute_correlated_scalar_subquery(
    batch: &RecordBatch,
    plan: &LogicalPlan,
    executor: &SubqueryExecutor,
) -> Result<ArrayRef> {
    let num_rows = batch.num_rows();
    let mut results = Vec::with_capacity(num_rows);

    // Compute plan hash once for cache key
    let plan_hash = executor.plan_hash(plan);

    // For each row, we need to:
    // 1. Extract correlation key values
    // 2. Check cache for existing result
    // 3. If not cached, substitute columns and execute
    // 4. Cache the result

    for row in 0..num_rows {
        // Extract correlation values for this row (used as cache key)
        let correlation_values = executor.extract_correlation_values(batch, row)?;

        // Check cache first
        if let Some(SubqueryResult::Scalar(cached)) =
            executor.get_correlated_cache(plan_hash, &correlation_values)
        {
            results.push(cached);
            continue;
        }

        // Cache miss - execute the subquery
        let substituted_plan = substitute_correlated_columns(plan, batch, row)?;

        let scalar = executor.execute_scalar(&substituted_plan)?;

        // Cache the result
        executor.set_correlated_cache(
            plan_hash,
            correlation_values,
            SubqueryResult::Scalar(scalar.clone()),
        );
        results.push(scalar);
    }

    // Convert results to an array
    results_array_from_scalars(&results, num_rows, &plan.schema().fields()[0].data_type)
}

/// Execute a correlated EXISTS subquery for each row in the batch
fn execute_correlated_exists_subquery(
    batch: &RecordBatch,
    subquery: &LogicalPlan,
    negated: bool,
    executor: &SubqueryExecutor,
) -> Result<ArrayRef> {
    let num_rows = batch.num_rows();
    let mut results = Vec::with_capacity(num_rows);

    // Compute plan hash once for cache key
    let plan_hash = executor.plan_hash(subquery);

    for row in 0..num_rows {
        // Extract correlation values for this row (used as cache key)
        let correlation_values = executor.extract_correlation_values(batch, row)?;

        // Check cache first
        if let Some(SubqueryResult::Boolean(cached)) =
            executor.get_correlated_cache(plan_hash, &correlation_values)
        {
            results.push(if negated { !cached } else { cached });
            continue;
        }

        // Cache miss - execute the subquery
        let substituted_plan = substitute_correlated_columns(subquery, batch, row)?;

        let exists = executor.execute_exists(&substituted_plan)?;

        // Cache the result (before applying negation)
        executor.set_correlated_cache(
            plan_hash,
            correlation_values,
            SubqueryResult::Boolean(exists),
        );
        results.push(if negated { !exists } else { exists });
    }

    Ok(Arc::new(BooleanArray::from(results)))
}

/// Substitute correlated column references with literal values from a specific row
fn substitute_correlated_columns(
    plan: &LogicalPlan,
    batch: &RecordBatch,
    row: usize,
) -> Result<LogicalPlan> {
    use crate::planner::*;

    // First, collect which table aliases are local to this subquery
    // We should ONLY substitute columns that reference OUTER tables (not in this set)
    let local_tables = collect_table_aliases(plan);

    // Create a mapping of column names to their literal values for this row
    let mut column_values: std::collections::HashMap<String, Expr> =
        std::collections::HashMap::new();

    for (i, field) in batch.schema().fields().iter().enumerate() {
        let column = batch.column(i);
        let scalar = if column.is_null(row) {
            ScalarValue::Null
        } else {
            array_ref_to_scalar_value(column, row)?
        };

        let literal_expr = Expr::Literal(scalar);

        // Add the fully qualified name (e.g., "partsupp.ps_partkey")
        column_values.insert(field.name().clone(), literal_expr.clone());

        // Also add just the column name without qualifier (e.g., "ps_partkey")
        // This handles cases where the subquery uses unqualified references
        if let Some(dot_pos) = field.name().find('.') {
            let unqualified = &field.name()[dot_pos + 1..];
            column_values.insert(unqualified.to_string(), literal_expr.clone());
        }

        // Also add with potential table qualifiers from common patterns
        // E.g., "l_partkey" could be referenced as just "partkey" if context is clear
        if let Some(dot_pos) = field.name().rfind('_') {
            // Extract base name after last underscore (common pattern: table_column)
            let base_name = &field.name()[dot_pos + 1..];
            column_values.insert(base_name.to_string(), literal_expr);
        }
    }

    // Do not execute/cache a plan with an unresolved outer scope. Nested
    // correlation requires scope-aware substitution beyond the supported
    // single-level expressions; refusing it is preferable to capturing a
    // same-named column from the wrong row.
    let substituted = substitute_columns_in_plan(plan, &column_values, &local_tables)?;
    if is_correlated_subquery(&substituted) {
        return Err(QueryError::NotImplemented(
            "nested or unresolved correlated subquery scope".into(),
        ));
    }
    Ok(substituted)
}

/// Recursively substitute column references with literals in a logical plan
/// Only substitutes columns that reference tables NOT in local_tables (i.e., outer references)
fn substitute_columns_in_plan(
    plan: &LogicalPlan,
    column_values: &std::collections::HashMap<String, Expr>,
    local_tables: &std::collections::HashSet<String>,
) -> Result<LogicalPlan> {
    use crate::planner::*;

    // Recursively process the plan
    match plan {
        LogicalPlan::Filter(node) => {
            let new_predicate =
                substitute_columns_in_expr(&node.predicate, column_values, local_tables);
            let new_input = substitute_columns_in_plan(&node.input, column_values, local_tables)?;
            Ok(LogicalPlan::Filter(FilterNode {
                input: Arc::new(new_input),
                predicate: new_predicate,
            }))
        }
        LogicalPlan::Window(node) => {
            let new_input = substitute_columns_in_plan(&node.input, column_values, local_tables)?;
            let window_exprs = node
                .window_exprs
                .iter()
                .map(|(name, w)| {
                    let mut w = w.clone();
                    for a in &mut w.args {
                        *a = substitute_columns_in_expr(a, column_values, local_tables);
                    }
                    for p in &mut w.partition_by {
                        *p = substitute_columns_in_expr(p, column_values, local_tables);
                    }
                    for o in &mut w.order_by {
                        o.expr = substitute_columns_in_expr(&o.expr, column_values, local_tables);
                    }
                    (name.clone(), w)
                })
                .collect();
            Ok(LogicalPlan::Window(WindowNode {
                input: Arc::new(new_input),
                window_exprs,
                schema: node.schema.clone(),
            }))
        }
        LogicalPlan::Project(node) => {
            let new_exprs: Vec<Expr> = node
                .exprs
                .iter()
                .map(|e| substitute_columns_in_expr(e, column_values, local_tables))
                .collect();
            let new_input = substitute_columns_in_plan(&node.input, column_values, local_tables)?;
            Ok(LogicalPlan::Project(ProjectNode {
                input: Arc::new(new_input),
                exprs: new_exprs,
                schema: node.schema.clone(),
            }))
        }
        LogicalPlan::Aggregate(node) => {
            let new_group_by: Vec<Expr> = node
                .group_by
                .iter()
                .map(|e| substitute_columns_in_expr(e, column_values, local_tables))
                .collect();
            let new_aggregates: Vec<Expr> = node
                .aggregates
                .iter()
                .map(|e| substitute_columns_in_expr(e, column_values, local_tables))
                .collect();
            let new_input = substitute_columns_in_plan(&node.input, column_values, local_tables)?;
            Ok(LogicalPlan::Aggregate(AggregateNode {
                input: Arc::new(new_input),
                group_by: new_group_by,
                aggregates: new_aggregates,
                schema: node.schema.clone(),
            }))
        }
        LogicalPlan::Scan(node) => {
            // Substitute in filter expression if present
            let new_filter = node
                .filter
                .as_ref()
                .map(|f| substitute_columns_in_expr(f, column_values, local_tables));
            Ok(LogicalPlan::Scan(ScanNode {
                table_name: node.table_name.clone(),
                schema: node.schema.clone(),
                projection: node.projection.clone(),
                filter: new_filter,
            }))
        }
        LogicalPlan::Join(node) => {
            let new_on: Vec<(Expr, Expr)> = node
                .on
                .iter()
                .map(|(l, r)| {
                    (
                        substitute_columns_in_expr(l, column_values, local_tables),
                        substitute_columns_in_expr(r, column_values, local_tables),
                    )
                })
                .collect();
            let new_filter = node
                .filter
                .as_ref()
                .map(|f| substitute_columns_in_expr(f, column_values, local_tables));
            let new_left = substitute_columns_in_plan(&node.left, column_values, local_tables)?;
            let new_right = substitute_columns_in_plan(&node.right, column_values, local_tables)?;
            Ok(LogicalPlan::Join(JoinNode {
                left: Arc::new(new_left),
                right: Arc::new(new_right),
                join_type: node.join_type,
                on: new_on,
                filter: new_filter,
                schema: node.schema.clone(),
            }))
        }
        LogicalPlan::Sort(node) => {
            let new_order_by: Vec<SortExpr> = node
                .order_by
                .iter()
                .map(|s| SortExpr {
                    expr: substitute_columns_in_expr(&s.expr, column_values, local_tables),
                    direction: s.direction,
                    nulls: s.nulls,
                })
                .collect();
            let new_input = substitute_columns_in_plan(&node.input, column_values, local_tables)?;
            Ok(LogicalPlan::Sort(SortNode {
                input: Arc::new(new_input),
                order_by: new_order_by,
            }))
        }
        LogicalPlan::Limit(node) => {
            let new_input = substitute_columns_in_plan(&node.input, column_values, local_tables)?;
            Ok(LogicalPlan::Limit(LimitNode {
                input: Arc::new(new_input),
                skip: node.skip,
                fetch: node.fetch,
            }))
        }
        LogicalPlan::Distinct(node) => {
            let new_input = substitute_columns_in_plan(&node.input, column_values, local_tables)?;
            Ok(LogicalPlan::Distinct(DistinctNode {
                input: Arc::new(new_input),
            }))
        }
        LogicalPlan::SubqueryAlias(node) => {
            let new_input = substitute_columns_in_plan(&node.input, column_values, local_tables)?;
            Ok(LogicalPlan::SubqueryAlias(SubqueryAliasNode {
                input: Arc::new(new_input),
                alias: node.alias.clone(),
                schema: node.schema.clone(),
                cte_name: node.cte_name.clone(),
            }))
        }
        LogicalPlan::Union(node) => {
            let new_inputs: Result<Vec<Arc<LogicalPlan>>> = node
                .inputs
                .iter()
                .map(|i| substitute_columns_in_plan(i, column_values, local_tables).map(Arc::new))
                .collect();
            Ok(LogicalPlan::Union(UnionNode {
                inputs: new_inputs?,
                schema: node.schema.clone(),
                all: node.all,
            }))
        }
        // Pass through unchanged for leaf nodes
        LogicalPlan::EmptyRelation(_) | LogicalPlan::Values(_) => Ok(plan.clone()),

        LogicalPlan::DelimJoin(node) => {
            let new_on: Vec<(Expr, Expr)> = node
                .on
                .iter()
                .map(|(l, r)| {
                    (
                        substitute_columns_in_expr(l, column_values, local_tables),
                        substitute_columns_in_expr(r, column_values, local_tables),
                    )
                })
                .collect();
            let new_left = substitute_columns_in_plan(&node.left, column_values, local_tables)?;
            let new_right = substitute_columns_in_plan(&node.right, column_values, local_tables)?;
            Ok(LogicalPlan::DelimJoin(DelimJoinNode {
                left: Arc::new(new_left),
                right: Arc::new(new_right),
                join_type: node.join_type,
                delim_columns: node.delim_columns.clone(),
                on: new_on,
                schema: node.schema.clone(),
            }))
        }

        // A vector search never contains an outer reference: the rule only
        // fires on a literal query vector over a single scan.
        LogicalPlan::VectorSearch(node) => Ok(LogicalPlan::VectorSearch(node.clone())),
        LogicalPlan::DelimGet(node) => Ok(LogicalPlan::DelimGet(node.clone())),
    }
}

/// Substitute column references in an expression
/// Only substitutes columns that reference tables NOT in local_tables
fn substitute_columns_in_expr(
    expr: &Expr,
    column_values: &std::collections::HashMap<String, Expr>,
    local_tables: &std::collections::HashSet<String>,
) -> Expr {
    use crate::planner::*;
    match expr {
        Expr::Column(col) => {
            // Only substitute if the column's relation is NOT a local table
            // If relation is Some and it's in local_tables, DON'T substitute
            if let Some(rel) = &col.relation {
                if local_tables.contains(rel) {
                    // This is a local table column - don't substitute
                    return expr.clone();
                }
            }

            // Try to substitute both qualified and unqualified names
            let qualified_name = if let Some(rel) = &col.relation {
                format!("{}.{}", rel, col.name)
            } else {
                col.name.clone()
            };

            if let Some(substituted) = column_values.get(&qualified_name) {
                substituted.clone()
            } else {
                // A qualified outer reference must resolve that exact scope;
                // matching only its bare name can capture a local column.
                expr.clone()
            }
        }
        Expr::BinaryExpr { left, op, right } => {
            let new_left = substitute_columns_in_expr(left, column_values, local_tables);
            let new_right = substitute_columns_in_expr(right, column_values, local_tables);
            Expr::BinaryExpr {
                left: Box::new(new_left),
                op: *op,
                right: Box::new(new_right),
            }
        }
        Expr::UnaryExpr { op, expr: inner } => {
            let new_expr = substitute_columns_in_expr(inner, column_values, local_tables);
            Expr::UnaryExpr {
                op: *op,
                expr: Box::new(new_expr),
            }
        }
        Expr::Alias { expr: inner, name } => {
            let new_expr = substitute_columns_in_expr(inner, column_values, local_tables);
            Expr::Alias {
                expr: Box::new(new_expr),
                name: name.clone(),
            }
        }
        Expr::Aggregate {
            func,
            args,
            distinct,
        } => {
            let new_args: Vec<Expr> = args
                .iter()
                .map(|a| substitute_columns_in_expr(a, column_values, local_tables))
                .collect();
            Expr::Aggregate {
                func: *func,
                args: new_args,
                distinct: *distinct,
            }
        }
        Expr::ScalarFunc { args, func } => {
            let new_args: Vec<Expr> = args
                .iter()
                .map(|a| substitute_columns_in_expr(a, column_values, local_tables))
                .collect();
            Expr::ScalarFunc {
                args: new_args,
                func: func.clone(),
            }
        }
        Expr::Cast {
            expr: inner,
            data_type,
            mode,
        } => {
            let new_expr = substitute_columns_in_expr(inner, column_values, local_tables);
            Expr::Cast {
                expr: Box::new(new_expr),
                data_type: data_type.clone(),
                mode: *mode,
            }
        }
        Expr::Case {
            operand,
            when_then,
            else_expr,
        } => {
            let new_operand = operand
                .as_ref()
                .map(|e| substitute_columns_in_expr(e, column_values, local_tables));
            let new_when_then: Vec<(Expr, Expr)> = when_then
                .iter()
                .map(|(w, t)| {
                    (
                        substitute_columns_in_expr(w, column_values, local_tables),
                        substitute_columns_in_expr(t, column_values, local_tables),
                    )
                })
                .collect();
            let new_else = else_expr
                .as_ref()
                .map(|e| substitute_columns_in_expr(e, column_values, local_tables));
            Expr::Case {
                operand: new_operand.map(Box::new),
                when_then: new_when_then,
                else_expr: new_else.map(Box::new),
            }
        }
        Expr::InList {
            expr,
            list,
            negated,
        } => Expr::InList {
            expr: Box::new(substitute_columns_in_expr(
                expr,
                column_values,
                local_tables,
            )),
            list: list
                .iter()
                .map(|expr| substitute_columns_in_expr(expr, column_values, local_tables))
                .collect(),
            negated: *negated,
        },
        Expr::Between {
            expr,
            low,
            high,
            negated,
        } => Expr::Between {
            expr: Box::new(substitute_columns_in_expr(
                expr,
                column_values,
                local_tables,
            )),
            low: Box::new(substitute_columns_in_expr(low, column_values, local_tables)),
            high: Box::new(substitute_columns_in_expr(
                high,
                column_values,
                local_tables,
            )),
            negated: *negated,
        },
        // For other expressions, return as-is
        _ => expr.clone(),
    }
}

/// Convert an array element to ScalarValue at a specific index
fn array_ref_to_scalar_value(array: &ArrayRef, index: usize) -> Result<ScalarValue> {
    array_ref_to_scalar(array, index)
}

/// Convert a vector of scalars to an arrow array
fn results_array_from_scalars(
    scalars: &[ScalarValue],
    num_rows: usize,
    data_type: &arrow::datatypes::DataType,
) -> Result<ArrayRef> {
    if scalars.is_empty() {
        return Ok(arrow::array::new_null_array(data_type, num_rows));
    }
    let arrays = scalars
        .iter()
        .map(|scalar| crate::planner::numeric::cast_strict(&scalar_to_array(scalar, 1)?, data_type))
        .collect::<std::result::Result<Vec<_>, _>>()?;
    let references = arrays.iter().map(|a| a.as_ref()).collect::<Vec<_>>();
    Ok(arrow::compute::concat(&references)?)
}

/// Evaluate IN subquery by checking membership
fn evaluate_in_subquery(left: &ArrayRef, right: &ArrayRef, negated: bool) -> Result<ArrayRef> {
    use crate::planner::numeric::cast_strict;
    use arrow::datatypes::DataType;
    use arrow::row::{RowConverter, SortField};
    use std::collections::HashSet;

    // The empty-set identity takes precedence over NULL on the left.
    if right.is_empty() {
        return Ok(Arc::new(BooleanArray::from(vec![negated; left.len()])));
    }
    let decode = |array: &ArrayRef| -> Result<ArrayRef> {
        if let DataType::Dictionary(_, value_type) = array.data_type() {
            cast_strict(array, value_type)
        } else {
            Ok(array.clone())
        }
    };
    let left = decode(left)?;
    let right = decode(right)?;
    let common = crate::planner::numeric::common_type(left.data_type(), right.data_type())?;
    let left = cast_strict(&left, &common)?;
    let right = cast_strict(&right, &common)?;

    // Arrow row encoding retains exact integer/decimal domains and supports
    // all scalar comparison types without converting them to floating point.
    let converter = RowConverter::new(vec![SortField::new(common)])?;
    let right_rows = converter.convert_columns(&[right.clone()])?;
    let set: HashSet<_> = (0..right.len())
        .filter(|&row| !right.is_null(row))
        .map(|row| right_rows.row(row))
        .collect();
    let left_rows = converter.convert_columns(&[left.clone()])?;
    let result: BooleanArray = (0..left.len())
        .map(|row| {
            if left.is_null(row) {
                None
            } else if set.contains(&left_rows.row(row)) {
                Some(!negated)
            } else if right.null_count() != 0 {
                None
            } else {
                Some(negated)
            }
        })
        .collect();
    Ok(Arc::new(result))
}

#[cfg(test)]
mod tests {
    use super::*;
    use arrow::array::{BooleanArray, Int64Array};

    #[test]
    fn test_scalar_to_array_conversion() {
        let scalar = ScalarValue::Int64(42);
        let arr = scalar_to_array(&scalar, 3).unwrap();
        let int_arr = arr.as_any().downcast_ref::<Int64Array>().unwrap();
        assert_eq!(int_arr.len(), 3);
        assert_eq!(int_arr.value(0), 42);
        assert_eq!(int_arr.value(1), 42);
        assert_eq!(int_arr.value(2), 42);
    }

    #[test]
    fn test_empty_in_subquery() {
        let empty = new_empty_array(arrow::datatypes::DataType::Int64);
        let left: ArrayRef = Arc::new(Int64Array::from(vec![1, 2, 3]));
        let result = evaluate_in_subquery(&left, &empty, false).unwrap();
        let bool_arr = result.as_any().downcast_ref::<BooleanArray>().unwrap();
        assert_eq!(bool_arr.len(), 3);
        // All should be false since right side is empty
        assert!(!bool_arr.value(0));
        assert!(!bool_arr.value(1));
        assert!(!bool_arr.value(2));
    }
}

#[cfg(test)]
mod scalar_trace_cache_contract_tests {
    use super::*;
    use std::sync::atomic::{AtomicUsize, Ordering};
    #[derive(Debug)]
    struct CountingProvider {
        batch: RecordBatch,
        calls: AtomicUsize,
        fail: bool,
    }
    impl TableProvider for CountingProvider {
        fn schema(&self) -> arrow::datatypes::SchemaRef {
            self.batch.schema()
        }
        fn as_any(&self) -> &dyn std::any::Any {
            self
        }
        fn scan(&self, projection: Option<&[usize]>) -> Result<Vec<RecordBatch>> {
            self.calls.fetch_add(1, Ordering::SeqCst);
            if self.fail {
                return Err(QueryError::Type("counting scalar source failure".into()));
            }
            Ok(vec![match projection {
                Some(indices) => self.batch.project(indices)?,
                None => self.batch.clone(),
            }])
        }
    }
    fn fixture(fail: bool) -> (Arc<CountingProvider>, SubqueryExecutor, LogicalPlan) {
        let batch = RecordBatch::try_from_iter([(
            "v",
            Arc::new(arrow::array::Int64Array::from(vec![73])) as ArrayRef,
        )])
        .unwrap();
        let provider = Arc::new(CountingProvider {
            batch,
            calls: AtomicUsize::new(0),
            fail,
        });
        let executor = SubqueryExecutor::from_tables(HashMap::from([(
            "counted".into(),
            provider.clone() as Arc<dyn TableProvider>,
        )]));
        let plan = LogicalPlan::Scan(crate::planner::ScanNode {
            table_name: "counted".into(),
            schema: crate::planner::PlanSchema::new(vec![crate::planner::SchemaField::new(
                "v",
                arrow::datatypes::DataType::Int64,
            )]),
            projection: None,
            filter: None,
        });
        (provider, executor, plan)
    }
    #[test]
    fn scalar_miss_then_hit_reads_provider_once() {
        let (provider, executor, plan) = fixture(false);
        assert_eq!(
            executor.execute_scalar(&plan).unwrap(),
            ScalarValue::Int64(73)
        );
        assert_eq!(provider.calls.load(Ordering::SeqCst), 1);
        assert_eq!(
            executor.execute_scalar(&plan).unwrap(),
            ScalarValue::Int64(73)
        );
        assert_eq!(provider.calls.load(Ordering::SeqCst), 1);
    }
    #[test]
    fn source_error_preserves_type_and_does_not_publish_scalar_cache() {
        let (provider, executor, plan) = fixture(true);
        for count in 1..=2 {
            let error = executor.execute_scalar(&plan).unwrap_err();
            assert!(
                matches!(error, QueryError::Type(ref message) if message == "counting scalar source failure"),
                "{error}"
            );
            assert_eq!(provider.calls.load(Ordering::SeqCst), count);
            assert!(executor.inner.cache.lock().is_empty());
        }
    }
}

#[cfg(test)]
mod subquery_projection_contract_tests {
    use super::*;
    use arrow::array::{Int64Array, StringArray};
    use parking_lot::Mutex;

    #[derive(Debug)]
    struct ProjectedSource {
        batch: RecordBatch,
        projections: Mutex<Vec<Option<Vec<usize>>>>,
    }
    impl TableProvider for ProjectedSource {
        fn schema(&self) -> arrow::datatypes::SchemaRef {
            self.batch.schema()
        }
        fn as_any(&self) -> &dyn std::any::Any {
            self
        }
        fn scan(&self, projection: Option<&[usize]>) -> Result<Vec<RecordBatch>> {
            self.projections
                .lock()
                .push(projection.map(<[usize]>::to_vec));
            // Several batches exercise output collection and duplicate/NULL
            // semantics independently of column-pruning plan text.
            let batch = match projection {
                Some(p) => self.batch.project(p)?,
                None => self.batch.clone(),
            };
            Ok(vec![batch.slice(0, 2), batch.slice(2, 2)])
        }
    }
    fn fixture(sql: &str) -> (Arc<ProjectedSource>, SubqueryExecutor, LogicalPlan) {
        let batch = RecordBatch::try_from_iter([
            (
                "v",
                Arc::new(Int64Array::from(vec![Some(7), Some(7), None, Some(90)])) as ArrayRef,
            ),
            (
                "keep",
                Arc::new(Int64Array::from(vec![1, 1, 1, 0])) as ArrayRef,
            ),
            (
                "unused",
                Arc::new(StringArray::from(vec!["payload"; 4])) as ArrayRef,
            ),
        ])
        .unwrap();
        let provider = Arc::new(ProjectedSource {
            batch,
            projections: Mutex::new(vec![]),
        });
        let mut context = crate::ExecutionContext::new();
        context.register_table_provider("t", provider.clone());
        let plan = context.logical_plan(sql).unwrap();
        let executor = SubqueryExecutor::from_tables(HashMap::from([(
            "t".into(),
            provider.clone() as Arc<dyn TableProvider>,
        )]));
        (provider, executor, plan)
    }
    #[test]
    fn scalar_prunes_unused_provider_columns_and_preserves_cache() {
        let (source, executor, plan) = fixture("SELECT sum(v) FROM t WHERE keep > 0");
        for _ in 0..2 {
            assert_eq!(
                executor.execute_scalar(&plan).unwrap(),
                ScalarValue::Int64(14)
            );
        }
        assert_eq!(*source.projections.lock(), vec![Some(vec![0, 1])]);
    }
    #[test]
    fn in_prunes_unused_columns_without_losing_duplicates_or_nulls() {
        let (source, executor, plan) = fixture("SELECT v FROM t WHERE keep > 0");
        let result = executor.execute_in_subquery(&plan).unwrap();
        let result = result.as_any().downcast_ref::<Int64Array>().unwrap();
        assert_eq!(
            result.iter().collect::<Vec<_>>(),
            vec![Some(7), Some(7), None]
        );
        assert_eq!(*source.projections.lock(), vec![Some(vec![0, 1])]);
    }
    #[test]
    fn exists_retains_filter_dependencies_and_empty_result() {
        for (predicate, expected) in [("keep > 0", true), ("keep > 9", false)] {
            let (source, executor, plan) = fixture(&format!("SELECT v FROM t WHERE {predicate}"));
            assert_eq!(executor.execute_exists(&plan).unwrap(), expected);
            assert_eq!(*source.projections.lock(), vec![Some(vec![0, 1])]);
        }
    }
    #[test]
    fn scalar_cardinality_error_survives_pruning() {
        let (_, executor, plan) = fixture("SELECT v FROM t WHERE keep > 0");
        assert!(executor
            .execute_scalar(&plan)
            .unwrap_err()
            .to_string()
            .contains("returned 3 rows"));
    }

    #[test]
    fn already_pruned_subquery_keeps_provider_column_ordinals() {
        use crate::optimizer::OptimizerRule;
        let (source, executor, plan) = fixture("SELECT sum(v) FROM t WHERE keep > 0");
        let plan = crate::optimizer::ProjectionPushdown
            .optimize(&plan)
            .unwrap();
        assert_eq!(
            executor.execute_scalar(&plan).unwrap(),
            ScalarValue::Int64(14)
        );
        assert_eq!(*source.projections.lock(), vec![Some(vec![0, 1])]);
    }

    #[test]
    fn nested_correlated_membership_keeps_outer_filter_only_column() {
        let (_, executor, plan) =
            fixture("SELECT sum(v) FROM t WHERE v IN (SELECT u.v FROM t u WHERE u.keep = t.keep)");
        assert_eq!(
            executor.execute_scalar(&plan).unwrap(),
            ScalarValue::Int64(104)
        );
    }
}
